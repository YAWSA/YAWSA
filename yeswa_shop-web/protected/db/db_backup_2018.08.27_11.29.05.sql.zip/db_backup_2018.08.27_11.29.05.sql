-- -------------------------------------------
SET AUTOCOMMIT=0;
START TRANSACTION;
SET SQL_QUOTE_SHOW_CREATE = 1;
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
-- -------------------------------------------

-- -------------------------------------------

-- START BACKUP

-- -------------------------------------------

-- -------------------------------------------

-- TABLE `tbl_about_page_info`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_about_page_info`;
CREATE TABLE IF NOT EXISTS `tbl_about_page_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `page_id` int(11) NOT NULL,
  `type_id` int(11) DEFAULT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;


-- -------------------------------------------

-- TABLE `tbl_auth_session`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_auth_session`;
CREATE TABLE IF NOT EXISTS `tbl_auth_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `auth_code` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `device_token` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_session_create_user` (`created_by_id`),
  CONSTRAINT `fk_session_create_user` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_brand`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_brand`;
CREATE TABLE IF NOT EXISTS `tbl_brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_brand_category_id` (`category_id`),
  KEY `fk_brand_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_brand_category_id` FOREIGN KEY (`category_id`) REFERENCES `tbl_category` (`id`),
  CONSTRAINT `fk_brand_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_cart`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_cart`;
CREATE TABLE IF NOT EXISTS `tbl_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cart_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_cart_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_cart_item`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_cart_item`;
CREATE TABLE IF NOT EXISTS `tbl_cart_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_variant_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `amount` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cart_item_cart_id` (`cart_id`),
  KEY `fk_cart_item_vendor_id` (`vendor_id`),
  KEY `fk_cart_item_product_variant_id` (`product_variant_id`),
  KEY `fk_cart_item_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_cart_item_cart_id` FOREIGN KEY (`cart_id`) REFERENCES `tbl_cart` (`id`),
  CONSTRAINT `fk_cart_item_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`),
  CONSTRAINT `fk_cart_item_product_variant_id` FOREIGN KEY (`product_variant_id`) REFERENCES `tbl_product_variant` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_category`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_category`;
CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_category_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_category_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_color`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_color`;
CREATE TABLE IF NOT EXISTS `tbl_color` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `color_code` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_color_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_color_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_comment`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_comment`;
CREATE TABLE IF NOT EXISTS `tbl_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` text COLLATE utf8_unicode_ci,
  `model_type` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `model_id` int(11) NOT NULL,
  `state_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comment_created_by` (`created_by_id`),
  CONSTRAINT `fk_comment_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_contact_page_info`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_contact_page_info`;
CREATE TABLE IF NOT EXISTS `tbl_contact_page_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `page_id` int(11) NOT NULL,
  `type_id` int(11) DEFAULT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -------------------------------------------

-- TABLE `tbl_contact_us`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_contact_us`;
CREATE TABLE IF NOT EXISTS `tbl_contact_us` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text COLLATE utf8_unicode_ci,
  `contact_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_contact_us_created_by` (`created_by_id`),
  CONSTRAINT `fk_contact_us_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_country`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_country`;
CREATE TABLE IF NOT EXISTS `tbl_country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(100) NOT NULL,
  `state_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;


-- -------------------------------------------

-- TABLE `tbl_customer_profile`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_customer_profile`;
CREATE TABLE IF NOT EXISTS `tbl_customer_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `whatsapp_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_customer_profile_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_customer_profile_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_email_queue`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_email_queue`;
CREATE TABLE IF NOT EXISTS `tbl_email_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_email` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `to_email` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci,
  `subject` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_published` datetime DEFAULT NULL,
  `last_attempt` datetime DEFAULT NULL,
  `date_sent` datetime DEFAULT NULL,
  `attempts` int(11) DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `model_type` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_account_id` int(11) DEFAULT NULL,
  `message_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_file`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_file`;
CREATE TABLE IF NOT EXISTS `tbl_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `file` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `size` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `extension` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `model_id` int(11) NOT NULL,
  `model_type` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_file_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_file_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_log`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_log`;
CREATE TABLE IF NOT EXISTS `tbl_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `error` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `api` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  `state_id` int(11) DEFAULT '1',
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_login_history`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_login_history`;
CREATE TABLE IF NOT EXISTS `tbl_login_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_ip` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `failer_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_notice`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_notice`;
CREATE TABLE IF NOT EXISTS `tbl_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `model_type` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `model_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_notice_created_by` (`created_by_id`),
  CONSTRAINT `fk_notice_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_notification`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_notification`;
CREATE TABLE IF NOT EXISTS `tbl_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `to_user_id` int(11) NOT NULL,
  `model_id` int(11) NOT NULL,
  `model_type` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_notification_created_by_id` (`created_by_id`),
  KEY `fk_notification_to_user_id` (`to_user_id`),
  CONSTRAINT `fk_notification_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`),
  CONSTRAINT `fk_notification_to_user_id` FOREIGN KEY (`to_user_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_order`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_order`;
CREATE TABLE IF NOT EXISTS `tbl_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `super_order_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `shipping_charge` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_order_super_order_id` (`super_order_id`),
  KEY `fk_order_vendor_id` (`vendor_id`),
  KEY `fk_order_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_order_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`),
  CONSTRAINT `fk_order_super_order_id` FOREIGN KEY (`super_order_id`) REFERENCES `tbl_super_order` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_order_cancel`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_order_cancel`;
CREATE TABLE IF NOT EXISTS `tbl_order_cancel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_id` int(11) NOT NULL DEFAULT '0',
  `state_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_order_cancel_order_id` (`order_id`),
  KEY `fk_order_cancel_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_order_cancel_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`),
  CONSTRAINT `fk_order_cancel_order_id` FOREIGN KEY (`order_id`) REFERENCES `tbl_super_order` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_order_item`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_order_item`;
CREATE TABLE IF NOT EXISTS `tbl_order_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL DEFAULT '0',
  `product_variant_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `amount` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `expected_delivery_date` datetime DEFAULT NULL,
  `type_id` int(11) NOT NULL DEFAULT '0',
  `state_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_order_item_order_id` (`order_id`),
  KEY `fk_order_item_product_variant_id` (`product_variant_id`),
  KEY `fk_order_item_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_order_item_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`),
  CONSTRAINT `fk_order_item_order_id` FOREIGN KEY (`order_id`) REFERENCES `tbl_order` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_page`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_page`;
CREATE TABLE IF NOT EXISTS `tbl_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `extra_info` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_page_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_page_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_product`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_product`;
CREATE TABLE IF NOT EXISTS `tbl_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_product_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_product_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_product_favourite`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_product_favourite`;
CREATE TABLE IF NOT EXISTS `tbl_product_favourite` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `type_id` int(11) DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;


-- -------------------------------------------

-- TABLE `tbl_product_variant`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_product_variant`;
CREATE TABLE IF NOT EXISTS `tbl_product_variant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `color_id` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `amount` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_product_variant_product_id` (`product_id`),
  KEY `fk_product_variant_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_product_variant_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`),
  CONSTRAINT `fk_product_variant_product_id` FOREIGN KEY (`product_id`) REFERENCES `tbl_product` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_sale`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_sale`;
CREATE TABLE IF NOT EXISTS `tbl_sale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` int(11) NOT NULL,
  `model_type` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `discount` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `min_limit` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `image_file` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_setting`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_setting`;
CREATE TABLE IF NOT EXISTS `tbl_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  `type_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `state_id` int(11) DEFAULT '0',
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_shipping_address`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_shipping_address`;
CREATE TABLE IF NOT EXISTS `tbl_shipping_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `house_address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `street` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_number1` int(11) NOT NULL,
  `phone_number2` int(11) NOT NULL,
  `zipcode` int(11) NOT NULL,
  `lat` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `long` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_shipping_address_created_by_id` (`created_by_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_size`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_size`;
CREATE TABLE IF NOT EXISTS `tbl_size` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `symbol` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_size_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_size_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_state`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_state`;
CREATE TABLE IF NOT EXISTS `tbl_state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(100) NOT NULL,
  `country_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;


-- -------------------------------------------

-- TABLE `tbl_sub_category`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_sub_category`;
CREATE TABLE IF NOT EXISTS `tbl_sub_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sub_category_category_id` (`category_id`),
  KEY `fk_sub_category_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_sub_category_category_id` FOREIGN KEY (`category_id`) REFERENCES `tbl_category` (`id`),
  CONSTRAINT `fk_sub_category_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_super_order`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_super_order`;
CREATE TABLE IF NOT EXISTS `tbl_super_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shipping_address_id` int(11) NOT NULL,
  `payment_mode` int(11) NOT NULL DEFAULT '0',
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_super_order_shipping_address_id` (`shipping_address_id`),
  KEY `fk_super_order_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_super_order_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_transaction`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_transaction`;
CREATE TABLE IF NOT EXISTS `tbl_transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `model_type` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_transaction_order` (`order_id`),
  KEY `fk_transaction_created_by` (`created_by_id`),
  CONSTRAINT `fk_transaction_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_user`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `full_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` int(11) DEFAULT '0',
  `about_me` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location_tracking` int(11) NOT NULL DEFAULT '0',
  `address` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_no_1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `zipcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_verified` tinyint(1) DEFAULT '0',
  `profile_file` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tos` int(11) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `is_customer` int(11) NOT NULL DEFAULT '0',
  `is_vendor` int(11) NOT NULL DEFAULT '0',
  `state_id` int(11) NOT NULL,
  `type_id` int(11) DEFAULT '0',
  `last_visit_time` datetime DEFAULT NULL,
  `last_action_time` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `login_error_count` int(11) DEFAULT NULL,
  `activation_key` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `access_token` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timezone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_vendor_address`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_vendor_address`;
CREATE TABLE IF NOT EXISTS `tbl_vendor_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `area` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `block` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `street` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `house` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `apartment` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `office` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) DEFAULT NULL,
  `created_on` int(11) NOT NULL,
  `updated_on` int(11) NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_vendor_address_created_by` (`created_by_id`),
  CONSTRAINT `fk_vendor_address_created_by` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_vendor_location`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_vendor_location`;
CREATE TABLE IF NOT EXISTS `tbl_vendor_location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_id` int(11) NOT NULL,
  `location` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `latitude` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `longitude` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_vendor_location_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_vendor_location_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- -------------------------------------------

-- TABLE `tbl_vendor_profile`

-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_vendor_profile`;
CREATE TABLE IF NOT EXISTS `tbl_vendor_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `civil_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `whats_app_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `shopname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `shop_logo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state_id` int(11) NOT NULL DEFAULT '1',
  `type_id` int(11) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_vendor_profile_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_vendor_profile_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




INSERT INTO `tbl_about_page_info` (`id`,`title`,`description`,`page_id`,`type_id`,`state_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("2","Email","<p>Yeswaapplication@gmail.com</p>
","9","","1","","","1"),
("3","Call us at:","<p>+965 6508 2227</p>
","9","","1","","","1"),
("4","you can also contact us with:  social media via ","<p><a href=\"https://mobile.twitter.com/yeswaapp\">Twitter</a></p>

<p><a href=\"https://www.instagram.com/yeswaapp\">instagram</a></p>
","9","","1","","","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_auth_session` (`id`,`auth_code`,`device_token`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("40","eYAMSjqpYfn37GHpGn8DYuG7rPcl69n9","23D2EE4B431BAF1657EC8D4458FB975313296ACFB6B6F4E316C66E05578A7D01","2","2018-08-16 13:51:59","2018-08-22 12:11:25","199"),
("62","8KQ98UMehknIU0ImQTQc8RxPZBiZ0h7O","C6B1ECC80C2742F3B97B883F8761AC83800164758D937B6E32CBB0CE61FA345B","2","2018-08-22 09:31:25","2018-08-23 04:01:05","198"),
("79","DDYsYc9NAIQmCGnr4hsZRw8LT0hQs06r","00000000000055","2","2018-08-23 10:23:42","2018-08-23 10:27:22","202"),
("80","Duxgl3T8K4oKxMy1oGWG6AiBmCqMXcmj","00000000000055","2","2018-08-23 10:27:40","2018-08-23 10:27:52","201"),
("81","k5wkW38s2kITD8amAtbmAICpCCmZNOm8","0A0635F6CA7338E86E698064CFF0D7A2888FEF9F3F17AE6D2169ABD3B73EC491","2","2018-08-23 11:01:05","2018-08-23 11:08:42","200"),
("82","oH0uf9PMmt6UCTbzD3dxfm9g7RFfQ7Is","EACB3FDBE2E6184588BB04A7E9504BEDE3563FD89874932CD40E0AB41B7C7477","2","2018-08-23 11:02:33","2018-08-23 11:18:15","203");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_brand` (`id`,`category_id`,`title`,`description`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("116","13","Tommy Hilfiger","","1","0","2018-05-04 16:46:42","2018-05-04 16:46:42","109"),
("149","4","new product","","1","0","2018-06-27 06:46:55","2018-06-27 06:46:55","15"),
("154","4","Zara sports","","1","0","2018-06-27 10:37:37","2018-06-27 10:37:37","142"),
("155","2","Zara formal jacket","","1","0","2018-06-27 10:37:58","2018-06-27 10:37:58","142"),
("159","13","Zara jacket","","1","0","2018-06-27 10:42:10","2018-06-27 10:42:10","142"),
("160","12","brand","","1","0","2018-06-27 10:42:30","2018-06-27 10:42:30","142"),
("167","13","brand","","1","0","2018-06-27 14:06:57","2018-06-27 14:06:57","144"),
("171","12","nour","","1","0","2018-06-27 14:33:59","2018-06-27 14:33:59","137"),
("172","13","munera q8","","1","0","2018-07-02 13:18:37","2018-07-02 13:20:29","147"),
("174","13","Armani","","1","0","2018-07-06 12:04:59","2018-07-06 12:04:59","152"),
("175","12","Armani jacket","","1","0","2018-07-06 12:08:24","2018-07-06 12:08:24","152"),
("176","4","Armani","","1","0","2018-07-06 12:08:54","2018-07-06 12:08:54","152"),
("177","2","formal jacket","","1","0","2018-07-06 12:10:02","2018-07-06 12:10:02","152"),
("178","13","Porsche","","1","0","2018-07-10 11:44:57","2018-07-10 11:44:57","162"),
("179","13","laptop","","1","0","2018-07-11 10:45:18","2018-07-11 10:45:18","147"),
("180","12","food","","1","0","2018-07-11 10:45:56","2018-07-11 10:45:56","147"),
("181","12","ha","","1","0","2018-07-11 10:46:04","2018-07-11 10:46:04","147"),
("182","13","channel","","1","0","2018-07-12 12:06:21","2018-07-12 12:06:21","165"),
("183","2","pi","","1","0","2018-07-12 13:57:19","2018-07-12 13:57:19","147"),
("184","2","sold","","1","0","2018-07-12 13:57:38","2018-07-12 13:57:38","147"),
("186","13","waaaa","","1","0","2018-07-18 12:33:34","2018-07-18 12:33:34","2"),
("187","13","jjjh","","1","0","2018-07-18 13:21:09","2018-07-18 13:21:16","167"),
("188","12","big brand","","1","0","2018-07-18 13:26:31","2018-07-18 13:26:31","167"),
("189","13","lap top","","1","0","2018-07-22 13:56:59","2018-07-22 13:56:59","168"),
("191","13","adidas","","1","0","2018-07-27 12:21:24","2018-07-27 12:21:24","171"),
("192","13","Armani","","1","0","2018-08-02 10:53:52","2018-08-02 10:53:52","178"),
("193","13","lake me","","1","0","2018-08-02 11:34:32","2018-08-02 11:34:32","171"),
("194","13","yuh","","1","0","2018-08-04 08:46:31","2018-08-04 08:46:31","147"),
("195","2","mubark","","1","0","2018-08-04 22:19:48","2018-08-04 22:19:48","185"),
("197","13","Adidas","","1","0","2018-08-10 09:10:32","2018-08-10 09:10:32","198"),
("198","13","shine","","1","0","2018-08-16 13:06:10","2018-08-16 13:06:10","200"),
("199","13","locoste","","1","0","2018-08-21 14:14:36","2018-08-21 14:14:36","200"),
("200","13","lakme","","1","0","2018-08-23 05:09:56","2018-08-23 05:09:56","201");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_cart` (`id`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("114","1","0","2018-07-18 12:31:50","2018-07-18 12:31:50","2"),
("133","1","0","2018-08-10 09:28:08","2018-08-10 09:28:08","113"),
("246","1","0","2018-08-21 09:03:31","2018-08-21 09:03:31","198"),
("271","1","0","2018-08-23 11:07:25","2018-08-23 11:07:25","203");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_cart_item` (`id`,`cart_id`,`vendor_id`,`product_id`,`product_variant_id`,`quantity`,`amount`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("33","271","1","139","137","1","335","1","0","2018-08-23 11:17:09","2018-08-23 11:17:09","203");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_category` (`id`,`title`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("2","Formal Jacket","1","0","2018-03-29 12:24:54","2018-04-18 12:46:47","1"),
("4","Sports","1","0","2018-03-29 12:26:23","2018-04-18 10:37:26","1"),
("12","Leather jacket","1","0","2018-04-04 14:39:06","2018-04-18 12:46:20","1"),
("13","Jacket","1","0","2018-04-04 14:39:16","2018-04-18 12:45:40","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_color` (`id`,`title`,`color_code`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("1","Black","#000000","1","0","2018-03-29 15:05:53","2018-03-29 15:05:53","1"),
("2","Red","#FF0000","1","0","2018-03-29 15:06:09","2018-03-29 15:06:09","1"),
("3","Yellow","#FFFF00","1","0","2018-03-29 15:06:34","2018-03-29 15:06:34","1"),
("7","white","2","1","0","2018-04-11 15:17:30","2018-04-11 15:17:30","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_comment` (`id`,`comment`,`model_type`,`model_id`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("9","State Changed : New to Accepted","app\\models\\Order","5","0","0","2018-04-11 15:53:56","","1"),
("10","State Changed : Active to Inactive","app\\models\\User","146","0","0","2018-07-04 09:42:26","","1"),
("11","State Changed : Inactive to Active","app\\models\\User","146","0","0","2018-07-04 09:42:28","","1"),
("12","State Changed : New to Completed","app\\models\\Order","251","0","0","2018-08-17 10:44:07","","1"),
("13","State Changed : New to Started","app\\models\\Order","250","0","0","2018-08-17 10:45:44","","1"),
("14","State Changed : Rejected to Completed","app\\models\\Order","249","0","0","2018-08-17 10:46:01","","1"),
("15","State Changed : Started to Completed","app\\models\\Order","250","0","0","2018-08-17 10:48:51","","1"),
("16","State Changed : Completed to Cancelled","app\\models\\Order","250","0","0","2018-08-17 10:52:53","","1"),
("17","State Changed : Cancelled to Rejected","app\\models\\Order","250","0","0","2018-08-17 10:52:58","","1"),
("18","State Changed : Rejected to Completed","app\\models\\Order","250","0","0","2018-08-17 10:53:39","","1"),
("19","State Changed : Completed to Cancelled","app\\models\\Order","250","0","0","2018-08-17 10:54:21","","1"),
("20","State Changed : Cancelled to Completed","app\\models\\Order","250","0","0","2018-08-17 10:54:28","","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_country` (`id`,`country_name`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("1","Hawally","1","0","2018-05-10 10:29:10","2018-06-26 07:07:30","1"),
("2","Mubarak Al Kaber","1","0","2018-05-10 10:32:39","2018-06-26 07:07:09","1"),
("3","Al Farwanya","1","0","2018-05-10 10:32:51","2018-06-26 07:05:30","1"),
("4","Asimah","1","0","2018-05-10 10:33:02","2018-06-26 07:07:57","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_email_queue` (`id`,`from_email`,`to_email`,`message`,`subject`,`date_published`,`last_attempt`,`date_sent`,`attempts`,`state_id`,`model_id`,`model_type`,`email_account_id`,`message_id`) VALUES
("9","admin@toxsl.in","amehra537@gmail.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello admin,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://jupiter.ozvid.in/yeswa/user/resetpassword?token=RlKCsXJa494ZtEQrudoASA5VHW7GN3pH_1522497693\">http://jupiter.ozvid.in/yeswa/user/resetpassword?token=RlKCsXJa494ZtEQrudoASA5VHW7GN3pH_1522497693</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-03-31 17:31:33","0","1","0","","0","ba01221c766e857b91ac6405ce8c2aaa@jupiter.ozvid.in"),
("10","admin@toxsl.in","admin@toxsl.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello admin,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://jupiter.ozvid.in/yeswa/user/resetpassword?token=crOg2ScBHIRX3smfmDdk5w6z2T8dIQP7_1522497920\">http://jupiter.ozvid.in/yeswa/user/resetpassword?token=crOg2ScBHIRX3smfmDdk5w6z2T8dIQP7_1522497920</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-03-31 17:35:20","0","1","0","","0","1b78ac5208c76997056103423fda20c8@jupiter.ozvid.in"),
("11","admin@toxsl.in","alhwary.dsn@gmail.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello mohamed,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://jupiter.ozvid.in/yeswa/user/resetpassword?token=Fh5rLQWHwdx3gLpc2jb9B2FKCGd6KAaf_1522498191\">http://jupiter.ozvid.in/yeswa/user/resetpassword?token=Fh5rLQWHwdx3gLpc2jb9B2FKCGd6KAaf_1522498191</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-03-31 17:39:51","0","1","0","","0","60901fda6ac6c003d9d41d00fa4697a2@jupiter.ozvid.in"),
("12","admin@toxsl.in","amehra537@gmail.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello admin,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://jupiter.ozvid.in/yeswa/user/resetpassword?token=v4VIwa9ifOWSW7qDP8P4vFZj4jjg0poq_1522498972\">http://jupiter.ozvid.in/yeswa/user/resetpassword?token=v4VIwa9ifOWSW7qDP8P4vFZj4jjg0poq_1522498972</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-03-31 17:52:53","0","1","0","","0","3282d93d15d6e5511e267b40792e8ae2@jupiter.ozvid.in"),
("13","admin@toxsl.in","amehra537@gmail.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello admin,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://jupiter.ozvid.in/yeswa/user/resetpassword?token=qp-bpUAo8mDuAEeAzeuJn0FtvIwksRuC_1522499283\">http://jupiter.ozvid.in/yeswa/user/resetpassword?token=qp-bpUAo8mDuAEeAzeuJn0FtvIwksRuC_1522499283</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-03-31 17:58:04","0","1","0","","0","0e3823e782cda8a76e231d0a5b52abc2@jupiter.ozvid.in"),
("14","admin@toxsl.in","amehra537@gmail.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello admin,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://jupiter.ozvid.in/yeswa/user/resetpassword?token=Tz01xw-pnMShetm7RVx0bCatpBrZ1ylp_1522500469\">http://jupiter.ozvid.in/yeswa/user/resetpassword?token=Tz01xw-pnMShetm7RVx0bCatpBrZ1ylp_1522500469</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-03-31 18:17:49","0","1","0","","0","c45d85e4fb6171b9b9a4293288bcc332@jupiter.ozvid.in"),
("19","admin@toxsl.in","thakurrosy@hotmail.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello Reagan,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://jupiter.ozvid.in/yeswa/user/resetpassword?token=5QQIGADgZZ2HlT6u5o4UCDVFclAcyiY7_1523438003\">http://jupiter.ozvid.in/yeswa/user/resetpassword?token=5QQIGADgZZ2HlT6u5o4UCDVFclAcyiY7_1523438003</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-04-11 15:04:15","0","1","0","","0","ed64748e6642a47ef88ff5a351530f70@jupiter.ozvid.in"),
("20","admin@toxsl.in","thakurrosy@hotmail.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello Raman,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://jupiter.ozvid.in/yeswa/user/resetpassword?token=kqyF4AaGiYGtrOMdPu1tugfbFrF9cBfN_1523439358\">http://jupiter.ozvid.in/yeswa/user/resetpassword?token=kqyF4AaGiYGtrOMdPu1tugfbFrF9cBfN_1523439358</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-04-11 15:05:59","0","1","0","","0","f156d0dd0cbcb081e6bdb57db6bf8062@jupiter.ozvid.in"),
("21","admin@toxsl.in","sonusharma@gmail.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello sad fast,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://jupiter.ozvid.in/yeswa/user/resetpassword?token=o7dGfJTeCwiqHaAybRS9LckcHCNkN76u_1523449803\">http://jupiter.ozvid.in/yeswa/user/resetpassword?token=o7dGfJTeCwiqHaAybRS9LckcHCNkN76u_1523449803</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-04-11 18:00:03","0","1","0","","0","cef087166afcb222431ae448670dec97@jupiter.ozvid.in"),
("22","admin@toxsl.in","s@t.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello Vipin,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://jupiter.ozvid.in/yeswa/user/resetpassword?token=HtCbGIFH-aTwZJIMsrNEsKykca5QxwU4_1523450402\">http://jupiter.ozvid.in/yeswa/user/resetpassword?token=HtCbGIFH-aTwZJIMsrNEsKykca5QxwU4_1523450402</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-04-11 18:10:02","0","1","0","","0","7819291fce07571aee91f142c42ee6b7@jupiter.ozvid.in"),
("23","admin@toxsl.in","s@t.in","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello Vipin,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://jupiter.ozvid.in/yeswa/user/resetpassword?token=gXZoeAlCunbZtzt3lwDwZmiv2tmIW763_1523450410\">http://jupiter.ozvid.in/yeswa/user/resetpassword?token=gXZoeAlCunbZtzt3lwDwZmiv2tmIW763_1523450410</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-04-11 18:10:10","0","1","0","","0","236abe1f8c31349e8459860b596616cf@jupiter.ozvid.in"),
("24","admin@toxsl.in","muneraalrashidi@gmail.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello Munera,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://yeswa.shop/user/resetpassword?token=v6u2Ol8E7LYwOkrJvHdx4v4R8bhyWY5P_1533130618\">http://yeswa.shop/user/resetpassword?token=v6u2Ol8E7LYwOkrJvHdx4v4R8bhyWY5P_1533130618</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-08-01 13:36:58","","1","","","","176cb8f4e2ca7620ea30932fe4080e38@yeswa.shop"),
("25","admin@toxsl.in","muneraalrashidi@gmail.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello Munera,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://yeswa.shop/user/resetpassword?token=6g8jWwK_pWwS5ziXXegOo9_zpcbMh3PT_1533130650\">http://yeswa.shop/user/resetpassword?token=6g8jWwK_pWwS5ziXXegOo9_zpcbMh3PT_1533130650</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-08-01 13:37:30","","1","","","","f12e73206148ce1f9470be4dee297260@yeswa.shop"),
("26","admin@toxsl.in","alhwary.90@gmail.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello mohamed alhwary,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://yeswa.shop/user/resetpassword?token=MqPzFWUiGFdHRWnkMhnuPOkfH4KU74VB_1533130754\">http://yeswa.shop/user/resetpassword?token=MqPzFWUiGFdHRWnkMhnuPOkfH4KU74VB_1533130754</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-08-01 13:39:14","","1","","","","4ac20e2f6cb0cac93c9b060856cd1f7e@yeswa.shop"),
("27","admin@toxsl.in","yashikapatodia27@icloud.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello prize prize,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://yeswa.shop/user/resetpassword?token=2-vuFeGVQ5sTQRS2ZT56QQmWDXIKD9VJ_1533208035\">http://yeswa.shop/user/resetpassword?token=2-vuFeGVQ5sTQRS2ZT56QQmWDXIKD9VJ_1533208035</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-08-02 11:07:17","","1","","","","6a8c5642cb1838eef79670e2162c7351@yeswa.shop"),
("28","admin@toxsl.in","desh.raj@toxsltech.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello anti anki,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://yeswa.shop/user/resetpassword?token=0E5CHb7xMPNsEEXl-W3VpZHVJPE7_08q_1533208391\">http://yeswa.shop/user/resetpassword?token=0E5CHb7xMPNsEEXl-W3VpZHVJPE7_08q_1533208391</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-08-02 11:13:12","","1","","","","f496952bc3fe0cb304f5a089b147f2a5@yeswa.shop"),
("29","admin@toxsl.in","desh.raj@toxsltech.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello anti anki,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://yeswa.shop/user/resetpassword?token=VRYTwrnzeqGKLAklvnYWoaLJEgoV3UgD_1533208661\">http://yeswa.shop/user/resetpassword?token=VRYTwrnzeqGKLAklvnYWoaLJEgoV3UgD_1533208661</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-08-02 11:17:41","","1","","","","60dd282ae1edaa9cd648f9e0344d751c@yeswa.shop"),
("30","admin@toxsl.in","anki.rana47@gmail.com","<!DOCTYPE html>
<html lang=\"en\">
<head>
<style>
body {
	font-family: \"Lato\", sans-serif;
}

p {
	line-height: 25px;
	margin: 0;
}

.border-radius {
	border-radius: 4px;
}
</style>
</head>
<body>
	<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">
		<tr>
			<td align=\"center\" valign=\"top\">
				<table class=\"border-radius\" width=\"630px\" cellpadding=\"15\"
					cellspacing=\"0\" style=\"border: 1px solid #eee;\">
					<thead>
						<tr>
							<th align=\"left\" bgcolor=\"#00A65A\"
								style=\"border-bottom-left-radius: 0 !important; border-bottom-right-radius: 0 !important; border-radius: 4px; padding: 5px 13px 3px;\"><h3
									style=\"font-size: 16px; font-weight: 400; color: #fff;\"> Yeswa</h3></th>
						</tr>
					</thead>
					<tbody>
					<td><tr>
	<td align=\"left\"
		style=\"font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;\"><h3
			style=\"margin: 0; font-weight: 500; font-size: 19px;\">
			<p>Hello Anita rana,</p>
		</h3></td>
</tr>
<tr>
	<td align=\"left\">
		<p> Follow the link below to reset your password </p>
		<p><a href=\"http://yeswa.shop/user/resetpassword?token=ubcnIT759lbDduW7SAVhmWxPo3zSGC3P_1533208755\">http://yeswa.shop/user/resetpassword?token=ubcnIT759lbDduW7SAVhmWxPo3zSGC3P_1533208755</a></p>
	</td>
</tr>
</td>
<tr>
	<td align=\"left\" style=\"padding-top: 8px; padding-bottom: 3px;\">
		<p
			style=\"font-size: 14px; border-top: 1px solid #ececec; padding: 16px 0px 4px; text-align: left; color: #666; margin-top: 10px;\"></p>
		<p
			style=\"font-size: 14px; padding: 0 0px 20px; text-align: left; color: #666\">
			Thanks & Regards,<br> Yeswa Team.</p>
	</td>
</tr>
</tbody>

<tfoot>
	<tr>
		<td
			style=\"border-radius: 4px; border-top-left-radius: 0px; border-top-right-radius: 0px; height: 25px; font-family: Lato, sans-serif; border-top: 1px solid #ebebeb; border-bottom: 0;\"
			align=\"left\" bgcolor=\"#00A65A\"><h3
				style=\"font-size: 15px; font-weight: 400; color: #fff; margin: 0;\">Copyright
									&copy;  Yeswa</h3></td>
	</tr>
</tfoot>
</table>
</td>
</tr>
</table>
</body>
</html>","Recover Your Account at: YESWA","","","2018-08-02 11:19:15","","1","","","","7e4310b42d935507689c5e051cb8ec62@yeswa.shop");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_file` (`id`,`title`,`file`,`size`,`extension`,`model_id`,`model_type`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("198","Category_4_images.jpg","","5404","jpg","4","app\\models\\Category","1","0","2018-04-18 10:37:26","2018-04-18 10:37:26","1"),
("205","Category_13_imagesjackets-.jpg","","4171","jpg","13","app\\models\\Category","1","0","2018-04-18 12:45:40","2018-04-18 12:45:40","1"),
("206","Category_12_images3.jpg","","6095","jpg","12","app\\models\\Category","1","0","2018-04-18 12:46:20","2018-04-18 12:46:20","1"),
("207","Category_2_images3.jpg","","6095","jpg","2","app\\models\\Category","1","0","2018-04-18 12:46:47","2018-04-18 12:46:47","1"),
("273","Brand_116_image1525432598419.77.png","","33172","png","116","app\\models\\Brand","1","0","2018-05-04 16:46:42","2018-05-04 16:46:42","109"),
("274","Product_69_image1525432703441.73.png","","118663","png","69","app\\models\\Product","1","0","2018-05-04 16:48:24","2018-05-04 16:48:24","109"),
("291","Brand_127_image1525769517387.13.png","","25951","png","127","app\\models\\Brand","1","0","2018-05-08 14:21:58","2018-05-08 14:21:58","115"),
("306","Brand_135_image1526637776340.29.png","","35010","png","135","app\\models\\Brand","1","0","2018-05-18 15:32:57","2018-05-18 15:32:57","128"),
("309","Brand_137_image1529398557244.59.png","","25456","png","137","app\\models\\Brand","1","0","2018-06-19 08:55:58","2018-06-19 08:55:58","132"),
("324","Brand_149_image1530082014529.17.png","","38592","png","149","app\\models\\Brand","1","0","2018-06-27 06:46:55","2018-06-27 06:46:55","15"),
("325","Product_83_image1530082080677.36.png","","1050168","png","83","app\\models\\Product","1","0","2018-06-27 06:48:03","2018-06-27 06:48:03","15"),
("332","Brand_154_image1530095856030.4.png","","36714","png","154","app\\models\\Brand","1","0","2018-06-27 10:37:37","2018-06-27 10:37:37","142"),
("333","Brand_155_image1530095877773.76.png","","35184","png","155","app\\models\\Brand","1","0","2018-06-27 10:37:58","2018-06-27 10:37:58","142"),
("337","Brand_159_image1530096129606.51.png","","8727","png","159","app\\models\\Brand","1","0","2018-06-27 10:42:10","2018-06-27 10:42:10","142"),
("338","Brand_160_image1530096149393.33.png","","34340","png","160","app\\models\\Brand","1","0","2018-06-27 10:42:30","2018-06-27 10:42:30","142"),
("341","Product_87_image1530096234360.79.png","","511843","png","87","app\\models\\Product","1","0","2018-06-27 10:43:56","2018-06-27 10:43:56","142"),
("368","Brand_167_image1530108384053.69.png","","7337","png","167","app\\models\\Brand","1","0","2018-06-27 14:06:57","2018-06-27 14:06:57","144"),
("373","Brand_171_image1530110039689.7.png","","11830","png","171","app\\models\\Brand","1","0","2018-06-27 14:33:59","2018-06-27 14:33:59","137"),
("374","Product_92_image1530110131317.33.png","","154279","png","92","app\\models\\Product","1","0","2018-06-27 14:35:45","2018-06-27 14:35:45","137"),
("377","Brand_172_image1530537628241.42.png","","165017","png","172","app\\models\\Brand","1","0","2018-07-02 13:20:29","2018-07-02 13:20:29","147"),
("379","Product_94_image1530537927687.07.png","","142533","png","94","app\\models\\Product","1","0","2018-07-02 13:25:28","2018-07-02 13:25:28","147"),
("380","Product_95_image1530538044530.89.png","","564684","png","95","app\\models\\Product","1","0","2018-07-02 13:27:26","2018-07-02 13:27:26","147"),
("389","Brand_174_image1530878698815.11.png","","7337","png","174","app\\models\\Brand","1","0","2018-07-06 12:04:59","2018-07-06 12:04:59","152"),
("390","Product_102_image1530878729000.9.png","","35439","png","102","app\\models\\Product","1","0","2018-07-06 12:05:30","2018-07-06 12:05:30","152"),
("392","Brand_175_image1530878903834.54.png","","7337","png","175","app\\models\\Brand","1","0","2018-07-06 12:08:24","2018-07-06 12:08:24","152"),
("393","Brand_176_image1530878934203.57.png","","7337","png","176","app\\models\\Brand","1","0","2018-07-06 12:08:54","2018-07-06 12:08:54","152"),
("394","Product_103_image1530878964838.21.png","","35439","png","103","app\\models\\Product","1","0","2018-07-06 12:09:25","2018-07-06 12:09:25","152"),
("395","Brand_177_image1530879000588.13.png","","7337","png","177","app\\models\\Brand","1","0","2018-07-06 12:10:02","2018-07-06 12:10:02","152"),
("396","Product_104_image1530879041372.35.png","","35439","png","104","app\\models\\Product","1","0","2018-07-06 12:10:42","2018-07-06 12:10:42","152"),
("397","Product_105_image1530879078550.56.png","","35439","png","105","app\\models\\Product","1","0","2018-07-06 12:11:19","2018-07-06 12:11:19","152"),
("398","Brand_178_image1531223096174.12.png","","17929","png","178","app\\models\\Brand","1","0","2018-07-10 11:44:57","2018-07-10 11:44:57","162"),
("399","Product_106_image1531223134372.68.png","","606359","png","106","app\\models\\Product","1","0","2018-07-10 11:45:37","2018-07-10 11:45:37","162"),
("400","Brand_179_image1531305917411.26.png","","209687","png","179","app\\models\\Brand","1","0","2018-07-11 10:45:18","2018-07-11 10:45:18","147"),
("401","Brand_180_image1531305955382.71.png","","165182","png","180","app\\models\\Brand","1","0","2018-07-11 10:45:56","2018-07-11 10:45:56","147"),
("402","Brand_181_image1531305964514.79.png","","11830","png","181","app\\models\\Brand","1","0","2018-07-11 10:46:04","2018-07-11 10:46:04","147"),
("403","Product_107_image1531306011014.4.png","","533530","png","107","app\\models\\Product","1","0","2018-07-11 10:46:52","2018-07-11 10:46:52","147"),
("406","Brand_182_image1531397179327.25.png","","131403","png","182","app\\models\\Brand","1","0","2018-07-12 12:06:21","2018-07-12 12:06:21","165"),
("407","Product_110_image1531397211154.68.png","","789501","png","110","app\\models\\Product","1","0","2018-07-12 12:06:54","2018-07-12 12:06:54","165"),
("408","Product_111_image1531401260088.82.png","","85387","png","111","app\\models\\Product","1","0","2018-07-12 13:14:20","2018-07-12 13:14:20","147"),
("409","Product_112_image1531401449184.22.png","","85387","png","112","app\\models\\Product","1","0","2018-07-12 13:17:29","2018-07-12 13:17:29","147"),
("410","Brand_183_image1531403838390.51.png","","248833","png","183","app\\models\\Brand","1","0","2018-07-12 13:57:19","2018-07-12 13:57:19","147"),
("411","Brand_184_image1531403857471.35.png","","73343","png","184","app\\models\\Brand","1","0","2018-07-12 13:57:38","2018-07-12 13:57:38","147"),
("412","Product_113_image1531403878574.73.png","","85387","png","113","app\\models\\Product","1","0","2018-07-12 13:57:59","2018-07-12 13:57:59","147"),
("419","Brand_186_image1531917212727.93.png","","71520","png","186","app\\models\\Brand","1","0","2018-07-18 12:33:34","2018-07-18 12:33:34","2"),
("420","Product_116_image1531917228837.33.png","","61628","png","116","app\\models\\Product","1","0","2018-07-18 12:33:50","2018-07-18 12:33:50","2"),
("422","Brand_187_image1531920076121.98.png","","1239","png","187","app\\models\\Brand","1","0","2018-07-18 13:21:16","2018-07-18 13:21:16","167"),
("423","Product_117_image1531920100623.4.png","","22329","png","117","app\\models\\Product","1","0","2018-07-18 13:21:43","2018-07-18 13:21:43","167"),
("424","Product_117_image1531920100653.01.png","","12421","png","117","app\\models\\Product","1","0","2018-07-18 13:21:43","2018-07-18 13:21:43","167"),
("425","Product_117_image1531920100683.88.png","","35439","png","117","app\\models\\Product","1","0","2018-07-18 13:21:43","2018-07-18 13:21:43","167"),
("426","Brand_188_image1531920390436.83.png","","7337","png","188","app\\models\\Brand","1","0","2018-07-18 13:26:31","2018-07-18 13:26:31","167"),
("427","Product_118_image1531920410672.05.png","","35439","png","118","app\\models\\Product","1","0","2018-07-18 13:26:52","2018-07-18 13:26:52","167"),
("428","Product_119_image1531921446867.74.png","","35439","png","119","app\\models\\Product","1","0","2018-07-18 13:44:09","2018-07-18 13:44:09","167"),
("429","Brand_189_image1532267819026.72.png","","67367","png","189","app\\models\\Brand","1","0","2018-07-22 13:56:59","2018-07-22 13:56:59","168"),
("430","Product_120_image1532267856001.55.png","","326155","png","120","app\\models\\Product","1","0","2018-07-22 13:57:37","2018-07-22 13:57:37","168"),
("431","Product_121_image1532267886186.15.png","","326155","png","121","app\\models\\Product","1","0","2018-07-22 13:58:07","2018-07-22 13:58:07","168"),
("433","Brand_191_image1532694083598.7.png","","9263","png","191","app\\models\\Brand","1","0","2018-07-27 12:21:24","2018-07-27 12:21:24","171"),
("434","Product_122_image1532694937742.12.png","","835611","png","122","app\\models\\Product","1","0","2018-07-27 12:35:40","2018-07-27 12:35:40","171"),
("438","Brand_192_image1533207230788.48.png","","77145","png","192","app\\models\\Brand","1","0","2018-08-02 10:53:52","2018-08-02 10:53:52","178"),
("439","Product_125_image1533208133890.2.png","","102817","png","125","app\\models\\Product","1","0","2018-08-02 11:09:00","2018-08-02 11:09:00","178"),
("440","Product_125_image1533208133977.05.png","","106794","png","125","app\\models\\Product","1","0","2018-08-02 11:09:00","2018-08-02 11:09:00","178"),
("441","Brand_193_image1533209671614.4.png","","9263","png","193","app\\models\\Brand","1","0","2018-08-02 11:34:32","2018-08-02 11:34:32","171"),
("442","Product_126_image1533209707708.04.png","","1050168","png","126","app\\models\\Product","1","0","2018-08-02 11:35:17","2018-08-02 11:35:17","171"),
("443","Product_126_image1533209707793.76.png","","835611","png","126","app\\models\\Product","1","0","2018-08-02 11:35:17","2018-08-02 11:35:17","171"),
("444","Brand_194_image1533372389653.96.png","","154913","png","194","app\\models\\Brand","1","0","2018-08-04 08:46:31","2018-08-04 08:46:31","147"),
("445","Product_127_image1533372418604.41.png","","807444","png","127","app\\models\\Product","1","0","2018-08-04 08:47:00","2018-08-04 08:47:00","147"),
("446","Brand_195_image1533421187333.64.png","","11830","png","195","app\\models\\Brand","1","0","2018-08-04 22:19:48","2018-08-04 22:19:48","185"),
("447","Product_128_image1533421222245.18.png","","197483","png","128","app\\models\\Product","1","0","2018-08-04 22:20:23","2018-08-04 22:20:23","185"),
("448","Product_129_image1533421251900.68.png","","161125","png","129","app\\models\\Product","1","0","2018-08-04 22:20:53","2018-08-04 22:20:53","185"),
("451","Brand_197_image1533892231600.38.png","","42553","png","197","app\\models\\Brand","1","0","2018-08-10 09:10:32","2018-08-10 09:10:32","198"),
("452","Product_131_image1533892920861.22.png","","680463","png","131","app\\models\\Product","1","0","2018-08-10 09:22:04","2018-08-10 09:22:04","198"),
("453","Product_131_image1533892920950.98.png","","571300","png","131","app\\models\\Product","1","0","2018-08-10 09:22:04","2018-08-10 09:22:04","198"),
("454","Product_132_image1533898266261.96.png","","61428","png","132","app\\models\\Product","1","0","2018-08-10 10:51:07","2018-08-10 10:51:07","198"),
("455","Brand_198_image1534424769819.27.png","","18608","png","198","app\\models\\Brand","1","0","2018-08-16 13:06:10","2018-08-16 13:06:10","200"),
("456","Product_133_image1534424850170.6.png","","617077","png","133","app\\models\\Product","1","0","2018-08-16 13:07:38","2018-08-16 13:07:38","200"),
("457","Product_134_image1534424995321.86.png","","404587","png","134","app\\models\\Product","1","0","2018-08-16 13:09:57","2018-08-16 13:09:57","200"),
("458","Product_135_image1534479946302.53.png","","602344","png","135","app\\models\\Product","1","0","2018-08-17 04:25:54","2018-08-17 04:25:54","198"),
("459","Brand_199_image1534860874926.09.png","","66924","png","199","app\\models\\Brand","1","0","2018-08-21 14:14:36","2018-08-21 14:14:36","200"),
("460","Product_136_image1534860927459.63.png","","224586","png","136","app\\models\\Product","1","0","2018-08-21 14:15:29","2018-08-21 14:15:29","200"),
("461","Product_136_image1534860927557.83.png","","225178","png","136","app\\models\\Product","1","0","2018-08-21 14:15:29","2018-08-21 14:15:29","200"),
("462","Brand_200_image1535000995667.34.png","","37337","png","200","app\\models\\Brand","1","0","2018-08-23 05:09:56","2018-08-23 05:09:56","201"),
("463","Product_137_image1535001018589.2.png","","32514","png","137","app\\models\\Product","1","0","2018-08-23 05:10:19","2018-08-23 05:10:19","201"),
("464","Product_138_image1535002575189.11.png","","764413","png","138","app\\models\\Product","1","0","2018-08-23 05:36:19","2018-08-23 05:36:19","201"),
("465","Product_139_shirt.jpg","","64404","jpg","139","app\\models\\Product","1","0","2018-08-23 11:14:14","2018-08-23 11:14:14","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_log` (`id`,`error`,`api`,`description`,`state_id`,`link`,`type_id`,`created_on`) VALUES
("687","Missing required parameters: token","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘resetpassword‘, Array)
#3 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/resetpassw...‘, Array)
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /yeswa/user/resetpassword","0","2018-04-11 14:59:20"),
("688","Missing required parameters: id","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘update‘, Array)
#3 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘setting/update‘, Array)
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /yeswa/setting/update","0","2018-04-11 15:01:25"),
("689","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘add‘, Array)
#9 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘setting/add‘, Array)
#10 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /yeswa/setting/add","0","2018-04-11 15:01:27"),
("690","Missing required parameters: id","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘view‘, Array)
#3 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘file/view‘, Array)
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /yeswa/file/view","0","2018-04-11 15:18:29"),
("691","Missing required parameters: id","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘view‘, Array)
#3 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘file/view‘, Array)
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /yeswa/file/view","0","2018-04-11 15:18:42"),
("692","You are not allowed to access this page.","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/protected/controllers/BrandController.php(121): app\\controllers\\BrandController->findModel(‘68‘)
#1 [internal function]: app\\controllers\\BrandController->actionView(‘68‘)
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/InlineAction.php(67): call_user_func_array(Array, Array)
#3 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘view‘, Array)
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘brand/view‘, Array)
#6 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#7 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#8 {main}","1","403:  /yeswa/brand/68","0","2018-04-11 15:18:53"),
("693","Missing required parameters: id","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘view‘, Array)
#3 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘file/view‘, Array)
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /yeswa/file/view","0","2018-04-18 10:40:04"),
("694","Missing required parameters: id","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘view‘, Array)
#3 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘file/view‘, Array)
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /yeswa/file/view","0","2018-04-18 12:45:30"),
("695","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /yeswa/user/download","0","2018-05-02 11:51:15"),
("696","Login Required","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(168): yii\\web\\User->loginRequired()
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#3 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#6 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#9 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘shop-logo‘, Array)
#10 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘vendor-profile/...‘, Array)
#11 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#12 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#13 {main}","1","403:  /yeswa/vendor-profile/shop-logo/59?file=user-1526547680-shop_logouser_id_123.png&thumbnail=150","0","2018-05-17 14:40:37"),
("697","Login Required","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(168): yii\\web\\User->loginRequired()
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#3 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#6 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#9 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘shop-logo‘, Array)
#10 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘vendor-profile/...‘, Array)
#11 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#12 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#13 {main}","1","403:  /yeswa/vendor-profile/shop-logo/59?file=user-1526548261-shop_logouser_id_123.png&thumbnail=150","0","2018-05-17 14:41:07"),
("698","Login Required","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(168): yii\\web\\User->loginRequired()
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#3 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#6 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#9 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘shop-logo‘, Array)
#10 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘vendor-profile/...‘, Array)
#11 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#12 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#13 {main}","1","403:  /yeswa/vendor-profile/shop-logo/59?file=user-1526548261-shop_logouser_id_123.png&thumbnail=150","0","2018-05-17 14:42:51"),
("699","Login Required","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(168): yii\\web\\User->loginRequired()
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#3 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#6 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#9 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘shop-logo‘, Array)
#10 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘vendor-profile/...‘, Array)
#11 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#12 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#13 {main}","1","403:  /yeswa/vendor-profile/shop-logo/59?file=user-1526548261-shop_logouser_id_123.png&thumbnail=150","0","2018-05-17 14:44:24"),
("700","Login Required","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(168): yii\\web\\User->loginRequired()
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#3 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#6 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#9 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘shop-logo‘, Array)
#10 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘vendor-profile/...‘, Array)
#11 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#12 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#13 {main}","1","403:  /yeswa/vendor-profile/shop-logo/59?file=user-1526548591-shop_logouser_id_123.png&thumbnail=150","0","2018-05-17 14:47:20"),
("701","Login Required","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(168): yii\\web\\User->loginRequired()
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#3 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#6 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#9 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘shop-logo‘, Array)
#10 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘vendor-profile/...‘, Array)
#11 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#12 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#13 {main}","1","403:  /yeswa/vendor-profile/shop-logo/59?file=user-1526548591-shop_logouser_id_123.png&thumbnail=150","0","2018-05-17 14:52:19"),
("702","Login Required","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(168): yii\\web\\User->loginRequired()
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#3 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#6 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#9 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘shop-logo‘, Array)
#10 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘vendor-profile/...‘, Array)
#11 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#12 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#13 {main}","1","403:  /yeswa/vendor-profile/shop-logo/59?file=user-1526548953-shop_logouser_id_123.png&thumbnail=150","0","2018-05-17 14:52:41"),
("703","Login Required","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(168): yii\\web\\User->loginRequired()
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#3 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#6 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#9 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘shop-logo‘, Array)
#10 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘vendor-profile/...‘, Array)
#11 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#12 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#13 {main}","1","403:  /yeswa/vendor-profile/shop-logo/59?file=user-1526548953-shop_logouser_id_123.png&thumbnail=150","0","2018-05-17 14:56:56"),
("704","Login Required","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(168): yii\\web\\User->loginRequired()
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#3 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#6 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#9 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘shop-logo‘, Array)
#10 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘vendor-profile/...‘, Array)
#11 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#12 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#13 {main}","1","403:  /yeswa/vendor-profile/shop-logo/59?file=user-1526549236-shop_logouser_id_123.png&thumbnail=150","0","2018-05-17 14:57:35"),
("705","Login Required","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(168): yii\\web\\User->loginRequired()
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#3 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#6 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#9 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘shop-logo‘, Array)
#10 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘vendor-profile/...‘, Array)
#11 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#12 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#13 {main}","1","403:  /yeswa/vendor-profile/shop-logo/59?file=user-1526549547-shop_logouser_id_123.png&thumbnail=150","0","2018-05-17 15:02:33"),
("706","Login Required","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(168): yii\\web\\User->loginRequired()
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#3 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#6 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#9 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘shop-logo‘, Array)
#10 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘vendor-profile/...‘, Array)
#11 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#12 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#13 {main}","1","403:  /yeswa/vendor-profile/shop-logo/59?file=user-1526549547-shop_logouser_id_123.png&thumbnail=150","0","2018-05-17 15:06:38"),
("707","Login Required","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(168): yii\\web\\User->loginRequired()
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#3 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#6 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#9 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘shop-logo‘, Array)
#10 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘vendor-profile/...‘, Array)
#11 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#12 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#13 {main}","1","403:  /yeswa/vendor-profile/shop-logo/59?file=user-1526549547-shop_logouser_id_123.png&thumbnail=150","0","2018-05-17 15:08:18"),
("708","Login Required","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(168): yii\\web\\User->loginRequired()
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#3 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#6 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#9 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘shop-logo‘, Array)
#10 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘vendor-profile/...‘, Array)
#11 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#12 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#13 {main}","1","403:  /yeswa/vendor-profile/shop-logo/59?file=user-1526549916-shop_logouser_id_123.png&thumbnail=150","0","2018-05-17 15:08:42"),
("709","Login Required","","#0 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(168): yii\\web\\User->loginRequired()
#1 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#2 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#3 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#6 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#9 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘shop-logo‘, Array)
#10 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘vendor-profile/...‘, Array)
#11 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/vendor_human/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#12 /var/sentora/hostdata/ozvid/public_html/jupiter_ozvid_in/yeswa/index.php(10): yii\\base\\Application->run()
#13 {main}","1","403:  /yeswa/vendor-profile/shop-logo/59?file=user-1526549916-shop_logouser_id_123.png&thumbnail=150","0","2018-05-17 15:18:49"),
("710","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download","0","2018-06-19 09:36:47"),
("711","You are not allowed to access this page.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/controllers/ProductController.php(99): app\\controllers\\ProductController->findModel(‘85‘)
#1 [internal function]: app\\controllers\\ProductController->actionView(‘85‘)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(67): call_user_func_array(Array, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘view‘, Array)
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘product/view‘, Array)
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#8 {main}","1","403:  /product/85/new-lakme-product","0","2018-06-27 10:04:07"),
("712","You are not allowed to access this page.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/controllers/CategoryController.php(116): app\\controllers\\CategoryController->findModel(‘14‘)
#1 [internal function]: app\\controllers\\CategoryController->actionView(‘14‘)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(67): call_user_func_array(Array, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘view‘, Array)
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘category/view‘, Array)
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#8 {main}","1","403:  /category/14/casual-shoes","0","2018-07-04 09:25:51"),
("713","You are not allowed to access this page.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(164): yii\\gii\\Module->beforeAction(Object(yii\\base\\InlineAction))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘‘, Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘tugii‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#5 {main}","1","403:  /tugii","0","2018-07-06 09:58:03"),
("715","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘add‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘contact-us/add‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /contact-us/add","0","2018-07-10 08:55:30"),
("716","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download","0","2018-07-24 05:21:50"),
("717","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard/index‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /dashboard/index","0","2018-08-08 10:40:56"),
("718","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard/index‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /dashboard/index","0","2018-08-08 10:41:00"),
("719","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard/index‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /dashboard/index","0","2018-08-08 10:41:02"),
("720","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard/index‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /dashboard/index","0","2018-08-08 10:42:38"),
("721","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard/index‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /dashboard/index","0","2018-08-08 10:42:40"),
("722","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard/index‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /dashboard/index","0","2018-08-08 10:42:42"),
("723","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard/index‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /dashboard/index","0","2018-08-08 10:42:44"),
("724","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard/index‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /dashboard/index","0","2018-08-08 10:42:46"),
("725","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard/index‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /dashboard/index","0","2018-08-08 10:42:47"),
("726","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard/index‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /dashboard/index","0","2018-08-08 10:42:47"),
("727","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘login‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/login‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /user/login","0","2018-08-08 10:42:54"),
("728","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘login‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/login‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /user/login","0","2018-08-08 10:44:18"),
("729","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard/index‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /dashboard/index","0","2018-08-08 10:44:22"),
("730","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard/index‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /dashboard/index","0","2018-08-08 10:44:41"),
("731","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard/index‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /dashboard/index","0","2018-08-08 10:44:43"),
("732","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘login‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/login‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /user/login","0","2018-08-08 10:44:51"),
("733","You are not allowed to perform this action.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/filters/AccessControl.php(150): yii\\filters\\AccessControl->denyAccess(Object(app\\components\\WebUser))
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/ActionFilter.php(87): yii\\filters\\AccessControl->beforeAction(Object(yii\\base\\InlineAction))
#2 [internal function]: yii\\base\\ActionFilter->beforeFilter(Object(yii\\base\\ActionEvent))
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Component.php(604): call_user_func(Array, Object(yii\\base\\ActionEvent))
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(305): yii\\base\\Component->trigger(‘beforeAction‘, Object(yii\\base\\ActionEvent))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Controller.php(173): yii\\base\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/components/TController.php(204): yii\\web\\Controller->beforeAction(Object(yii\\base\\InlineAction))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(174): app\\components\\TController->beforeAction(Object(yii\\base\\InlineAction))
#8 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘index‘, Array)
#9 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘dashboard/index‘, Array)
#10 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#11 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#12 {main}","1","403:  /dashboard/index","0","2018-08-08 10:45:03"),
("734","You are not allowed to access this page.","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/protected/controllers/ProductController.php(99): app\\controllers\\ProductController->findModel(‘112‘)
#1 [internal function]: app\\controllers\\ProductController->actionView(‘112‘)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(67): call_user_func_array(Array, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘view‘, Array)
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘product/view‘, Array)
#6 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#7 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#8 {main}","1","403:  /product/112","0","2018-08-10 05:15:35"),
("735","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534419787-image_fileuser_id_1.jpeg","0","2018-08-16 11:51:10"),
("736","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534419787-image_fileuser_id_1.jpeg","0","2018-08-16 11:56:01"),
("737","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534419787-image_fileuser_id_1.jpeg","0","2018-08-16 11:59:41"),
("738","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534419787-image_fileuser_id_1.jpeg","0","2018-08-20 10:16:20"),
("739","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534419787-image_fileuser_id_1.jpeg","0","2018-08-20 10:20:18"),
("740","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534419787-image_fileuser_id_1.jpeg","0","2018-08-20 10:40:52"),
("741","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=images.jpeg","0","2018-08-20 13:16:21"),
("742","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534419787-image_fileuser_id_1.jpeg","0","2018-08-20 13:16:21"),
("743","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534419787-image_fileuser_id_1.jpeg","0","2018-08-21 04:21:51"),
("744","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=images.jpeg","0","2018-08-21 04:21:51"),
("745","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534419787-image_fileuser_id_1.jpeg","0","2018-08-21 04:23:42"),
("746","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=images.jpeg","0","2018-08-21 04:23:42"),
("747","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=images.jpeg","0","2018-08-21 04:30:41"),
("748","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534419787-image_fileuser_id_1.jpeg","0","2018-08-21 04:30:41"),
("749","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534826243-image_fileuser_id_1.jpg","0","2018-08-21 04:38:19"),
("750","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534826233-image_fileuser_id_1.jpg","0","2018-08-21 04:38:20"),
("751","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534826219-image_fileuser_id_1.jpg","0","2018-08-21 04:38:21"),
("752","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534826243-image_fileuser_id_1.jpg","0","2018-08-21 04:38:56"),
("753","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534826243-image_fileuser_id_1.jpg","0","2018-08-21 04:39:14"),
("754","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534826243-image_fileuser_id_1.jpg","0","2018-08-21 04:39:15"),
("755","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534826233-image_fileuser_id_1.jpg","0","2018-08-21 04:39:42"),
("756","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534826243-image_fileuser_id_1.jpg","0","2018-08-21 04:43:17"),
("757","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534826243-image_fileuser_id_1.jpg","0","2018-08-21 04:45:54"),
("758","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534826243-image_fileuser_id_1.jpg","0","2018-08-21 04:47:30"),
("759","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download?file=sale-1534826233-image_fileuser_id_1.jpg","0","2018-08-21 04:50:59"),
("760","Missing required parameters: profile_file","","#0 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/InlineAction.php(58): yii\\web\\Controller->bindActionParams(Object(yii\\base\\InlineAction), Array)
#1 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Controller.php(176): yii\\base\\InlineAction->runWithParams(Array)
#2 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Module.php(591): yii\\base\\Controller->runAction(‘download‘, Array)
#3 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/web/Application.php(109): yii\\base\\Module->runAction(‘user/download‘, Array)
#4 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/vendor/yiisoft/yii2/base/Application.php(430): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))
#5 /var/sentora/hostdata/yeswa/public_html/yeswa_shop/index.php(10): yii\\base\\Application->run()
#6 {main}","1","400:  /user/download","0","2018-08-23 11:11:04");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_login_history` (`id`,`user_id`,`user_ip`,`user_agent`,`failer_reason`,`state_id`,`type_id`,`code`,`created_on`) VALUES
("1","2","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-28 13:12:02"),
("2","2","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-28 13:12:11"),
("3","12","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-28 14:49:57"),
("4","1","168.187.65.119","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-28 15:06:48"),
("5","1","168.187.65.119","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-28 15:08:21"),
("6","1","168.187.65.119","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-28 15:08:36"),
("7","1","103.54.102.131","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-28 15:09:11"),
("8","1","168.187.65.119","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-28 15:09:45"),
("9","1","168.187.65.119","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-28 15:10:17"),
("10","12","61.246.7.159","development/YESWA/1.0","","1","0","","2018-03-28 18:06:18"),
("11","1","103.54.102.131","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-29 10:26:10"),
("12","1","103.54.102.131","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-29 10:26:23"),
("13","13","61.246.7.159","development/YESWA/1.0","","1","0","","2018-03-29 10:52:28"),
("14","12","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-03-29 11:18:59"),
("15","12","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-29 11:19:13"),
("16","12","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-29 11:20:42"),
("17","15","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-29 11:27:54"),
("18","16","61.246.7.159","development/YESWA/1.0","","1","0","","2018-03-29 11:37:04"),
("19","20","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-29 11:47:58"),
("20","21","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-29 11:49:17"),
("21","1","103.54.102.131","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-29 12:02:11"),
("22","1","103.54.102.131","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-29 12:02:20"),
("23","21","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-29 12:02:39"),
("24","12","61.246.7.159","development/YESWA/1.0","","1","0","","2018-03-29 12:25:59"),
("25","25","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-29 16:07:23"),
("26","25","61.246.7.159","development/YESWA/1.0","","1","0","","2018-03-29 16:08:23"),
("27","19","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-03-29 16:16:52"),
("28","27","61.246.7.159","development/YESWA/1.0","","1","0","","2018-03-29 16:19:40"),
("29","27","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-29 16:20:34"),
("30","27","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-29 16:20:35"),
("31","1","103.54.102.131","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-29 16:21:22"),
("32","1","103.54.102.131","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-29 16:21:31"),
("33","1","103.54.102.131","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-29 16:23:00"),
("34","29","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-29 16:27:10"),
("35","29","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-29 16:28:17"),
("36","30","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-29 16:30:02"),
("37","30","61.246.7.159","development/YESWA/1.0","","1","0","","2018-03-29 16:30:19"),
("38","29","61.246.7.159","development/YESWA/1.0","","1","0","","2018-03-29 16:34:25"),
("39","20","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-03-29 16:49:52"),
("40","20","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-03-29 16:50:02"),
("41","35","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-29 16:50:39"),
("42","37","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-29 16:55:40"),
("43","29","61.246.7.159","development/YESWA/1.0","","1","0","","2018-03-29 17:05:21"),
("44","44","61.246.7.159","development/YESWA/1.0","","1","0","","2018-03-29 17:51:22"),
("45","44","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-29 17:52:15"),
("46","45","61.246.7.159","development/YESWA/1.0","","1","0","","2018-03-29 18:03:48"),
("47","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-29 18:17:04"),
("48","51","61.246.7.159","development/YESWA/1.0","","1","0","","2018-03-29 18:40:50"),
("49","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-03-29 18:49:38"),
("50","52","149.147.89.22","development/YESWA/1.0","","1","0","","2018-03-29 20:47:19"),
("51","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-30 09:37:33"),
("52","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-03-30 10:55:28"),
("53","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-03-30 16:00:03"),
("56","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 10:57:51"),
("57","1","103.54.102.131","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 16:11:44"),
("58","1","103.54.102.131","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 16:11:53"),
("59","53","149.147.21.25","development/YESWA/1.0","","1","0","","2018-03-31 16:17:46"),
("60","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 17:15:03"),
("61","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 17:25:43"),
("62","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 17:33:59"),
("63","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 17:37:49"),
("64","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 17:38:01"),
("65","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 17:54:14"),
("66","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 17:54:21"),
("67","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:00:48"),
("68","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:01:48"),
("69","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:01:56"),
("70","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:02:00"),
("71","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:05:32"),
("72","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:06:56"),
("73","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:07:15"),
("74","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:07:16"),
("75","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:07:25"),
("76","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:07:43"),
("77","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:07:43"),
("78","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:07:52"),
("79","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:08:05"),
("80","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:08:25"),
("81","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:08:27"),
("82","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:08:33"),
("83","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:08:40"),
("84","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:09:29"),
("85","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:12:22"),
("86","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:12:31"),
("87","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:12:51"),
("88","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:13:31"),
("89","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:13:36"),
("90","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-03-31 18:53:11"),
("91","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-02 09:55:05"),
("92","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-02 10:27:41"),
("93","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-02 10:27:48"),
("94","47","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-02 11:46:09"),
("95","47","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-02 11:46:17"),
("96","47","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-02 11:46:39"),
("97","47","103.54.102.131","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","{\"password\":[\"Incorrect username or password.\"]}","0","1","http://jupiter.ozvid.in/yeswa/api","2018-04-02 11:49:15"),
("98","47","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","{\"password\":[\"Incorrect username or password.\"]}","0","1","http://jupiter.ozvid.in/yeswa/api","2018-04-02 11:52:06"),
("99","47","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","1","http://jupiter.ozvid.in/yeswa/api","2018-04-02 11:52:25"),
("100","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-02 12:11:47"),
("101","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-02 12:58:59"),
("102","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-02 13:01:13");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_login_history` (`id`,`user_id`,`user_ip`,`user_agent`,`failer_reason`,`state_id`,`type_id`,`code`,`created_on`) VALUES
("103","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-02 14:19:30"),
("104","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-02 15:42:32"),
("105","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-02 15:50:55"),
("106","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-02 15:52:19"),
("107","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-02 15:55:18"),
("108","12","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-02 17:04:32"),
("109","1","149.147.82.37","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-02 17:43:40"),
("110","1","149.147.82.37","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-02 17:44:15"),
("111","1","149.147.82.37","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-02 17:44:25"),
("112","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-02 17:50:01"),
("113","1","149.147.82.37","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-02 17:53:04"),
("114","1","149.147.82.37","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-02 17:53:14"),
("115","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-03 10:43:04"),
("116","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-03 11:40:31"),
("117","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-03 11:57:33"),
("118","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-03 16:12:01"),
("119","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-03 16:12:07"),
("120","47","61.246.7.159","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/603.3.8 (KHTML, like Gecko) Version/10.1.2 Safari/603.3.8","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-03 16:18:13"),
("121","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-03 17:44:47"),
("122","1","61.246.7.159","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/603.3.8 (KHTML, like Gecko) Version/10.1.2 Safari/603.3.8","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-03 18:10:04"),
("123","54","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-03 18:45:36"),
("124","54","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-03 18:53:37"),
("125","54","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-03 19:01:15"),
("126","54","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-03 19:09:25"),
("127","54","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-03 19:13:49"),
("128","54","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-03 19:13:57"),
("129","54","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-03 19:20:04"),
("130","54","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-03 19:22:33"),
("131","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-04 09:27:15"),
("135","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-05 12:03:55"),
("136","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-05 15:04:23"),
("137","1","61.246.7.159","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_1) AppleWebKit/604.3.5 (KHTML, like Gecko) Version/11.0.1 Safari/604.3.5","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-05 15:44:43"),
("138","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-05 16:53:43"),
("139","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-05 16:55:56"),
("140","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-05 17:16:42"),
("141","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-05 17:31:31"),
("142","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-05 18:26:53"),
("143","47","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","1","http://jupiter.ozvid.in/yeswa/api","2018-04-05 19:13:18"),
("144","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-05 19:19:05"),
("145","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-06 09:37:28"),
("146","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-06 10:11:39"),
("147","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-06 10:15:43"),
("148","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-06 10:28:25"),
("149","47","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-06 10:34:55"),
("150","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-06 10:54:55"),
("151","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-06 10:58:26"),
("152","1","103.54.102.131","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-06 11:04:10"),
("153","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-06 11:04:13"),
("154","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-06 11:53:49"),
("155","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-06 12:40:53"),
("156","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-06 12:58:59"),
("157","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-06 14:49:57"),
("158","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-06 15:00:41"),
("159","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-06 15:07:54"),
("160","56","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-06 16:45:28"),
("161","57","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-06 16:53:42"),
("162","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-06 17:35:02"),
("163","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-06 18:24:54"),
("164","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-07 10:09:41"),
("165","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-07 11:45:58"),
("166","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-07 12:47:44"),
("167","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-07 13:17:04"),
("168","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-07 15:34:11"),
("169","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-07 15:34:35"),
("170","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-07 15:34:41"),
("171","47","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-07 16:14:30"),
("172","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-07 16:14:36"),
("173","53","149.147.179.227","development/YESWA/1.0","","1","0","","2018-04-07 17:00:22"),
("174","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-07 18:21:54"),
("175","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-07 18:21:59"),
("176","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-09 09:24:33"),
("177","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-09 09:24:37"),
("178","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-09 10:29:59"),
("179","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-09 14:20:50"),
("180","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-09 15:51:22"),
("181","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-09 15:53:39"),
("182","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-09 16:13:56"),
("183","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-09 16:14:56"),
("184","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-09 16:16:44"),
("185","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-10 11:19:53"),
("186","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-10 11:22:40"),
("187","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-10 12:22:23"),
("188","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-10 12:22:54"),
("189","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-10 14:35:11"),
("190","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-10 16:08:30"),
("191","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-10 16:39:10"),
("192","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-10 18:26:19"),
("193","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-10 18:35:43"),
("194","55","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-11 09:37:41"),
("195","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 09:37:51"),
("196","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 09:50:36"),
("197","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 11:06:48"),
("198","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 11:08:29"),
("199","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 11:36:11"),
("200","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 12:05:22"),
("201","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 12:41:42"),
("202","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 12:43:23"),
("203","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 12:44:44"),
("204","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 12:48:00"),
("205","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 13:46:18");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_login_history` (`id`,`user_id`,`user_ip`,`user_agent`,`failer_reason`,`state_id`,`type_id`,`code`,`created_on`) VALUES
("206","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 13:54:38"),
("207","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 13:54:46"),
("208","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 14:17:27"),
("209","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 14:17:36"),
("210","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 14:17:52"),
("211","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 14:17:59"),
("212","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 14:29:56"),
("213","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 14:30:01"),
("215","58","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 14:41:38"),
("216","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 14:43:32"),
("217","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 14:44:59"),
("218","59","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 14:47:15"),
("219","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 14:58:50"),
("220","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 14:58:56"),
("221","1","103.54.102.131","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 15:07:46"),
("222","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 15:07:55"),
("223","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 15:21:44"),
("224","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 15:33:15"),
("225","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 15:36:49"),
("226","58","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-11 16:05:24"),
("227","58","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-11 16:05:36"),
("228","58","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-11 16:05:45"),
("229","58","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-11 16:05:57"),
("230","58","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-11 16:06:08"),
("231","58","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 16:06:31"),
("232","59","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 16:07:23"),
("233","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 16:07:52"),
("234","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 16:08:06"),
("235","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 16:09:30"),
("236","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 16:09:36"),
("237","58","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 16:23:10"),
("238","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 16:25:35"),
("239","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 16:26:14"),
("240","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 16:26:59"),
("241","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 16:41:08"),
("242","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 16:43:44"),
("243","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 16:44:34"),
("244","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-11 16:54:11"),
("245","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 17:17:23"),
("246","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 17:51:32"),
("247","60","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 18:10:39"),
("248","61","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 18:15:38"),
("249","60","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 18:29:24"),
("250","61","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 18:29:50"),
("251","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 18:33:29"),
("252","62","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 18:42:42"),
("253","62","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 18:43:24"),
("254","62","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 18:44:14"),
("255","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 18:44:28"),
("256","62","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 18:44:45"),
("257","62","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 18:45:52"),
("258","62","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 18:46:25"),
("259","63","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 18:47:46"),
("260","62","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 18:49:49"),
("261","62","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 18:53:16"),
("262","62","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-11 18:53:46"),
("263","62","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-11 18:53:58"),
("264","62","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 18:55:00"),
("265","62","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-11 18:56:45"),
("266","62","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 18:58:08"),
("267","64","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 19:25:49"),
("268","65","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-11 19:31:25"),
("269","66","188.71.229.42","development/YESWA/1.0","","1","0","","2018-04-11 19:48:52"),
("270","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-12 10:10:49"),
("271","62","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-12 10:14:26"),
("272","62","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-12 10:14:37"),
("273","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-12 10:18:31"),
("274","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-12 10:23:34"),
("275","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-12 10:29:52"),
("276","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-12 15:59:14"),
("277","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-12 16:25:13"),
("278","47","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-12 16:29:34"),
("279","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-12 16:29:42"),
("280","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-12 18:59:08"),
("281","47","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-13 11:54:56"),
("282","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-13 11:55:01"),
("283","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-13 12:06:49"),
("284","67","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-13 15:18:20"),
("285","67","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-13 15:34:17"),
("286","68","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-13 15:37:30"),
("287","68","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-13 15:39:43"),
("288","68","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-13 15:43:33"),
("289","68","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-13 15:48:17"),
("290","68","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-13 16:15:56"),
("291","68","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","","2018-04-13 16:23:47"),
("292","1","103.54.102.131","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-13 16:46:43"),
("293","1","103.54.102.131","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-13 16:46:57"),
("294","47","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-13 17:10:10"),
("295","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-13 17:10:17"),
("296","68","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-16 10:18:15"),
("297","69","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-16 10:25:12"),
("298","70","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-16 10:53:12"),
("299","71","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-16 11:43:52"),
("300","71","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-16 11:46:46"),
("301","71","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-16 11:51:03"),
("302","71","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-16 11:56:08"),
("303","72","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-16 12:08:38"),
("304","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-16 12:14:09"),
("305","72","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-16 12:16:10"),
("306","72","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-16 12:19:44");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_login_history` (`id`,`user_id`,`user_ip`,`user_agent`,`failer_reason`,`state_id`,`type_id`,`code`,`created_on`) VALUES
("307","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-16 12:21:29"),
("308","72","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-16 12:25:13"),
("309","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-16 12:27:02"),
("310","72","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-16 12:42:18"),
("311","72","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-16 12:43:54"),
("312","72","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-16 12:46:17"),
("313","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-16 13:03:50"),
("314","73","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-16 14:39:12"),
("315","73","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-16 14:42:20"),
("316","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-16 15:06:40"),
("317","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-16 15:57:39"),
("318","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-17 14:43:58"),
("319","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-17 15:05:45"),
("320","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-18 10:25:36"),
("321","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-18 10:25:43"),
("322","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-18 11:39:06"),
("323","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-18 11:42:02"),
("324","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-18 12:43:49"),
("325","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-18 12:44:40"),
("326","68","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-18 13:01:35"),
("327","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-18 15:09:49"),
("328","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-18 15:13:35"),
("329","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-18 16:13:05"),
("330","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-18 16:28:24"),
("331","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-18 18:46:14"),
("332","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-19 09:06:16"),
("333","68","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-19 09:38:01"),
("334","68","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-19 09:42:18"),
("335","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-19 09:43:39"),
("336","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-19 12:03:55"),
("337","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-19 12:03:55"),
("338","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-19 12:43:37"),
("339","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-19 13:04:01"),
("340","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-19 13:05:15"),
("341","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-19 13:11:40"),
("342","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-19 13:21:57"),
("343","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-19 13:28:11"),
("344","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-19 14:25:54"),
("345","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-19 14:52:24"),
("346","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-19 15:01:08"),
("347","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-19 15:14:50"),
("348","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-19 15:33:27"),
("349","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-19 15:34:01"),
("350","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-19 15:34:46"),
("351","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-19 16:12:44"),
("352","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-19 16:13:05"),
("353","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-19 17:21:29"),
("354","47","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-19 17:28:27"),
("355","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-19 17:28:36"),
("356","76","188.70.61.100","development/YESWA/1.0","","1","0","","2018-04-20 00:18:16"),
("357","66","188.70.29.168","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-21 20:53:49"),
("358","66","188.70.29.168","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-21 20:53:57"),
("359","66","188.70.29.168","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-21 20:54:03"),
("360","77","188.70.29.168","development/YESWA/1.0","","1","0","","2018-04-21 20:54:30"),
("361","55","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-23 09:37:05"),
("362","55","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-23 09:38:11"),
("363","78","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-23 09:54:34"),
("364","78","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-23 09:57:42"),
("365","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-23 10:31:47"),
("366","79","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-23 15:59:29"),
("367","80","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-30 10:41:54"),
("368","47","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-30 11:17:57"),
("369","47","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-30 11:18:08"),
("370","47","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-30 11:18:16"),
("371","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-30 11:18:25"),
("372","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-30 11:38:55"),
("373","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-30 11:42:12"),
("374","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-04-30 11:42:17"),
("375","80","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-30 12:09:42"),
("376","80","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-30 12:37:08"),
("377","80","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-30 12:37:17"),
("378","80","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-30 12:41:50"),
("379","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-30 13:29:47"),
("380","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-30 14:59:02"),
("381","81","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-30 15:31:06"),
("382","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-30 16:52:33"),
("383","80","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-30 18:03:32"),
("384","80","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-30 18:03:40"),
("385","80","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-30 18:03:48"),
("386","80","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-04-30 18:03:56"),
("387","82","103.54.102.131","development/YESWA/1.0","","1","0","","2018-04-30 18:04:50"),
("388","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-30 18:07:29"),
("389","82","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-30 18:49:44"),
("390","82","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-30 19:10:34"),
("391","82","61.246.7.159","development/YESWA/1.0","","1","0","","2018-04-30 19:28:47"),
("392","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-01 09:51:50"),
("393","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 09:58:41"),
("394","80","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-01 10:03:56"),
("395","80","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-01 10:04:05"),
("396","80","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-01 10:04:15"),
("397","82","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-01 10:04:25"),
("398","82","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-01 10:04:33"),
("399","85","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 10:15:57"),
("400","85","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-01 10:17:17"),
("401","85","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-01 10:17:25"),
("402","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-01 10:17:52"),
("403","86","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-01 10:34:02"),
("404","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-01 10:37:00"),
("405","87","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 10:40:12"),
("406","88","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 10:43:36");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_login_history` (`id`,`user_id`,`user_ip`,`user_agent`,`failer_reason`,`state_id`,`type_id`,`code`,`created_on`) VALUES
("407","86","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 10:56:38"),
("408","89","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-01 11:23:01"),
("409","89","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-01 11:23:16"),
("410","90","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 11:25:32"),
("411","90","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-01 11:31:17"),
("412","89","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-01 11:36:40"),
("413","91","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 11:45:12"),
("414","90","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 11:51:37"),
("415","86","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-01 11:54:43"),
("416","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 11:55:04"),
("417","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 11:55:19"),
("418","92","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 12:07:28"),
("419","93","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 12:08:47"),
("420","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-01 12:21:04"),
("421","86","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 12:27:06"),
("422","94","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 12:38:36"),
("423","94","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 12:41:01"),
("424","94","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 12:41:23"),
("425","94","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 12:47:53"),
("426","94","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 13:31:28"),
("427","96","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 14:05:45"),
("428","88","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-01 14:24:00"),
("429","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-01 14:38:11"),
("430","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 14:42:00"),
("431","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-01 14:42:43"),
("432","96","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 14:53:26"),
("433","97","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 14:57:46"),
("434","97","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-01 15:01:37"),
("435","88","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 15:04:28"),
("436","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-01 15:11:12"),
("437","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-01 15:12:02"),
("438","88","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 15:38:06"),
("439","98","188.71.226.27","development/YESWA/1.0","","1","0","","2018-05-01 15:48:18"),
("440","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-01 15:57:57"),
("441","88","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-01 16:54:48"),
("442","99","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-02 10:58:17"),
("443","88","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-02 11:01:11"),
("444","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-05-02 11:47:20"),
("445","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-05-02 11:47:27"),
("446","1","46.186.220.18","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1 Safari/605.1.15","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-05-02 11:51:13"),
("447","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-03 16:55:14"),
("448","88","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-03 18:07:37"),
("449","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-03 18:32:43"),
("450","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-05-04 10:45:49"),
("451","1","103.54.102.131","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-05-04 10:45:56"),
("452","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 10:49:39"),
("453","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 11:12:43"),
("454","101","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 11:50:37"),
("455","100","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 11:53:36"),
("456","102","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-04 12:06:16"),
("457","102","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 12:06:23"),
("458","100","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 12:39:32"),
("459","100","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 12:39:38"),
("460","100","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 12:39:50"),
("461","102","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 12:41:20"),
("462","103","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 12:44:08"),
("463","101","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 12:45:11"),
("464","102","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 12:47:46"),
("465","104","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 12:51:05"),
("466","107","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 13:23:58"),
("467","107","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 13:25:26"),
("468","107","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 13:26:09"),
("469","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-05-04 14:30:53"),
("470","108","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 15:44:13"),
("471","109","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 15:48:01"),
("472","108","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 16:18:37"),
("473","109","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 16:26:57"),
("474","110","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 17:20:02"),
("475","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 17:31:37"),
("476","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 17:41:13"),
("477","111","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 17:47:28"),
("478","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 17:50:28"),
("479","111","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 18:10:35"),
("480","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 18:11:19"),
("481","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 18:16:37"),
("482","111","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 18:17:02"),
("483","109","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 18:18:25"),
("484","108","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 18:20:07"),
("485","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 18:23:56"),
("486","112","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 18:24:47"),
("487","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 18:39:59"),
("488","109","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 18:40:52"),
("489","108","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 18:53:55"),
("490","109","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 18:55:43"),
("491","108","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 18:56:44"),
("492","109","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 18:59:19"),
("493","109","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 19:09:00"),
("494","108","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-04 19:10:31"),
("495","109","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-04 19:11:37"),
("496","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-07 12:14:43"),
("497","112","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-07 12:27:32"),
("498","112","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-07 12:27:40"),
("499","112","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-07 12:28:23"),
("500","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-07 12:40:40"),
("501","113","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-07 13:06:47"),
("502","113","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-07 13:11:01"),
("503","114","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-08 14:07:35"),
("504","115","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-08 14:14:10"),
("505","115","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-08 14:14:20"),
("506","114","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-08 14:40:34");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_login_history` (`id`,`user_id`,`user_ip`,`user_agent`,`failer_reason`,`state_id`,`type_id`,`code`,`created_on`) VALUES
("507","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-08 15:35:21"),
("508","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-08 16:13:17"),
("509","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-05-08 16:18:28"),
("510","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-08 16:20:38"),
("511","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-08 16:40:46"),
("512","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-08 16:57:03"),
("513","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-08 16:57:53"),
("514","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-08 17:15:04"),
("515","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-09 10:07:51"),
("516","116","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-09 10:09:41"),
("517","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-09 10:57:37"),
("518","116","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-09 11:05:23"),
("519","116","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-09 11:47:06"),
("520","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-09 18:47:38"),
("521","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-11 09:30:31"),
("522","116","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-11 10:27:16"),
("523","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-11 10:53:08"),
("524","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-11 11:13:56"),
("525","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-11 11:59:17"),
("526","116","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-11 12:00:19"),
("527","47","103.54.102.131","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-11 12:00:49"),
("528","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-11 12:00:56"),
("529","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-11 12:01:32"),
("530","116","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-11 12:13:56"),
("531","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-11 12:14:14"),
("532","117","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-11 12:18:59"),
("533","116","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-11 12:35:18"),
("534","117","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-11 12:36:33"),
("535","116","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-11 12:43:04"),
("536","117","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-11 12:52:03"),
("537","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-11 13:04:02"),
("538","117","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-11 13:04:37"),
("539","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-11 13:23:49"),
("540","116","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-11 14:46:35"),
("541","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-11 14:47:18"),
("542","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-14 13:00:09"),
("543","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-14 13:13:54"),
("544","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-14 14:33:18"),
("545","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-14 14:46:05"),
("546","117","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-14 14:47:16"),
("547","116","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-14 15:01:33"),
("548","117","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-14 15:05:31"),
("549","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-14 15:06:09"),
("550","117","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-14 15:47:04"),
("551","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-14 15:47:23"),
("552","117","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-14 15:48:05"),
("553","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-14 15:59:15"),
("554","116","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-14 16:07:53"),
("555","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-14 16:42:23"),
("556","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-14 16:43:11"),
("557","47","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-14 16:49:12"),
("558","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-14 16:57:33"),
("559","118","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-14 17:12:05"),
("560","66","188.70.49.4","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-14 17:22:56"),
("561","66","188.70.49.4","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-14 17:23:17"),
("562","119","188.70.49.4","development/YESWA/1.0","","1","0","","2018-05-14 17:24:36"),
("563","119","188.70.49.4","development/YESWA/1.0","","1","0","","2018-05-14 17:47:42"),
("564","116","103.54.102.131","development/YESWA/1.0","","1","0","","2018-05-15 09:55:38"),
("565","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-15 14:58:51"),
("566","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-15 17:13:43"),
("567","117","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-15 17:46:09"),
("568","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-15 17:47:05"),
("569","117","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-15 17:51:47"),
("570","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-15 17:53:38"),
("571","117","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-15 18:12:40"),
("572","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-15 18:21:55"),
("573","120","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-15 18:35:03"),
("574","120","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-15 18:49:32"),
("575","119","188.71.213.196","development/YESWA/1.0","","1","0","","2018-05-16 01:08:44"),
("576","117","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-17 09:51:42"),
("577","123","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-17 10:05:27"),
("578","123","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-17 11:19:58"),
("579","123","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-17 14:37:30"),
("580","1","61.246.7.159","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_1) AppleWebKit/604.3.5 (KHTML, like Gecko) Version/11.0.1 Safari/604.3.5","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-05-17 14:55:18"),
("581","1","61.246.7.159","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_1) AppleWebKit/604.3.5 (KHTML, like Gecko) Version/11.0.1 Safari/604.3.5","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-05-17 14:56:12"),
("582","123","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-17 15:06:05"),
("583","123","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-17 15:06:14"),
("584","123","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-17 15:36:54"),
("585","123","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-17 15:38:10"),
("586","123","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-17 16:07:50"),
("587","123","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-17 16:09:44"),
("588","123","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-17 16:10:56"),
("589","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-17 16:37:22"),
("590","116","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-17 16:40:55"),
("591","116","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-17 16:41:01"),
("592","116","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-17 16:41:16"),
("593","123","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-17 18:15:03"),
("594","127","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 15:20:00"),
("595","128","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 15:25:44"),
("596","128","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 15:30:19"),
("597","123","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 16:59:58"),
("598","123","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 17:04:44"),
("599","128","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 17:06:54"),
("600","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 17:14:08"),
("601","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 17:20:42"),
("602","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 17:22:50"),
("603","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 17:26:13"),
("604","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 17:27:54"),
("605","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 17:33:26"),
("606","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 17:34:23");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_login_history` (`id`,`user_id`,`user_ip`,`user_agent`,`failer_reason`,`state_id`,`type_id`,`code`,`created_on`) VALUES
("607","127","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 17:35:28"),
("608","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 17:37:20"),
("609","128","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 17:38:40"),
("610","47","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","","1","0","","2018-05-18 17:39:16"),
("611","47","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","","1","0","","2018-05-18 17:39:38"),
("612","47","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","","1","0","","2018-05-18 17:39:50"),
("613","47","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","","1","0","","2018-05-18 17:40:27"),
("614","47","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","","1","0","","2018-05-18 17:41:21"),
("615","47","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","","1","0","","2018-05-18 17:42:07"),
("616","47","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","","1","0","","2018-05-18 17:43:37"),
("617","47","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36","","1","0","","2018-05-18 17:48:13"),
("618","129","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 17:50:39"),
("619","129","61.246.7.159","development/YESWA/1.0","","1","0","","2018-05-18 17:51:22"),
("620","130","188.71.255.61","development/YESWA/1.0","","1","0","","2018-05-21 16:39:42"),
("621","119","188.71.255.61","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-05-21 16:48:44"),
("622","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-06-19 10:26:31"),
("623","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://jupiter.ozvid.in/yeswa/user/login","2018-06-19 10:26:41"),
("624","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36","","1","0","http://jupiter.ozvid.in/yeswa/user/login","2018-06-19 10:26:47"),
("625","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36","","1","0","http://yeswa.shop/user/login","2018-06-19 05:40:02"),
("626","131","103.41.26.30","development/YESWA/1.0","","1","0","","2018-06-19 08:37:07"),
("627","132","103.41.26.30","development/YESWA/1.0","","1","0","","2018-06-19 08:45:45"),
("628","132","103.41.26.30","development/YESWA/1.0","","1","0","","2018-06-19 08:47:39"),
("629","132","103.41.26.30","development/YESWA/1.0","","1","0","","2018-06-19 08:55:04"),
("630","133","103.41.26.30","development/YESWA/1.0","","1","0","","2018-06-19 09:01:29"),
("631","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://yeswa.shop/user/login","2018-06-19 09:09:16"),
("632","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36","","1","0","http://yeswa.shop/user/login","2018-06-19 09:09:23"),
("633","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0","","1","0","http://yeswa.shop/user/login","2018-06-19 09:13:49"),
("634","134","103.41.26.30","development/YESWA/1.0","","1","0","","2018-06-19 09:23:56"),
("635","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36","","1","0","http://yeswa.shop/user/login","2018-06-19 09:36:44"),
("636","135","103.41.26.30","development/YESWA/1.0","","1","0","","2018-06-19 09:38:03"),
("637","135","103.41.26.30","development/YESWA/1.0","","1","0","","2018-06-19 09:50:34"),
("638","133","103.41.26.30","development/YESWA/1.0","","1","0","","2018-06-19 09:56:37"),
("639","132","103.41.26.30","development/YESWA/1.0","","1","0","","2018-06-19 09:59:05"),
("640","133","103.41.26.30","development/YESWA/1.0","","1","0","","2018-06-19 10:00:15"),
("641","132","103.41.26.30","development/YESWA/1.0","","1","0","","2018-06-19 10:04:52"),
("642","133","103.41.26.30","development/YESWA/1.0","","1","0","","2018-06-19 10:17:50"),
("643","136","103.41.26.30","development/YESWA/1.0","","1","0","","2018-06-19 10:21:25"),
("644","131","103.41.26.30","development/YESWA/1.0","","1","0","","2018-06-19 10:23:32"),
("645","137","37.38.243.134","development/YESWA/1.0","","1","0","","2018-06-20 07:45:25"),
("646","1","61.246.7.159","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.1 Safari/605.1.15","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://yeswa.shop/user/login","2018-06-26 07:02:13"),
("647","1","61.246.7.159","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.1 Safari/605.1.15","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://yeswa.shop/user/login","2018-06-26 07:02:25"),
("648","1","61.246.7.159","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.1 Safari/605.1.15","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://yeswa.shop/user/login","2018-06-26 07:02:51"),
("649","1","61.246.7.159","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.1 Safari/605.1.15","","1","0","http://yeswa.shop/user/login","2018-06-26 07:03:10"),
("650","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-26 07:09:09"),
("651","138","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-26 07:12:24"),
("652","138","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-26 07:20:28"),
("653","139","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-26 07:24:05"),
("654","140","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-26 07:31:57"),
("655","47","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-26 09:38:12"),
("656","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36","","1","0","http://yeswa.shop/user/login","2018-06-26 09:47:29"),
("657","141","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-27 04:33:58"),
("658","141","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-27 04:58:01"),
("659","141","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-27 05:37:41"),
("660","15","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-27 06:46:33"),
("661","141","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-27 06:48:47"),
("662","62","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-06-27 06:51:29"),
("663","62","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-06-27 06:51:37"),
("664","85","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-27 06:54:43"),
("665","141","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-27 06:56:00"),
("666","85","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-27 09:26:15"),
("667","141","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-27 09:27:30"),
("668","142","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-27 10:30:37"),
("669","85","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-27 10:37:49"),
("670","143","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-06-27 10:53:09"),
("671","143","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-27 10:53:19"),
("672","141","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-06-27 11:37:29"),
("673","141","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-27 11:37:39"),
("674","85","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-27 13:26:32"),
("675","144","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-27 13:58:21"),
("676","145","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-06-27 14:10:07"),
("677","145","61.246.7.159","development/YESWA/1.0","","1","0","","2018-06-27 14:10:20"),
("678","146","188.71.200.190","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-07-01 12:56:23"),
("679","146","188.71.200.190","development/YESWA/1.0","","1","0","","2018-07-01 12:56:30"),
("680","147","188.71.240.26","development/YESWA/1.0","","1","0","","2018-07-02 11:42:34"),
("681","147","188.71.240.26","development/YESWA/1.0","","1","0","","2018-07-02 13:34:39"),
("682","147","188.71.240.26","development/YESWA/1.0","","1","0","","2018-07-02 13:39:18"),
("683","1","103.41.26.188","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-02 13:43:40"),
("684","1","103.41.26.188","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-02 13:44:05"),
("685","1","103.41.26.188","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-02 13:44:48"),
("686","1","103.41.26.188","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-02 13:44:54"),
("687","1","103.41.26.188","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-02 13:46:42"),
("688","1","103.41.26.188","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-02 13:47:25"),
("689","1","103.41.26.188","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-02 13:47:29"),
("690","1","103.41.26.188","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-02 13:50:35"),
("691","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-02 13:53:35"),
("692","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-02 13:53:41"),
("693","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-02 13:53:44"),
("694","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-02 13:53:48"),
("695","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0","","1","0","http://yeswa.shop/user/login","2018-07-02 14:00:59"),
("696","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://yeswa.shop/user/login","2018-07-02 14:01:15"),
("697","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0","","1","0","http://yeswa.shop/user/login","2018-07-02 14:01:19"),
("698","1","103.41.26.188","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://yeswa.shop/user/login","2018-07-02 14:01:55"),
("699","1","168.187.65.119","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://yeswa.shop/user/login","2018-07-02 14:03:51"),
("700","1","103.41.26.188","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://yeswa.shop/user/login","2018-07-04 09:01:14"),
("701","1","103.41.26.188","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","","1","0","http://yeswa.shop/user/login","2018-07-04 09:01:26"),
("702","1","103.41.26.188","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0","","1","0","http://yeswa.shop/user/login","2018-07-04 09:26:20"),
("703","148","103.41.26.164","development/YESWA/1.0","","1","0","","2018-07-05 04:08:52"),
("704","148","103.41.26.164","development/YESWA/1.0","","1","0","","2018-07-05 04:10:56"),
("705","149","103.41.26.164","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-07-05 05:08:26"),
("706","149","103.41.26.164","development/YESWA/1.0","","1","0","","2018-07-05 05:08:33");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_login_history` (`id`,`user_id`,`user_ip`,`user_agent`,`failer_reason`,`state_id`,`type_id`,`code`,`created_on`) VALUES
("707","149","103.41.26.164","development/YESWA/1.0","","1","0","","2018-07-05 05:16:45"),
("708","148","103.41.26.164","development/YESWA/1.0","","1","0","","2018-07-05 05:17:21"),
("709","149","103.41.26.164","development/YESWA/1.0","","1","0","","2018-07-05 05:24:58"),
("710","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-05 05:29:12"),
("711","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-05 05:29:17"),
("712","148","103.41.26.164","development/YESWA/1.0","","1","0","","2018-07-05 06:26:55"),
("713","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0","","1","0","http://yeswa.shop/user/login","2018-07-05 08:55:32"),
("714","1","103.41.26.164","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0","","1","0","http://yeswa.shop/user/login","2018-07-06 07:43:22"),
("715","150","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-06 11:22:38"),
("716","151","103.41.26.164","development/YESWA/1.0","","1","0","","2018-07-06 11:29:05"),
("717","150","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-06 11:44:55"),
("718","150","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-06 11:53:49"),
("719","152","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-06 12:04:31"),
("720","149","103.41.26.164","development/YESWA/1.0","","1","0","","2018-07-06 12:16:27"),
("721","147","188.70.0.222","development/YESWA/1.0","","1","0","","2018-07-06 12:51:48"),
("722","147","188.70.0.222","development/YESWA/1.0","","1","0","","2018-07-06 13:01:51"),
("723","153","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-09 04:22:10"),
("724","154","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-09 06:20:31"),
("725","155","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-09 06:30:11"),
("726","148","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-09 06:44:25"),
("727","156","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-09 06:52:38"),
("728","157","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-09 07:05:41"),
("729","158","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-09 07:11:31"),
("730","158","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-09 07:27:50"),
("731","158","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-09 07:46:41"),
("732","158","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-09 07:58:33"),
("733","1","103.41.26.236","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-09 08:39:10"),
("734","1","103.41.26.236","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://yeswa.shop/user/login","2018-07-09 08:40:32"),
("735","1","103.41.26.236","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://yeswa.shop/user/login","2018-07-09 08:40:40"),
("736","158","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-09 09:26:37"),
("737","159","49.34.76.139","development/YESWA/1.0","","1","0","","2018-07-09 09:49:15"),
("738","160","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 10:26:27"),
("739","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 10:28:05"),
("740","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 10:28:37"),
("741","161","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 11:15:16"),
("742","1","103.41.26.236","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-10 11:27:09"),
("743","1","103.41.26.236","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-10 11:27:16"),
("744","162","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 11:32:07"),
("745","1","103.41.26.236","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://yeswa.shop/user/login","2018-07-10 11:39:09"),
("746","1","103.41.26.236","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","","1","0","http://yeswa.shop/user/login","2018-07-10 11:39:19"),
("747","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 11:57:35"),
("748","161","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 11:59:47"),
("749","163","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 12:01:06"),
("750","162","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 12:03:43"),
("751","163","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 12:21:33"),
("752","164","103.41.26.236","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-07-10 12:28:41"),
("753","164","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 12:28:57"),
("754","163","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 12:32:16"),
("755","162","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 12:35:51"),
("756","162","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 12:40:34"),
("757","161","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 12:44:45"),
("758","162","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 12:49:06"),
("759","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 12:53:55"),
("760","161","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 12:56:11"),
("761","161","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-10 13:38:06"),
("762","147","188.70.20.97","development/YESWA/1.0","","1","0","","2018-07-11 10:39:22"),
("763","147","188.70.20.97","development/YESWA/1.0","","1","0","","2018-07-11 10:49:48"),
("764","147","188.70.20.97","development/YESWA/1.0","","1","0","","2018-07-11 10:55:18"),
("765","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-12 09:16:14"),
("766","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-12 09:34:14"),
("767","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-12 10:23:10"),
("768","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-12 10:35:36"),
("769","165","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-12 12:05:54"),
("770","166","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-12 12:10:33"),
("771","147","188.70.28.146","development/YESWA/1.0","","1","0","","2018-07-12 12:38:15"),
("772","147","188.70.28.146","development/YESWA/1.0","","1","0","","2018-07-12 13:11:59"),
("773","147","188.70.28.146","development/YESWA/1.0","","1","0","","2018-07-12 13:19:06"),
("774","147","188.70.28.146","development/YESWA/1.0","","1","0","","2018-07-12 13:56:38"),
("775","147","188.70.28.146","development/YESWA/1.0","","1","0","","2018-07-12 13:58:36"),
("776","147","188.70.28.146","development/YESWA/1.0","","1","0","","2018-07-12 14:00:42"),
("777","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-13 05:26:31"),
("778","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-13 05:49:03"),
("779","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-13 05:51:29"),
("780","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-13 06:01:21"),
("781","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-13 06:07:03"),
("782","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-13 06:15:20"),
("783","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-13 06:18:22"),
("784","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-13 06:31:00"),
("785","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-13 07:24:31"),
("786","149","103.41.26.236","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-07-13 09:10:09"),
("787","149","103.41.26.236","development/YESWA/1.0","","1","0","","2018-07-13 09:10:20"),
("788","149","61.246.7.159","PostmanRuntime/7.1.5","","1","0","","2018-07-13 10:57:50"),
("789","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-13 11:08:43"),
("790","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-16 06:26:09"),
("791","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-17 05:12:20"),
("792","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-17 05:12:49"),
("793","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-17 06:25:42"),
("794","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-17 06:25:52"),
("795","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","","1","0","http://yeswa.shop/user/login","2018-07-17 06:26:38"),
("796","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","","1","0","http://yeswa.shop/user/login","2018-07-18 09:06:45"),
("797","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-18 11:31:35"),
("798","149","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","1","http://yeswa.shop/api","2018-07-18 11:38:50"),
("799","149","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","1","http://yeswa.shop/api","2018-07-18 11:39:34"),
("800","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-18 11:43:37"),
("801","149","103.41.26.87","development/YESWA/1.0","","1","0","","2018-07-18 11:54:25"),
("802","149","103.41.26.87","development/YESWA/1.0","","1","0","","2018-07-18 12:24:20"),
("803","2","103.41.26.87","development/YESWA/1.0","","1","0","","2018-07-18 12:31:41"),
("804","167","103.41.26.87","development/YESWA/1.0","","1","0","","2018-07-18 13:20:44"),
("805","167","103.41.26.87","development/YESWA/1.0","","1","0","","2018-07-18 13:43:25"),
("806","147","188.71.193.26","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-07-18 14:48:15");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_login_history` (`id`,`user_id`,`user_ip`,`user_agent`,`failer_reason`,`state_id`,`type_id`,`code`,`created_on`) VALUES
("807","147","188.71.193.26","development/YESWA/1.0","","1","0","","2018-07-18 14:48:27"),
("808","168","188.70.19.56","development/YESWA/1.0","","1","0","","2018-07-22 13:56:31"),
("809","147","188.70.19.56","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-07-22 13:59:02"),
("810","147","188.70.19.56","development/YESWA/1.0","","1","0","","2018-07-22 13:59:13"),
("811","149","103.41.26.183","development/YESWA/1.0","","1","0","","2018-07-23 06:55:18"),
("812","149","103.41.26.183","development/YESWA/1.0","","1","0","","2018-07-23 07:41:22"),
("813","149","103.41.26.183","development/YESWA/1.0","","1","0","","2018-07-23 09:26:12"),
("814","2","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-24 05:08:30"),
("815","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-24 05:16:37"),
("816","171","103.41.26.252","development/YESWA/1.0","","1","0","","2018-07-26 07:25:07"),
("817","172","103.41.26.252","development/YESWA/1.0","","1","0","","2018-07-26 10:19:40"),
("818","173","188.70.32.66","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-07-26 14:31:04"),
("819","173","188.70.32.66","development/YESWA/1.0","","1","0","","2018-07-26 14:31:13"),
("820","171","103.41.26.252","development/YESWA/1.0","","1","0","","2018-07-27 11:23:09"),
("821","172","103.41.26.252","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-07-27 11:24:41"),
("822","172","103.41.26.252","development/YESWA/1.0","","1","0","","2018-07-27 11:24:52"),
("823","171","103.41.26.252","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-07-27 11:48:01"),
("824","171","103.41.26.252","development/YESWA/1.0","","1","0","","2018-07-27 11:48:12"),
("825","1","103.41.26.252","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-07-27 13:14:30"),
("826","149","103.41.26.252","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-07-27 13:24:15"),
("827","149","103.41.26.252","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-07-27 13:24:24"),
("828","149","103.41.26.252","development/YESWA/1.0","","1","0","","2018-07-27 13:25:32"),
("829","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-30 06:14:52"),
("830","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-31 10:58:41"),
("831","172","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-07-31 10:59:56"),
("832","172","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-31 11:00:22"),
("833","149","61.246.7.159","development/YESWA/1.0/en","","1","0","","2018-07-31 12:04:53"),
("834","172","61.246.7.159","development/YESWA/1.0/ar","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-07-31 12:43:29"),
("835","172","61.246.7.159","development/YESWA/1.0/ar","","1","0","","2018-07-31 12:43:37"),
("836","149","61.246.7.159","development/YESWA/1.0/en","","1","0","","2018-07-31 13:03:25"),
("837","149","61.246.7.159","development/YESWA/1.0/en","","1","0","","2018-07-31 13:04:04"),
("838","149","61.246.7.159","development/YESWA/1.0/en","","1","0","","2018-07-31 13:06:03"),
("839","149","61.246.7.159","development/YESWA/1.0/en","","1","0","","2018-07-31 13:07:54"),
("840","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-31 13:09:38"),
("841","172","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-31 13:10:01"),
("842","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-31 13:14:14"),
("843","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-07-31 13:16:41"),
("844","172","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-01 05:33:06"),
("845","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-01 05:34:35"),
("846","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-01 05:36:22"),
("847","174","103.41.26.94","development/YESWA/1.0","","1","0","","2018-08-01 08:57:10"),
("848","176","103.41.26.94","development/YESWA/1.0","","1","0","","2018-08-01 09:29:37"),
("849","176","103.41.26.94","development/YESWA/1.0","","1","0","","2018-08-01 09:30:56"),
("850","174","103.41.26.94","development/YESWA/1.0","","1","0","","2018-08-01 09:47:10"),
("851","1","188.70.40.72","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-08-01 12:06:13"),
("852","1","188.70.40.72","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36","","1","0","http://yeswa.shop/user/login","2018-08-01 12:06:29"),
("853","172","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-08-02 04:39:47"),
("854","172","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-02 04:39:54"),
("855","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-02 06:10:02"),
("856","172","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-02 06:19:13"),
("857","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-02 06:37:36"),
("858","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-02 06:39:51"),
("859","171","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-08-02 06:47:14"),
("860","171","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-02 06:47:20"),
("861","177","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-02 10:27:37"),
("862","178","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-02 10:52:23"),
("863","180","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-02 11:23:21"),
("864","171","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-08-02 11:34:03"),
("865","171","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-02 11:34:12"),
("866","184","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-03 09:16:15"),
("867","147","188.70.25.72","development/YESWA/1.0","","1","0","","2018-08-04 08:41:07"),
("868","185","46.186.212.68","development/YESWA/1.0","","1","0","","2018-08-04 22:11:33"),
("869","186","46.186.212.68","development/YESWA/1.0","","1","0","","2018-08-04 22:22:45"),
("870","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-06 06:33:20"),
("871","181","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-08-06 06:36:04"),
("872","187","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-06 06:41:29"),
("873","188","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-06 09:04:54"),
("874","189","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-06 09:09:14"),
("875","190","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-06 09:42:19"),
("876","191","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-06 09:46:44"),
("877","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-06 09:54:33"),
("878","192","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-06 10:18:32"),
("879","193","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-06 10:30:57"),
("880","194","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-08-06 10:32:16"),
("881","194","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-08-06 10:32:25"),
("882","194","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-08-06 10:32:33"),
("883","194","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-08-06 10:32:39"),
("884","195","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-06 11:00:29"),
("885","147","188.70.8.163","development/YESWA/1.0","","1","0","","2018-08-07 07:25:54"),
("886","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-08 05:50:08"),
("887","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-08 06:03:53"),
("888","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-08 06:21:11"),
("889","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-08 06:54:23"),
("890","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-08-08 10:05:20"),
("891","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-08-08 10:05:41"),
("892","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://yeswa.shop/user/login","2018-08-08 10:06:31"),
("893","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36","","1","0","http://yeswa.shop/user/login","2018-08-08 10:06:38"),
("894","195","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://yeswa.shop/user/login","2018-08-08 10:40:49"),
("895","195","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.84 Safari/537.36","","1","0","http://yeswa.shop/user/login","2018-08-08 10:40:56"),
("896","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-08 11:57:46"),
("897","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-09 04:14:02"),
("898","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-09 04:33:33"),
("899","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-09 04:34:40"),
("900","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-09 11:48:02"),
("901","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-09 11:48:31"),
("902","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-09 12:11:38"),
("903","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 04:02:28"),
("904","197","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 04:07:38"),
("905","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 04:22:21"),
("906","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://yeswa.shop/user/login","2018-08-10 05:14:21");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_login_history` (`id`,`user_id`,`user_ip`,`user_agent`,`failer_reason`,`state_id`,`type_id`,`code`,`created_on`) VALUES
("907","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","","1","0","http://yeswa.shop/user/login","2018-08-10 05:14:27"),
("908","197","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 05:40:21"),
("909","197","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 06:01:43"),
("910","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 07:14:20"),
("911","149","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-08-10 07:14:41"),
("912","149","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 07:14:48"),
("913","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 07:20:30"),
("914","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 07:43:50"),
("915","197","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 07:46:35"),
("916","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 09:31:46"),
("917","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 09:34:17"),
("918","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 09:41:52"),
("919","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 09:42:50"),
("920","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 09:45:44"),
("921","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 09:46:05"),
("922","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 10:25:29"),
("923","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 10:27:49"),
("924","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 10:30:46"),
("925","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-10 10:49:56"),
("926","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-13 04:59:49"),
("927","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-13 13:00:16"),
("928","198","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-08-14 04:05:18"),
("929","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 04:05:28"),
("930","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36","{\"username\":[\"Incorrect Email.\"]}","0","0","http://yeswa.shop/user/login","2018-08-14 05:09:46"),
("931","1","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36","","1","0","http://yeswa.shop/user/login","2018-08-14 05:09:56"),
("932","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 06:01:17"),
("933","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 06:03:26"),
("934","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 06:05:18"),
("935","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 07:02:33"),
("936","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 07:07:17"),
("937","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 07:07:43"),
("938","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 07:15:48"),
("939","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 07:24:38"),
("940","198","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-08-14 07:29:46"),
("941","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 07:29:58"),
("942","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 08:59:23"),
("943","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 09:11:58"),
("944","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 09:27:33"),
("945","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 09:29:10"),
("946","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 09:31:24"),
("947","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 11:00:54"),
("948","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 11:09:08"),
("949","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 11:25:09"),
("950","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 11:30:48"),
("951","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-14 11:33:04"),
("952","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-16 08:51:52"),
("953","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-16 09:09:09"),
("954","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-16 09:18:21"),
("955","199","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-16 13:00:45"),
("956","200","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-16 13:05:25"),
("957","199","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-16 13:14:05"),
("958","200","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-16 13:21:18"),
("959","199","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-16 13:23:52"),
("960","199","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-16 13:40:49"),
("961","199","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-16 13:40:56"),
("962","199","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-16 13:51:59"),
("963","200","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-16 13:52:21"),
("964","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-17 04:15:23"),
("965","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-17 04:24:22"),
("966","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://yeswa.shop/user/login","2018-08-17 10:41:12"),
("967","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","","1","0","http://yeswa.shop/user/login","2018-08-17 10:41:28"),
("968","174","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-21 14:06:53"),
("969","200","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-21 14:12:33"),
("970","174","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-21 14:16:52"),
("971","200","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-21 14:24:11"),
("972","174","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-21 14:27:12"),
("973","200","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-21 14:28:45"),
("974","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-22 04:23:58"),
("975","200","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-22 04:25:45"),
("976","174","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-22 04:26:44"),
("977","200","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-22 04:28:50"),
("978","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-22 04:39:53"),
("979","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-22 04:41:02"),
("980","174","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-22 04:42:44"),
("981","174","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-22 04:45:36"),
("982","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://yeswa.shop/user/login","2018-08-22 05:08:32"),
("983","1","61.246.7.159","Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:61.0) Gecko/20100101 Firefox/61.0","","1","0","http://yeswa.shop/user/login","2018-08-22 05:08:38"),
("984","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-22 06:32:49"),
("985","196","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-22 06:33:30"),
("986","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-22 06:34:47"),
("987","174","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://yeswa.shop/user/login","2018-08-22 06:48:43"),
("988","174","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://yeswa.shop/user/login","2018-08-22 06:48:53"),
("989","174","61.246.7.159","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36","{\"password\":[\"Incorrect username or password.\"]}","0","0","http://yeswa.shop/user/login","2018-08-22 06:48:59"),
("990","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-22 09:15:23"),
("991","198","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-22 09:31:25"),
("992","201","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 04:05:48"),
("993","202","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 05:07:12"),
("994","201","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 05:08:28"),
("995","201","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 05:51:53"),
("996","202","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 06:13:36"),
("997","201","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 06:19:30"),
("998","203","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 09:35:58"),
("999","200","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 09:42:53"),
("1000","203","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 09:56:52"),
("1001","200","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 10:03:00"),
("1002","203","61.246.7.159","development/YESWA/1.0","{\"password\":[\"Incorrect username or password.\"]}","0","0","","2018-08-23 10:05:34"),
("1003","200","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 10:05:42"),
("1004","203","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 10:05:52"),
("1005","201","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 10:08:57"),
("1006","201","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 10:18:59");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_login_history` (`id`,`user_id`,`user_ip`,`user_agent`,`failer_reason`,`state_id`,`type_id`,`code`,`created_on`) VALUES
("1007","202","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 10:20:53"),
("1008","201","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 10:22:40"),
("1009","202","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 10:23:42"),
("1010","201","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 10:27:40"),
("1011","200","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 11:01:05"),
("1012","203","61.246.7.159","development/YESWA/1.0","","1","0","","2018-08-23 11:02:33");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_notification` (`id`,`to_user_id`,`model_id`,`model_type`,`message`,`state_id`,`type_id`,`created_on`,`created_by_id`) VALUES
("1","201","427","app\\models\\Order","New Order Recieved","1","","2018-08-23 10:21:18","202"),
("2","201","428","app\\models\\Order","New Order Recieved","1","","2018-08-23 10:24:15","202"),
("3","201","429","app\\models\\Order","New Order Recieved","1","","2018-08-23 10:25:49","203"),
("4","200","430","app\\models\\Order","New Order Recieved","1","","2018-08-23 11:03:36","203"),
("5","1","431","app\\models\\Order","New Order Recieved","1","","2018-08-23 11:18:13","203");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_order` (`id`,`super_order_id`,`vendor_id`,`shipping_charge`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("53","91","109","99","4","0","2018-05-14 17:13:58","2018-05-14 17:13:58","118"),
("54","92","117","99","1","0","2018-05-14 17:17:30","2018-05-14 17:17:30","118"),
("66","103","128","","1","0","2018-06-19 08:37:50","2018-06-19 08:37:50","131"),
("67","104","132","","3","0","2018-06-19 09:57:30","2018-06-19 09:59:29","133"),
("68","104","132","","6","0","2018-06-19 09:57:30","2018-06-19 09:59:42","133"),
("69","105","136","","1","0","2018-06-19 10:24:54","2018-06-19 10:24:54","131"),
("70","106","136","","1","0","2018-06-20 07:46:19","2018-06-20 07:46:19","137"),
("71","107","136","","1","0","2018-06-22 15:14:52","2018-06-22 15:14:52","137"),
("73","109","142","","1","0","2018-06-27 10:56:10","2018-06-27 10:56:10","143"),
("75","111","142","","1","0","2018-06-27 14:11:22","2018-06-27 14:11:22","145"),
("76","112","137","","1","0","2018-07-01 13:00:47","2018-07-01 13:00:47","146"),
("77","113","137","","1","0","2018-07-02 11:47:41","2018-07-02 11:47:41","147"),
("78","113","137","","1","0","2018-07-02 11:47:41","2018-07-02 11:47:41","147"),
("81","116","149","","6","0","2018-07-05 12:41:21","2018-07-30 05:32:37","1"),
("83","118","147","","1","0","2018-07-06 11:56:35","2018-07-06 11:56:35","150"),
("86","121","137","","1","0","2018-07-22 14:01:59","2018-07-22 14:01:59","147"),
("87","121","147","","6","0","2018-07-22 14:01:59","2018-07-22 14:02:36","147"),
("88","121","152","","1","0","2018-07-22 14:01:59","2018-07-22 14:01:59","147"),
("98","126","185","","1","0","2018-08-04 22:24:10","2018-08-04 22:24:10","186"),
("103","129","109","","1","0","2018-08-08 11:13:17","2018-08-08 11:13:17","113"),
("104","130","109","","1","0","2018-08-08 11:15:07","2018-08-08 11:15:07","113"),
("105","131","109","","1","0","2018-08-08 11:18:13","2018-08-08 11:18:13","113"),
("106","132","109","","1","0","2018-08-08 12:57:15","2018-08-08 12:57:15","113"),
("107","133","109","","1","0","2018-08-08 13:09:05","2018-08-08 13:09:05","113"),
("108","134","109","","1","0","2018-08-08 13:12:36","2018-08-08 13:12:36","113"),
("109","135","109","","1","0","2018-08-08 13:14:18","2018-08-08 13:14:18","113"),
("110","135","109","","1","0","2018-08-08 13:14:19","2018-08-08 13:14:19","113"),
("116","141","149","","1","0","2018-08-10 05:43:41","2018-08-10 05:43:41","113"),
("117","142","149","","1","0","2018-08-10 05:44:05","2018-08-10 05:44:05","113"),
("118","143","149","","1","0","2018-08-10 05:46:30","2018-08-10 05:46:30","113"),
("119","144","149","","1","0","2018-08-10 05:47:00","2018-08-10 05:47:00","113"),
("125","150","149","","1","0","2018-08-10 09:00:39","2018-08-10 09:00:39","113"),
("126","151","149","","1","0","2018-08-10 09:01:00","2018-08-10 09:01:00","113"),
("127","152","149","","1","0","2018-08-10 09:01:56","2018-08-10 09:01:56","113"),
("128","153","149","","1","0","2018-08-10 09:02:55","2018-08-10 09:02:55","113"),
("129","154","149","","1","0","2018-08-10 09:03:42","2018-08-10 09:03:42","113"),
("132","157","149","","1","0","2018-08-10 09:26:48","2018-08-10 09:26:48","113"),
("133","158","149","","1","0","2018-08-10 09:28:11","2018-08-10 09:28:11","113"),
("134","159","149","","1","0","2018-08-10 09:29:09","2018-08-10 09:29:09","113"),
("136","161","149","","1","0","2018-08-10 09:36:40","2018-08-10 09:36:40","113"),
("137","162","149","","1","0","2018-08-10 09:37:39","2018-08-10 09:37:39","198"),
("138","163","149","","1","0","2018-08-10 09:38:36","2018-08-10 09:38:36","198"),
("139","164","149","","1","0","2018-08-10 09:40:01","2018-08-10 09:40:01","198"),
("249","270","200","","3","0","2018-08-16 13:16:54","2018-08-21 14:29:40","199"),
("250","271","200","","6","0","2018-08-16 13:34:50","2018-08-16 13:34:50","199"),
("251","272","200","","6","0","2018-08-16 13:38:19","2018-08-16 13:38:19","199"),
("253","289","1","","1","0","2018-08-21 08:59:53","2018-08-21 08:59:53","198"),
("254","290","1","","1","0","2018-08-21 09:00:54","2018-08-21 09:00:54","198"),
("255","292","149","","1","0","2018-08-21 09:05:10","2018-08-21 09:05:10","198"),
("256","293","149","","1","0","2018-08-21 09:05:51","2018-08-21 09:05:51","198"),
("257","294","149","","1","0","2018-08-21 09:05:59","2018-08-21 09:05:59","198"),
("258","295","149","","1","0","2018-08-21 09:06:21","2018-08-21 09:06:21","198"),
("259","296","149","","1","0","2018-08-21 09:09:00","2018-08-21 09:09:00","198"),
("260","297","149","","1","0","2018-08-21 09:11:09","2018-08-21 09:11:09","198"),
("261","298","149","","1","0","2018-08-21 09:11:29","2018-08-21 09:11:29","198"),
("262","299","149","","1","0","2018-08-21 09:12:17","2018-08-21 09:12:17","198"),
("263","300","149","","1","0","2018-08-21 09:15:51","2018-08-21 09:15:51","198"),
("264","301","149","","1","0","2018-08-21 09:16:52","2018-08-21 09:16:52","198"),
("265","302","149","","1","0","2018-08-21 09:23:54","2018-08-21 09:23:54","198"),
("266","303","149","","1","0","2018-08-21 09:36:44","2018-08-21 09:36:44","198"),
("267","303","109","","1","0","2018-08-21 09:36:44","2018-08-21 09:36:44","198"),
("268","304","149","","1","0","2018-08-21 09:37:21","2018-08-21 09:37:21","198"),
("269","304","109","","1","0","2018-08-21 09:37:21","2018-08-21 09:37:21","198"),
("270","305","149","","1","0","2018-08-21 09:44:38","2018-08-21 09:44:38","198"),
("271","305","109","","1","0","2018-08-21 09:44:38","2018-08-21 09:44:38","198"),
("272","305","109","","1","0","2018-08-21 09:44:38","2018-08-21 09:44:38","198"),
("273","306","149","","1","0","2018-08-21 09:58:29","2018-08-21 09:58:29","198"),
("274","306","109","","1","0","2018-08-21 09:58:29","2018-08-21 09:58:29","198"),
("275","306","109","","1","0","2018-08-21 09:58:29","2018-08-21 09:58:29","198"),
("276","306","152","","1","0","2018-08-21 09:58:29","2018-08-21 09:58:29","198"),
("418","376","201","","6","0","2018-08-23 05:12:03","2018-08-23 05:12:26","202"),
("419","377","201","","3","0","2018-08-23 05:17:56","2018-08-23 05:35:03","202"),
("420","378","201","","6","0","2018-08-23 05:36:59","2018-08-23 06:12:36","202"),
("421","378","201","","3","0","2018-08-23 05:37:00","2018-08-23 06:12:19","202"),
("422","379","200","","6","0","2018-08-23 09:40:24","2018-08-23 09:44:00","203"),
("423","380","200","","1","0","2018-08-23 10:04:08","2018-08-23 10:04:08","203"),
("424","381","200","","1","0","2018-08-23 10:06:52","2018-08-23 10:06:52","203"),
("425","381","200","","1","0","2018-08-23 10:06:54","2018-08-23 10:06:54","203"),
("426","382","201","","1","0","2018-08-23 10:09:25","2018-08-23 10:09:25","203"),
("427","383","201","","1","0","2018-08-23 10:21:18","2018-08-23 10:21:18","202"),
("428","384","201","","6","0","2018-08-23 10:24:15","2018-08-23 10:24:48","202"),
("429","385","201","","6","0","2018-08-23 10:25:49","2018-08-23 10:26:01","203"),
("430","386","200","","6","0","2018-08-23 11:03:36","2018-08-23 11:04:03","203"),
("431","387","1","","1","0","2018-08-23 11:18:13","2018-08-23 11:18:13","203");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_order_cancel` (`id`,`order_id`,`subject`,`reason`,`type_id`,`state_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("4","117","","","0","0","2018-07-06 10:12:55","2018-07-06 10:12:55","148");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_order_item` (`id`,`order_id`,`product_id`,`product_variant_id`,`quantity`,`amount`,`expected_delivery_date`,`type_id`,`state_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("107","53","69","20","1","3999","2018-05-14 00:00:00","0","0","2018-05-14 17:13:58","2018-05-14 17:13:58","118"),
("127","73","87","42","2","5174","2018-06-27 00:00:00","0","0","2018-06-27 10:56:10","2018-06-27 10:56:10","143"),
("129","75","87","42","1","2587","2018-06-27 00:00:00","0","0","2018-06-27 14:11:22","2018-06-27 14:11:22","145"),
("130","76","92","47","1","694","2018-07-01 00:00:00","0","0","2018-07-01 13:00:47","2018-07-01 13:00:47","146"),
("131","77","92","47","2","1388","2018-07-02 00:00:00","0","0","2018-07-02 11:47:41","2018-07-02 11:47:41","147"),
("132","78","92","47","3","2082","2018-07-02 00:00:00","0","0","2018-07-02 11:47:41","2018-07-02 11:47:41","147"),
("137","83","94","48","2","100","2018-07-06 00:00:00","0","0","2018-07-06 11:56:35","2018-07-06 11:56:35","150"),
("140","86","92","47","2","1388","2018-07-22 00:00:00","0","0","2018-07-22 14:01:59","2018-07-22 14:01:59","147"),
("141","87","94","48","3","150","2018-07-22 00:00:00","0","0","2018-07-22 14:01:59","2018-07-22 14:01:59","147"),
("142","88","103","53","1","5000","2018-07-22 00:00:00","0","0","2018-07-22 14:01:59","2018-07-22 14:01:59","147"),
("152","98","129","124","1","46","2018-08-04 00:00:00","0","0","2018-08-04 22:24:10","2018-08-04 22:24:10","186"),
("157","109","69","20","1","1","2018-08-08 00:00:00","0","0","2018-08-08 13:14:19","2018-08-08 13:14:19","113"),
("158","110","69","20","1","1","2018-08-08 00:00:00","0","0","2018-08-08 13:14:21","2018-08-08 13:14:21","113"),
("275","249","134","131","1","8500","2018-08-16 00:00:00","0","0","2018-08-16 13:16:55","2018-08-16 13:16:55","199"),
("276","250","134","131","1","8500","2018-08-16 00:00:00","0","0","2018-08-16 13:34:52","2018-08-16 13:34:52","199"),
("277","251","133","130","1","4800","2018-08-16 00:00:00","0","0","2018-08-16 13:38:20","2018-08-16 13:38:20","199"),
("297","418","137","135","2","450","2018-08-23 00:00:00","0","0","2018-08-23 05:12:05","2018-08-23 05:12:05","202"),
("298","419","137","135","1","225","2018-08-23 00:00:00","0","0","2018-08-23 05:17:57","2018-08-23 05:17:57","202"),
("299","420","137","135","1","225","2018-08-23 00:00:00","0","0","2018-08-23 05:37:00","2018-08-23 05:37:00","202"),
("300","421","138","136","1","50","2018-08-23 00:00:00","0","0","2018-08-23 05:37:01","2018-08-23 05:37:01","202"),
("301","422","136","134","1","2500","2018-08-23 00:00:00","0","0","2018-08-23 09:40:26","2018-08-23 09:40:26","203"),
("302","423","136","134","2","5000","2018-08-23 00:00:00","0","0","2018-08-23 10:04:11","2018-08-23 10:04:11","203"),
("303","424","136","134","1","2500","2018-08-23 00:00:00","0","0","2018-08-23 10:06:54","2018-08-23 10:06:54","203"),
("304","425","136","134","1","2500","2018-08-23 00:00:00","0","0","2018-08-23 10:06:56","2018-08-23 10:06:56","203"),
("305","426","137","135","1","225","2018-08-23 00:00:00","0","0","2018-08-23 10:09:27","2018-08-23 10:09:27","203"),
("306","427","137","135","1","225","2018-08-23 00:00:00","0","0","2018-08-23 10:21:19","2018-08-23 10:21:19","202"),
("307","428","137","135","1","225","2018-08-23 00:00:00","0","0","2018-08-23 10:24:16","2018-08-23 10:24:16","202"),
("308","429","137","135","1","225","2018-08-23 00:00:00","0","0","2018-08-23 10:25:50","2018-08-23 10:25:50","203"),
("309","430","136","134","3","7500","2018-08-23 00:00:00","0","0","2018-08-23 11:03:38","2018-08-23 11:03:38","203");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_page` (`id`,`title`,`description`,`extra_info`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("6","Privacy Policy","<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
","","1","0","2018-04-07 17:28:41","2018-04-07 17:28:41","1"),
("7","Terms & Conditions","<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
","","1","1","2018-04-07 17:30:54","2018-04-07 17:30:54","1"),
("8","About Us","<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
","","1","2","2018-04-07 17:31:05","2018-04-07 17:31:05","1"),
("9","Help","<p>Please feel free to contact us:</p>

<p>Contact Detail:&nbsp; Yeswaapplication@gmail.com</p>

<p>Call us at: +965 6508 2227 &nbsp;</p>

<p>you can also contact us with:</p>

<p>social media via&nbsp;</p>

<p><a href=\"https://mobile.twitter.com/yeswaapp\">Twitter</a></p>

<p><a href=\"https://www.instagram.com/yeswaapp\">instagram</a><br />
&nbsp;</p>
","","0","3","2018-04-30 11:42:57","2018-07-05 09:00:08","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_product` (`id`,`title`,`description`,`category_id`,`brand_id`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("69","wow brand","Sports t-shirts","13","116","1","0","2018-05-04 16:48:24","2018-05-04 16:48:24","109"),
("83","new product details","Asfasdfasdfadsf","4","149","1","0","2018-06-27 06:48:03","2018-06-27 06:48:03","15"),
("87","brand","Wow","12","160","1","0","2018-06-27 10:43:56","2018-06-27 10:43:56","142"),
("92","hh","Jjjjjjm","12","171","1","0","2018-06-27 14:35:45","2018-06-27 14:35:45","137"),
("94","hshah","Afafa","13","172","1","0","2018-07-02 13:25:28","2018-07-02 13:25:28","147"),
("95","Shrug","<p>Agafa</p>","13","174","0","0","2018-07-02 13:27:26","2018-08-10 05:21:28","147"),
("102","Armani jacket","Wow","13","174","1","0","2018-07-06 12:05:30","2018-07-06 12:05:30","152"),
("103","Armani","POI","4","176","1","0","2018-07-06 12:09:25","2018-07-06 12:09:25","152"),
("104","Pepso","Wow","12","175","1","0","2018-07-06 12:10:42","2018-07-06 12:10:42","152"),
("105","woo","Ghhh","2","177","1","0","2018-07-06 12:11:19","2018-07-06 12:11:19","152"),
("106","porche","Wow","13","178","1","0","2018-07-10 11:45:37","2018-07-10 11:45:37","162"),
("107","haha","<p>Gahaha</p>","13","179","1","0","2018-07-11 10:46:52","2018-08-10 05:16:06","147"),
("110","enter","<p>Enter title</p>","13","182","1","0","2018-07-12 12:06:54","2018-08-10 05:15:52","165"),
("111","تت","<p>خخخ</p>","13","179","1","0","2018-07-12 13:14:20","2018-08-10 05:15:42","147"),
("112","mango","<p>Jahaha</p>","13","179","1","0","2018-07-12 13:17:29","2018-08-10 05:15:34","147"),
("113","ghg","Bahabaha","2","184","1","0","2018-07-12 13:57:59","2018-07-12 13:57:59","147"),
("116","urufu","Hdhchcv","13","186","1","0","2018-07-18 12:33:50","2018-07-18 12:33:50","2"),
("117","jjj","Jjj","13","187","1","0","2018-07-18 13:21:43","2018-07-18 13:21:43","167"),
("118","BigB","Fggg","12","188","1","0","2018-07-18 13:26:52","2018-07-18 13:26:52","167"),
("119","ghh","Ghh","13","187","1","0","2018-07-18 13:44:09","2018-07-18 13:44:09","167"),
("120","samsung","<p>Hahahah</p>","13","189","1","0","2018-07-22 13:57:37","2018-08-10 05:15:24","168"),
("121","samsung","Hahahah","13","189","1","0","2018-07-22 13:58:07","2018-07-22 13:58:07","168"),
("122","new product","We two ate wt wqwq twq wet we qw","13","191","1","0","2018-07-27 12:35:40","2018-07-27 12:35:40","171"),
("125","Armani","Armani","13","192","1","0","2018-08-02 11:08:55","2018-08-02 11:09:00","178"),
("126","eyeliner","<p>Wee we we www we we</p>","13","193","1","0","2018-08-02 11:35:17","2018-08-10 05:15:15","171"),
("127","tttt","<p>Fff</p>","13","194","1","0","2018-08-04 08:47:00","2018-08-10 05:15:05","147"),
("128","jack jack","<p>Sjnxkakjx</p>","2","195","1","0","2018-08-04 22:20:23","2018-08-10 05:14:42","185"),
("129","jack jack","Sjnxkakjx","2","195","1","0","2018-08-04 22:20:53","2018-08-04 22:20:53","185"),
("131","fgg","Ggg hugging","13","197","1","0","2018-08-10 09:22:04","2018-08-10 09:22:04","198"),
("132","product sale","<p>Cjfjjjfijdtozixgz</p>","13","197","0","0","2018-08-10 10:51:07","2018-08-10 11:29:39","198"),
("133","shine jacket","Shine jackets","13","198","1","0","2018-08-16 13:07:38","2018-08-16 13:07:38","200"),
("134","Channel jacket","Wow ","13","198","1","0","2018-08-16 13:09:57","2018-08-16 13:09:57","200"),
("135","chair","Dhdhdhdh","13","197","1","0","2018-08-17 04:25:54","2018-08-17 04:25:54","198"),
("136","locoste jeans","Wow","13","199","1","0","2018-08-21 14:15:29","2018-08-21 14:15:29","200"),
("137","add","Dhdhdh","13","200","1","0","2018-08-23 05:10:19","2018-08-23 05:10:19","201"),
("138","gold","Laugh","13","200","1","0","2018-08-23 05:36:19","2018-08-23 05:36:19","201"),
("139","shirt","<p>Good Quality</p>","4","154","1","0","2018-08-23 11:14:14","2018-08-23 11:14:14","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_product_favourite` (`id`,`product_id`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("23","103","1","","","","147"),
("26","103","1","","","","161"),
("36","103","1","","","","185"),
("47","103","1","","","","196"),
("49","100","1","","","","197"),
("53","100","1","","","","199"),
("56","125","1","","","","174"),
("57","100","1","","","","196"),
("58","100","1","","","","174"),
("59","83","1","","","","174"),
("62","136","1","","","","203");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_product_variant` (`id`,`product_id`,`color_id`,`size_id`,`quantity`,`amount`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("20","69","7","9","123","3999","1","0","2018-05-04 16:48:40","2018-05-04 16:48:40","109"),
("38","83","7","6","4","444","1","0","2018-06-27 06:48:15","2018-06-27 06:48:15","15"),
("42","87","3","3","258","2587","1","0","2018-06-27 10:45:50","2018-06-27 10:45:50","142"),
("43","87","7","3","258","5000","1","0","2018-06-27 10:45:50","2018-06-27 10:45:50","142"),
("47","92","3","6","46974","694","1","0","2018-06-27 14:48:45","2018-06-27 14:48:45","137"),
("48","94","7","6","20","50","1","0","2018-07-02 13:35:15","2018-07-02 13:35:15","147"),
("52","102","3","6","500","5000","1","0","2018-07-06 12:06:57","2018-07-06 12:06:57","152"),
("53","103","7","6","23","5000","1","0","2018-07-06 12:09:39","2018-07-06 12:09:39","152"),
("54","104","3","3","500","5000","1","0","2018-07-06 12:10:53","2018-07-06 12:10:53","152"),
("55","105","3","3","258","500","1","0","2018-07-06 12:11:32","2018-07-06 12:11:32","152"),
("56","106","3","6","500","2000","1","0","2018-07-10 11:45:56","2018-07-10 11:45:56","162"),
("60","113","3","6","50","12","1","0","2018-07-12 13:58:11","2018-07-12 13:58:11","147"),
("61","113","7","3","50","12","1","0","2018-07-12 13:59:25","2018-07-12 13:59:25","147"),
("102","117","3","6","25","2500","1","0","2018-07-18 13:23:44","2018-07-18 13:23:44","167"),
("103","117","7","9","56","5800","1","0","2018-07-18 13:23:44","2018-07-18 13:23:44","167"),
("108","118","3","3","25","852","1","0","2018-07-18 13:31:12","2018-07-18 13:31:12","167"),
("109","118","3","2","8","852","1","0","2018-07-18 13:31:12","2018-07-18 13:31:12","167"),
("110","118","3","1","5","852","1","0","2018-07-18 13:31:12","2018-07-18 13:31:12","167"),
("114","119","2","6","2586","2563","1","0","2018-07-18 13:45:31","2018-07-18 13:45:31","167"),
("115","121","3","6","21","20","1","0","2018-07-22 13:58:18","2018-07-22 13:58:18","168"),
("119","122","3","6","20","230","1","0","2018-07-27 13:01:15","2018-07-27 13:01:15","171"),
("123","125","3","6","28","200","1","0","2018-08-02 11:09:43","2018-08-02 11:09:43","178"),
("124","129","3","2","6467","46","1","0","2018-08-04 22:21:11","2018-08-04 22:21:11","185"),
("127","131","7","6","2","222","1","0","2018-08-10 09:22:49","2018-08-10 09:22:49","198"),
("128","131","3","3","2","22","1","0","2018-08-10 09:22:49","2018-08-10 09:22:49","198"),
("129","132","2","9","2","3535","1","0","2018-08-10 10:51:40","2018-08-10 10:51:40","198"),
("130","133","7","6","25","4800","1","0","2018-08-16 13:08:02","2018-08-16 13:08:02","200"),
("131","134","3","3","36","8500","1","0","2018-08-16 13:10:30","2018-08-16 13:10:30","200"),
("132","135","7","9","2","22","1","0","2018-08-17 04:26:07","2018-08-17 04:26:07","198"),
("133","136","3","6","25","2500","1","0","2018-08-21 14:15:43","2018-08-21 14:15:43","200"),
("134","136","2","3","28","2500","1","0","2018-08-21 14:25:25","2018-08-21 14:25:25","200"),
("135","137","3","6","2","225","1","0","2018-08-23 05:10:31","2018-08-23 05:10:31","201"),
("136","138","7","3","2","50","1","0","2018-08-23 05:36:29","2018-08-23 05:36:29","201"),
("137","139","1","3","33","345","1","0","2018-08-23 11:14:30","2018-08-23 11:14:30","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_sale` (`id`,`model_id`,`model_type`,`title`,`discount`,`min_limit`,`type_id`,`image_file`,`state_id`,`comment`,`created_on`,`updated_on`,`created_by_id`) VALUES
("1","105","app\\models\\Product","jacket","1","2","2","sale-1534826243-image_fileuser_id_1.jpg","1","","2018-08-13 07:06:41","","1"),
("2","99","app\\models\\Product","BUY 1 GET 1 Free","2","1","2","sale-1534826233-image_fileuser_id_1.jpg","1","","2018-08-14 05:12:40","","1"),
("3","130","app\\models\\Product","Best Offer","20","20","1","sale-1534826219-image_fileuser_id_1.jpg","1","","2018-08-20 13:10:41","","1"),
("4","139","app\\models\\Product","Black Shirt","10","60","1","sale.jpeg","1","","2018-08-23 11:15:41","","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_setting` (`id`,`key`,`title`,`value`,`type_id`,`state_id`,`created_by_id`) VALUES
("1","appConfig","App Configration","{\"companyUrl\":{\"type\":0,\"value\":\"https://www.toxsl.com\",\"required\":true},\"company\":{\"type\":0,\"value\":\"ToXSL Technologies\",\"required\":true},\"companyEmail\":{\"type\":0,\"value\":\"admin@toxsl.in\",\"required\":true},\"companyContactEmail\":{\"type\":0,\"value\":\"admin@toxsl.in\",\"required\":false},\"companyContactNo\":{\"type\":0,\"value\":\"9569127788\",\"required\":false},\"companyAddress\":{\"type\":0,\"value\":\"C-127, 4th floor, Phase 8, Industrial Area, Sector 72, Mohali, Punjab\",\"required\":false},\"loginCount\":{\"type\":2,\"value\":2,\"required\":false}}","0","0","1"),
("2","smtp","SMTP Configration","{\"host\":{\"value\":\"jupiter.toxsl.in\",\"type\":\"0\",\"required\":\"1\"},\"username\":{\"value\":\"test@jupiter.toxsl.in\",\"type\":\"0\",\"required\":\"1\"},\"password\":{\"value\":\"test@123\",\"type\":\"0\",\"required\":\"1\"},\"port\":{\"value\":\"587\",\"type\":\"0\",\"required\":\"1\"},\"encryption\":{\"value\":\"tls\",\"type\":\"0\",\"required\":\"\"}}","0","0","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_shipping_address` (`id`,`country`,`state`,`house_address`,`street`,`phone_number1`,`phone_number2`,`zipcode`,`lat`,`long`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("1","Chandigarh - Panchkula RoadModern Housing Complex ManimajraChandigarh","","","","0","0","0","30.7115478515625","76.82547760009766","1","0","2018-04-10 16:56:19","2018-04-10 16:56:19","55"),
("2","Mohali BypassPhase 3B-2 Sector 60Sahibzada Ajit Singh Nagar","","","","0","0","0","30.70746231079102","76.71559143066406","1","0","2018-04-10 17:06:52","2018-04-10 17:06:52","55"),
("3","Mohali Stadium RoadPhase 10 Sector 64Sahibzada Ajit Singh Nagar","","","","0","0","0","30.68681907653809","76.73927307128906","1","0","2018-04-10 17:45:52","2018-04-10 17:45:52","55"),
("4","Mohali Stadium RoadPhase 10 Sector 64Sahibzada Ajit Singh Nagar","","","","0","0","0","30.68681907653809","76.73927307128906","1","0","2018-04-10 17:46:23","2018-04-10 17:46:23","55"),
("5","Mohali Stadium RoadPhase 10 Sector 64Sahibzada Ajit Singh Nagar","","","","0","0","0","30.68681907653809","76.73927307128906","1","0","2018-04-10 17:47:09","2018-04-10 17:47:09","55"),
("6","Mohali BypassPhase 3B-2 Sector 60Sahibzada Ajit Singh Nagar","","","","0","0","0","30.70746231079102","76.71559143066406","1","0","2018-04-10 17:48:51","2018-04-10 17:48:51","55"),
("7","Chandigarh - Panchkula RoadModern Housing Complex ManimajraChandigarh","","","","0","0","0","30.7115478515625","76.82547760009766","1","0","2018-04-10 17:52:41","2018-04-10 17:52:41","55"),
("8","Mohali Stadium RoadPhase 10 Sector 64Sahibzada Ajit Singh Nagar","","","","0","0","0","30.68681907653809","76.73927307128906","1","0","2018-04-11 14:47:12","2018-04-11 14:47:12","55"),
("9","Mohali BypassPhase 3B-2 Sector 60Sahibzada Ajit Singh Nagar","","","","0","0","0","30.70746231079102","76.71559143066406","1","0","2018-04-11 15:53:29","2018-04-11 15:53:29","58"),
("10","Mohali BypassPhase 3B-2 Sector 60Sahibzada Ajit Singh Nagar","","","","0","0","0","30.70746231079102","76.71559143066406","1","0","2018-04-11 16:02:34","2018-04-11 16:02:34","58"),
("11","Chandos Place","","","","0","0","0","51.50992584228516","-0.1252415031194687","1","0","2018-04-11 16:12:03","2018-04-11 16:12:03","55"),
("12","Mohali BypassPhase 3B-2 Sector 60Sahibzada Ajit Singh Nagar","","","","0","0","0","30.70746231079102","76.71559143066406","1","0","2018-04-11 18:25:29","2018-04-11 18:25:29","60"),
("13","Mohali BypassPhase 3B-2 Sector 60Sahibzada Ajit Singh Nagar","","","","0","0","0","30.70746231079102","76.71559143066406","1","0","2018-04-11 18:51:00","2018-04-11 18:51:00","63"),
("14","Mohali BypassPhase 3B-2 Sector 60Sahibzada Ajit Singh Nagar","","","","0","0","0","30.70746231079102","76.71559143066406","1","0","2018-04-11 19:27:19","2018-04-11 19:27:19","64"),
("15","DasmanKuwait City","","","","0","0","0","29.38999938964844","48.00305557250977","1","0","2018-04-11 19:52:29","2018-04-11 19:52:29","66"),
("16","Chandigarh - Panchkula RoadModern Housing Complex ManimajraChandigarh","","","","0","0","0","30.7115478515625","76.82547760009766","1","0","2018-04-12 15:18:21","2018-04-12 15:18:21","55"),
("17","Chandigarh - Panchkula RoadModern Housing Complex ManimajraChandigarh","","","","0","0","0","30.7115478515625","76.82547760009766","1","0","2018-04-12 15:21:32","2018-04-12 15:21:32","55"),
("18","Mohali BypassPhase 3B-2 Sector 60Sahibzada Ajit Singh Nagar","","","","0","0","0","30.70746231079102","76.71559143066406","1","0","2018-04-13 11:34:56","2018-04-13 11:34:56","55"),
("19","Chandigarh - Panchkula RoadModern Housing Complex ManimajraChandigarh","","","","0","0","0","30.7115478515625","76.82547760009766","1","0","2018-04-16 15:48:55","2018-04-16 15:48:55","55"),
("20","Chandigarh - Panchkula RoadModern Housing Complex ManimajraChandigarh","","","","0","0","0","30.7115478515625","76.82547760009766","1","0","2018-04-19 12:12:15","2018-04-19 12:12:15","55"),
("21","Chandigarh - Panchkula RoadModern Housing Complex ManimajraChandigarh","","","","0","0","0","30.7115478515625","76.82547760009766","1","0","2018-04-19 13:28:40","2018-04-19 13:28:40","55"),
("22","Chandigarh - Panchkula RoadModern Housing Complex ManimajraChandigarh","","","","0","0","0","30.7115478515625","76.82547760009766","1","0","2018-04-19 14:42:36","2018-04-19 14:42:36","55"),
("23","Chandigarh - Panchkula RoadModern Housing Complex ManimajraChandigarh","","","","0","0","0","30.7115478515625","76.82547760009766","1","0","2018-04-19 14:45:21","2018-04-19 14:45:21","55"),
("24","Chandigarh - Panchkula RoadModern Housing Complex ManimajraChandigarh","","","","0","0","0","30.7115478515625","76.82547760009766","1","0","2018-05-01 10:35:30","2018-05-01 10:35:30","86"),
("25","Chandigarh - Panchkula RoadModern Housing Complex ManimajraChandigarh","","","","0","0","0","30.7115478515625","76.82547760009766","1","0","2018-05-01 10:49:00","2018-05-01 10:49:00","88"),
("26","Mohali BypassPhase 3B-2 Sector 60Sahibzada Ajit Singh Nagar","","","","0","0","0","30.70746231079102","76.71559143066406","1","0","2018-05-01 11:27:29","2018-05-01 11:27:29","90"),
("27","Mohegan Sun BoulevardMontville","","","","0","0","0","41.48923110961914","-72.08725738525391","1","0","2018-05-01 14:12:49","2018-05-01 14:12:49","96"),
("28","Mohegan Sun BoulevardMontville","","","","0","0","0","41.48923110961914","-72.08725738525391","1","0","2018-05-01 14:22:15","2018-05-01 14:22:15","96"),
("29","Mohali BypassPhase 3B-2 Sector 60Sahibzada Ajit Singh Nagar","","","","0","0","0","30.70746231079102","76.71559143066406","1","0","2018-05-01 14:28:33","2018-05-01 14:28:33","88"),
("30","Mohali BypassPhase 3B-2 Sector 60Sahibzada Ajit Singh Nagar","","","","0","0","0","30.70746231079102","76.71559143066406","1","0","2018-05-01 14:59:07","2018-05-01 14:59:07","97"),
("31","DasmanKuwait City","","","","0","0","0","29.38999938964844","48.00305557250977","1","0","2018-05-01 15:49:12","2018-05-01 15:49:12","98"),
("32","Chandigarh - Panchkula RoadModern Housing Complex ManimajraChandigarh","","","","0","0","0","30.7115478515625","76.82547760009766","1","0","2018-05-02 10:07:39","2018-05-02 10:07:39","88"),
("33","Chandigarh - Panchkula RoadModern Housing Complex ManimajraChandigarh","","","","0","0","0","30.7115478515625","76.82547760009766","1","0","2018-05-02 11:33:59","2018-05-02 11:33:59","88"),
("34","Chandigarh - Panchkula RoadModern Housing Complex ManimajraChandigarh","","","","0","0","0","30.7115478515625","76.82547760009766","1","0","2018-05-02 12:22:29","2018-05-02 12:22:29","88"),
("36","0","","","","0","0","0","0","0","1","0","2018-05-04 17:28:24","2018-05-04 17:28:24","1"),
("37","Uthth","Rationethtrh","hhtrhtrh","","0","0","123654","","","1","0","2018-05-10 15:20:26","2018-05-10 15:20:26","1"),
("38","Rem quia.","Debitis.","Sunt iste.","","0","0","123654","","","1","0","2018-05-10 15:34:41","2018-05-10 15:34:41","1"),
("39","capital governorate","street no -22","house no-12","","0","0","12341234","","","1","0","2018-05-10 18:04:29","2018-05-10 18:04:29","116"),
("40","capital governorate","kuwait city","12","","0","0","12341234","","","1","0","2018-05-10 18:13:51","2018-05-10 18:13:51","116"),
("41","capital governorate","kuwait city","12","","0","0","12341234","","","1","0","2018-05-10 18:31:49","2018-05-10 18:31:49","116"),
("42","capital governorate","AL Qudsiya","1234","","0","0","12341234","","","20","0","2018-05-10 19:04:20","2018-05-10 19:04:20","1"),
("43","capital governorate","AL Qudsiya","jyjtyjj","","0","0","12341234","","","20","0","2018-05-10 19:05:31","2018-05-10 19:05:31","1"),
("44","capital governorate","AL Qudsiya","1644","","0","0","12341234","","","20","0","2018-05-10 19:18:12","2018-05-10 19:18:12","1"),
("45","capital governorate","kuwait city","house no-12","","0","0","1234","","","1","0","2018-05-10 19:22:54","2018-05-10 19:22:54","116"),
("46","capital governorate","kuwait city","house no-12","","0","0","1234","","","1","0","2018-05-10 19:23:45","2018-05-10 19:23:45","116"),
("47","capital governorate","kuwait city","asdf","","0","0","1241234","","","1","0","2018-05-10 19:25:18","2018-05-10 19:25:18","116"),
("48","capital governorate","kuwait city","asdfasd","","0","0","12413","","","1","0","2018-05-10 19:26:13","2018-05-10 19:26:13","116"),
("49","capital governorate","AL Qudsiya","1644","","0","0","545","","","20","0","2018-05-10 19:27:51","2018-05-10 19:27:51","1"),
("50","capital governorate","kuwait city","asdf","","0","0","12341234","","","1","0","2018-05-10 19:35:59","2018-05-10 19:35:59","116"),
("51","capital governorate","kuwait city","we","","0","0","141234","","","1","0","2018-05-10 19:37:51","2018-05-10 19:37:51","116"),
("52","capital governorate","kuwait city","asdfs","","0","0","1124","","","1","0","2018-05-10 19:42:24","2018-05-10 19:42:24","116"),
("53","capital governorate","kuwait city","13","","0","0","123555","","","1","0","2018-05-11 09:32:18","2018-05-11 09:32:18","116"),
("54","Hawally","Bayan","asdf","","0","0","12341234","","","79","0","2018-05-11 10:39:40","2018-05-11 10:39:40","116"),
("55","capital governorate","Dasman","asdf","","0","0","124123412","","","2","0","2018-05-11 11:15:07","2018-05-11 11:15:07","116"),
("56","AL Frwaniya","AL Aqila","sdf","","0","0","12341","","","33","0","2018-05-11 11:18:06","2018-05-11 11:18:06","116"),
("57","AL Frwaniya","AL Zuhar","asdfasdf","","0","0","1241234","","","34","0","2018-05-11 11:26:32","2018-05-11 11:26:32","116"),
("58","Mubarak Al Kabeer","Abu Fteira","ad","","0","0","12341234","","","69","0","2018-05-11 12:02:06","2018-05-11 12:02:06","116"),
("59","capital governorate","Dasman","asdfs","","0","0","1341234","","","2","0","2018-05-11 12:06:36","2018-05-11 12:06:36","116"),
("60","AL Frwaniya","AL Zuhar","add","","0","0","1341234","","","34","0","2018-05-11 12:44:04","2018-05-11 12:44:04","116"),
("61","capital governorate","kuwait city","asdf","","0","0","1234123","","","1","0","2018-05-11 13:24:26","2018-05-11 13:24:26","116"),
("62","capital governorate","kuwait city","asdfas","","0","0","12341","","","1","0","2018-05-11 14:23:14","2018-05-11 14:23:14","116"),
("63","capital governorate","kuwait city","12","","0","0","1234123412","","","1","0","2018-05-11 17:18:12","2018-05-11 17:18:12","116"),
("64","AL Frwaniya","Khitan","dsf","","0","0","323333","","","50","0","2018-05-11 17:25:45","2018-05-11 17:25:45","116"),
("65","Mubarak Al Kabeer","AL Misila","sdf","","0","0","1423","","","68","0","2018-05-11 17:27:27","2018-05-11 17:27:27","116"),
("66","capital governorate","Dasman","try","","0","0","1234","","","2","0","2018-05-14 12:17:43","2018-05-14 12:17:43","116"),
("67","AL Frwaniya","AL Aqila","ad","","0","0","12344","","","33","0","2018-05-14 12:22:03","2018-05-14 12:22:03","116"),
("68","capital governorate","Dasman","12","","0","0","12312","","","2","0","2018-05-14 13:14:34","2018-05-14 13:14:34","116"),
("69","capital governorate","AL Salhiya","13","","0","0","123423","","","7","0","2018-05-14 14:30:49","2018-05-14 14:30:49","116"),
("70","AL Frwaniya","AL Aqila","13","133","0","0","12343","","","33","0","2018-05-14 15:04:03","2018-05-14 15:04:03","116"),
("71","Mubarak Al Kabeer","AL Misila","Foy","46","0","0","12365785","","","68","0","2018-05-14 17:13:58","2018-05-14 17:13:58","118"),
("72","Mubarak Al Kabeer","AL Misila","uru","duh","0","0","1233557","","","68","0","2018-05-14 17:17:30","2018-05-14 17:17:30","118"),
("73","capital governorate","AL Mirgab","5","t","0","0","58","","","5","0","2018-05-14 17:49:06","2018-05-14 17:49:06","119"),
("74","kuwait al asimah","Dasman","12","23","0","0","123412","","","2","0","2018-05-15 10:37:38","2018-05-15 10:37:38","116"),
("75","kuwait al asimah","kuwait city","we","tweet","0","0","12341","","","1","0","2018-05-15 15:17:03","2018-05-15 15:17:03","116"),
("76","kuwait al asimah","kuwait city","tt","gg","0","0","22658","","","1","0","2018-05-15 17:30:13","2018-05-15 17:30:13","116"),
("77","kuwait al asimah","kuwait city","th","vvghj","0","0","55555","","","1","0","2018-05-15 17:39:25","2018-05-15 17:39:25","116"),
("78","kuwait al asimah","kuwait city","df","fff","0","0","22222","","","1","0","2018-05-15 18:22:58","2018-05-15 18:22:58","116"),
("79","kuwait al asimah","kuwait city","fff","fff","0","0","1225","","","1","0","2018-05-15 18:27:04","2018-05-15 18:27:04","116"),
("80","kuwait al asimah","Dasman","ggh","fhj","0","0","1285568","","","2","0","2018-05-15 19:01:55","2018-05-15 19:01:55","120"),
("81","kuwait al asimah","Dasman","123","shhsjs","0","0","13454","","","2","0","2018-05-15 19:04:19","2018-05-15 19:04:19","120"),
("82","kuwait al asimah","AL Mirgab","d","c","0","0","4488","","","5","0","2018-05-16 01:09:42","2018-05-16 01:09:42","119"),
("83","Mubarak Al Kabeer","Abu Fteira","467","ghjk","0","0","123654","","","69","0","2018-06-19 08:37:50","2018-06-19 08:37:50","131"),
("84","AL Frwaniya","AL Aqila","fg","fgh","0","0","45553","","","33","0","2018-06-19 09:57:30","2018-06-19 09:57:30","133"),
("85","Hawally","AL Bidi","I fgh","fhjjj ","0","0","1255463","","","80","0","2018-06-19 10:24:54","2018-06-19 10:24:54","131"),
("86","kuwait al asimah","AL Nuzha","j","n","0","0","3566","","","15","0","2018-06-20 07:46:19","2018-06-20 07:46:19","137"),
("87","kuwait al asimah","Kaifan","d","f","0","0","5885","","","10","0","2018-06-22 15:14:52","2018-06-22 15:14:52","137"),
("88","Asimah","AL Shaab","12","street no-22","0","0","124123","","","78","0","2018-06-27 07:54:32","2018-06-27 07:54:32","141"),
("89","Hawally","Dasman","vhj","gh","0","0","2589635","","","2","0","2018-06-27 10:56:10","2018-06-27 10:56:10","143"),
("90","Al Farwanya","Abu Fteira","ggh","fgg","0","0","852741","","","69","0","2018-06-27 12:13:02","2018-06-27 12:13:02","141"),
("91","Mubarak Al Kaber","AL Aqila","ghh","gg","0","0","852852","","","33","0","2018-06-27 14:11:22","2018-06-27 14:11:22","145"),
("92","Asimah","AL Shaab","h","y","0","0","58865","","","78","0","2018-07-01 13:00:47","2018-07-01 13:00:47","146"),
("93","Al Farwanya","Abu Fteira","haha","haha","0","0","51515","","","69","0","2018-07-02 11:47:41","2018-07-02 11:47:41","147"),
("94","Hawally","Dasman","sdf","asdf","0","0","234123423","","","2","0","2018-07-05 07:17:00","2018-07-05 07:17:00","148"),
("95","Hawally","Dasman","fog","gf","0","0","2135565","","","2","0","2018-07-05 07:39:24","2018-07-05 07:39:24","148"),
("96","capital governorate","AL Qudsiya","1234","","12341234","2147483647","0","","","20","0","2018-07-05 10:26:50","2018-07-05 10:26:50","1"),
("97","capital governorate","AL Qudsiya","1234","","12341234","2147483647","0","","","20","0","2018-07-05 10:27:22","2018-07-05 10:27:22","1"),
("98","capital governorate","AL Qudsiya","1234","","12341234","2147483647","0","","","20","0","2018-07-05 10:31:27","2018-07-05 10:31:27","1"),
("99","capital governorate","AL Qudsiya","retertre","","12341234","2147483647","0","","","20","0","2018-07-05 10:31:32","2018-07-05 10:31:32","1"),
("100","capital governorate","AL Qudsiya","retertre","","12341234","66555","0","","","20","0","2018-07-05 10:31:46","2018-07-05 10:31:46","1"),
("101","capital governorate","AL Qudsiya","1234","","12341234","2147483647","0","","","20","0","2018-07-05 10:33:10","2018-07-05 10:33:10","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_shipping_address` (`id`,`country`,`state`,`house_address`,`street`,`phone_number1`,`phone_number2`,`zipcode`,`lat`,`long`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("102","capital governorate","AL Qudsiya","1234","","12341234","2147483647","0","","","20","0","2018-07-05 10:34:38","2018-07-05 10:34:38","1"),
("103","capital governorate","AL Qudsiya","1234","","12341234","2147483647","0","","","20","0","2018-07-05 10:38:48","2018-07-05 10:38:48","1"),
("104","capital governorate","AL Qudsiya","1234","","12341234","2147483647","0","","","20","0","2018-07-05 10:39:20","2018-07-05 10:39:20","1"),
("105","capital governorate","AL Qudsiya","1234","","12341234","2147483647","0","","","20","0","2018-07-05 10:40:44","2018-07-05 10:40:44","1"),
("106","capital governorate","AL Qudsiya","1234","","12341234","2147483647","0","","","20","0","2018-07-05 10:41:28","2018-07-05 10:41:28","1"),
("107","capital governorate","AL Qudsiya","1234","","12341234","2147483647","0","","","20","0","2018-07-05 10:42:09","2018-07-05 10:42:09","1"),
("108","Hawally","kuwait city","adds","","2147483647","986795765","0","","","1","0","2018-07-05 12:24:30","2018-07-05 12:24:30","148"),
("109","Hawally","kuwait city","adds","","2147483647","986795765","0","","","1","0","2018-07-05 12:24:32","2018-07-05 12:24:32","148"),
("110","Hawally","kuwait city","adds","","2147483647","986795765","0","","","1","0","2018-07-05 12:25:24","2018-07-05 12:25:24","148"),
("111","Hawally","kuwait city","adds","","2147483647","986795765","0","","","1","0","2018-07-05 12:26:53","2018-07-05 12:26:53","148"),
("112","Hawally","kuwait city","adds","","2147483647","986795765","0","","","1","0","2018-07-05 12:28:09","2018-07-05 12:28:09","148"),
("113","Hawally","Dasman","asdfasdfas","","412341234","2147483647","0","","","2","0","2018-07-05 12:32:20","2018-07-05 12:32:20","148"),
("114","Hawally","Dasman","asdfasdfas","","412341234","2147483647","0","","","2","0","2018-07-05 12:32:54","2018-07-05 12:32:54","148"),
("115","Hawally","Dasman","asdfasdfas","","4123423","345235234","0","","","2","0","2018-07-05 12:34:36","2018-07-05 12:34:36","148"),
("116","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-07-05 12:41:21","2018-07-05 12:41:21","1"),
("117","Hawally","Dasman","asdf","asdfasdfas","412341234","2147483647","0","","","2","0","2018-07-05 12:47:05","2018-07-05 12:47:05","148"),
("118","Hawally","Dasman","abc","anchor ","2147483647","2147483647","0","","","2","0","2018-07-06 11:56:35","2018-07-06 11:56:35","150"),
("119","Mubarak Al Kaber","AL Aqila","abc","abc","2147483647","2147483647","0","","","33","0","2018-07-10 12:02:31","2018-07-10 12:02:31","161"),
("120","Al Farwanya","AL Misila","fgg","fgh","2147483647","2147483647","0","","","68","0","2018-07-12 12:12:18","2018-07-12 12:12:18","166"),
("121","Mubarak Al Kaber","AL Aqila","jahaha","hahaha","21818101","545454","0","","","33","0","2018-07-22 14:01:59","2018-07-22 14:01:59","147"),
("122","Mubarak Al Kaber","AL Aqila","123","13","2147483647","2147483647","0","","","33","0","2018-07-26 12:03:09","2018-07-26 12:03:09","172"),
("123","Mubarak Al Kaber","AL Aqila","1233","7","2147483647","2147483647","0","","","33","0","2018-07-27 05:12:27","2018-07-27 05:12:27","172"),
("124","Mubarak Al Kaber","AL Aqila","retire","3345","2147483647","2147483647","0","","","33","0","2018-07-31 12:52:25","2018-07-31 12:52:25","172"),
("125","Mubarak Al Kaber","AL Fintas","yghhhh","hhh","555525255","2147483647","0","","","32","0","2018-08-01 09:08:00","2018-08-01 09:08:00","174"),
("126","Mubarak Al Kaber","AL Aqila","ghvkgc","2544 mhv","65","65088822","0","","","33","0","2018-08-04 22:24:10","2018-08-04 22:24:10","186"),
("127","Mubarak Al Kaber","AL Aqila","gds","staff","23452354","253452345","0","","","33","0","2018-08-06 06:42:10","2018-08-06 06:42:10","187"),
("128","Hawally","Dasman","hshs","hshshs","2147483647","2147483647","0","","","2","0","2018-08-08 06:55:55","2018-08-08 06:55:55","196"),
("129","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-08 11:13:17","2018-08-08 11:13:17","113"),
("130","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-08 11:15:07","2018-08-08 11:15:07","113"),
("131","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-08 11:18:13","2018-08-08 11:18:13","113"),
("132","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-08 12:57:15","2018-08-08 12:57:15","113"),
("133","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-08 13:09:05","2018-08-08 13:09:05","113"),
("134","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-08 13:12:36","2018-08-08 13:12:36","113"),
("135","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-08 13:14:18","2018-08-08 13:14:18","113"),
("136","Hawally","Dasman","Mohali","phase -5","523452352","2147483647","0","","","2","0","2018-08-09 11:50:23","2018-08-09 11:50:23","196"),
("137","Hawally","Dasman","Abc","Abc","2147483647","2147483647","0","","","2","0","2018-08-10 04:08:30","2018-08-10 04:08:30","197"),
("138","Hawally","Dasman","Hd","Hd","5454551","549645653","0","","","2","0","2018-08-10 04:10:54","2018-08-10 04:10:54","197"),
("139","Hawally","Dasman","Hd","Hd","5454551","549645653","0","","","2","0","2018-08-10 04:10:58","2018-08-10 04:10:58","197"),
("140","Hawally","Dasman","sh","jddh","459756756","845454545","0","","","2","0","2018-08-10 04:13:29","2018-08-10 04:13:29","197"),
("141","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 04:49:26","2018-08-10 04:49:26","113"),
("142","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 05:19:05","2018-08-10 05:19:05","113"),
("143","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 05:22:41","2018-08-10 05:22:41","113"),
("144","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 05:24:00","2018-08-10 05:24:00","113"),
("145","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 05:24:25","2018-08-10 05:24:25","113"),
("146","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 05:27:23","2018-08-10 05:27:23","113"),
("147","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 05:27:52","2018-08-10 05:27:52","113"),
("148","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 05:29:22","2018-08-10 05:29:22","113"),
("149","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 05:36:50","2018-08-10 05:36:50","113"),
("150","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 05:43:41","2018-08-10 05:43:41","113"),
("151","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 05:44:05","2018-08-10 05:44:05","113"),
("152","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 05:46:30","2018-08-10 05:46:30","113"),
("153","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 05:47:00","2018-08-10 05:47:00","113"),
("154","Hawally","kuwait city","asdf","asdf","213412342","214234124","0","","","1","0","2018-08-10 06:02:08","2018-08-10 06:02:08","197"),
("155","Hawally","Dasman","staff","asdf","134123","1241242141","0","","","2","0","2018-08-10 07:47:23","2018-08-10 07:47:23","197"),
("158","Hawally","kuwait city","af","asdf","134123","323534","0","","","1","0","2018-08-10 08:59:28","2018-08-10 08:59:28","197"),
("159","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:00:39","2018-08-10 09:00:39","113"),
("160","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:01:00","2018-08-10 09:01:00","113"),
("161","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:01:56","2018-08-10 09:01:56","113"),
("162","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:02:18","2018-08-10 09:02:18","113"),
("163","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:02:23","2018-08-10 09:02:23","113"),
("164","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:02:55","2018-08-10 09:02:55","113"),
("165","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:03:42","2018-08-10 09:03:42","113"),
("166","Hawally","kuwait city","dogs add","sdfg","523452345","2147483647","0","","","1","0","2018-08-10 09:04:42","2018-08-10 09:04:42","197"),
("167","Mubarak Al Kaber","AL Fintas","asdf","asdf","2147483647","2147483647","0","","","32","0","2018-08-10 09:24:01","2018-08-10 09:24:01","197"),
("168","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:26:41","2018-08-10 09:26:41","113"),
("169","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:26:48","2018-08-10 09:26:48","113"),
("170","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:28:05","2018-08-10 09:28:05","113"),
("171","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:28:11","2018-08-10 09:28:11","113"),
("172","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:29:09","2018-08-10 09:29:09","113"),
("173","Hawally","Dasman","sofas","sdfg","234523452","2147483647","0","","","2","0","2018-08-10 09:35:38","2018-08-10 09:35:38","197"),
("174","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:36:40","2018-08-10 09:36:40","113"),
("175","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:37:17","2018-08-10 09:37:17","198"),
("176","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:37:23","2018-08-10 09:37:23","198"),
("177","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:37:39","2018-08-10 09:37:39","198"),
("178","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:38:36","2018-08-10 09:38:36","198"),
("179","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","2","0","2018-08-10 09:40:01","2018-08-10 09:40:01","198"),
("180","Hawally","Dasman","asf","asdf","2147483647","2345234","0","","","2","0","2018-08-10 09:47:02","2018-08-10 09:47:02","196"),
("181","Hawally","Dasman","asdfasdfas","adds","12341234","435235234","0","","","2","0","2018-08-10 09:50:25","2018-08-10 09:50:25","196"),
("182","Mubarak Al Kaber","AL Aqila","add","asdf","534525232","34423523","0","","","33","0","2018-08-10 09:53:13","2018-08-10 09:53:13","196"),
("183","Mubarak Al Kaber","AL Aqila","asdf","asdf","12412423","1432412","0","","","33","0","2018-08-10 10:10:59","2018-08-10 10:10:59","196"),
("184","Hawally","Dasman","dad","adf","12342412","3252345","0","","","2","0","2018-08-10 10:22:16","2018-08-10 10:22:16","196"),
("185","Hawally","Dasman","dad","adds","234532","222222","0","","","2","0","2018-08-10 10:25:44","2018-08-10 10:25:44","196"),
("186","Mubarak Al Kaber","AL Zuhar","adds","asdf","234523","345234","0","","","34","0","2018-08-10 10:27:06","2018-08-10 10:27:06","196"),
("187","Mubarak Al Kaber","AL Fintas","sgsdfg","asdfasdfas","2147483647","456356","0","","","32","0","2018-08-10 10:28:52","2018-08-10 10:28:52","196"),
("188","Mubarak Al Kaber","AL Fintas","af","adf","3545345","5464536","0","","","32","0","2018-08-10 10:32:09","2018-08-10 10:32:09","196"),
("189","Mubarak Al Kaber","AL Aqila","sdfg","sdfg","34634645","546745675","0","","","33","0","2018-08-10 10:35:13","2018-08-10 10:35:13","196"),
("190","Mubarak Al Kaber","AL Aqila","shaggy","sdfg did","46456456","6745675","0","","","33","0","2018-08-10 10:37:58","2018-08-10 10:37:58","196"),
("191","Mubarak Al Kaber","AL Aqila","we","dad","53534534","2147483647","0","","","33","0","2018-08-10 10:48:05","2018-08-10 10:48:05","196"),
("192","Mubarak Al Kaber","AL Fintas","dfgs","sdfg","4564645","5234534","0","","","32","0","2018-08-10 10:50:00","2018-08-10 10:50:00","196"),
("193","Mubarak Al Kaber","AL Aqila","adf","asdf","235345","141234","0","","","33","0","2018-08-10 10:53:10","2018-08-10 10:53:10","196"),
("194","Mubarak Al Kaber","AL Aqila","adf","adds","3452345","35234545","0","","","33","0","2018-08-10 11:01:39","2018-08-10 11:01:39","196"),
("195","Hawally","kuwait city","dad","asdf","754674567","23452345","0","","","1","0","2018-08-10 11:08:16","2018-08-10 11:08:16","196"),
("196","Mubarak Al Kaber","AL Aqila","staff","asdf","3245235","32453","0","","","33","0","2018-08-10 11:55:30","2018-08-10 11:55:30","196"),
("197","Mubarak Al Kaber","AL Aqila","adds","asdf","34543453","34523453","0","","","33","0","2018-08-10 11:56:24","2018-08-10 11:56:24","196"),
("198","Mubarak Al Kaber","AL Aqila","as","asdf","3225345","3452353","0","","","33","0","2018-08-10 11:58:04","2018-08-10 11:58:04","196"),
("199","Mubarak Al Kaber","AL Aqila","asdf","asdf","34523535","3245235","0","","","33","0","2018-08-10 11:59:15","2018-08-10 11:59:15","196"),
("200","Hawally","Dasman","adds","adsf","2147483647","2147483647","0","","","2","0","2018-08-10 12:00:33","2018-08-10 12:00:33","196"),
("201","Mubarak Al Kaber","AL Aqila","dad","asdf","341342","3523453","0","","","33","0","2018-08-10 12:06:40","2018-08-10 12:06:40","196"),
("202","Mubarak Al Kaber","AL Aqila","adsf","asdf","345235","3452345","0","","","33","0","2018-08-10 12:07:25","2018-08-10 12:07:25","196"),
("203","Mubarak Al Kaber","AL Zuhar","asdf","adsf","3452345","34534","0","","","34","0","2018-08-10 12:19:26","2018-08-10 12:19:26","196");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_shipping_address` (`id`,`country`,`state`,`house_address`,`street`,`phone_number1`,`phone_number2`,`zipcode`,`lat`,`long`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("204","Mubarak Al Kaber","AL Aqila","df","asdf","412341234","2341234","0","","","33","0","2018-08-10 12:20:13","2018-08-10 12:20:13","196"),
("205","Mubarak Al Kaber","AL Aqila","adsf","adsf","23424","3425234","0","","","33","0","2018-08-10 12:20:47","2018-08-10 12:20:47","196"),
("206","Mubarak Al Kaber","AL Aqila","sofas","adsf","12341234","23423423","0","","","33","0","2018-08-10 12:22:35","2018-08-10 12:22:35","196"),
("207","Mubarak Al Kaber","AL Aqila","adsf","adsf","1412341234","343453","0","","","33","0","2018-08-10 12:23:20","2018-08-10 12:23:20","196"),
("208","Mubarak Al Kaber","AL Aqila","dad","asd","321423423","23423423","0","","","33","0","2018-08-10 12:32:27","2018-08-10 12:32:27","196"),
("209","Hawally","Sharq","asdf","asdf","3232323","3245234","0","","","3","0","2018-08-10 12:33:22","2018-08-10 12:33:22","196"),
("210","Mubarak Al Kaber","AL Aqila","AF","AS","34134","23423423","0","","","33","0","2018-08-10 12:34:09","2018-08-10 12:34:09","196"),
("211","Hawally","kuwait city","Z","D","23423","23423","0","","","1","0","2018-08-10 12:35:22","2018-08-10 12:35:22","196"),
("212","Hawally","kuwait city","sfasasd","DF","5234523","322","0","","","1","0","2018-08-10 12:43:44","2018-08-10 12:43:44","196"),
("213","Hawally","Sharq","sdfg","dad","345345","34353","0","","","3","0","2018-08-10 12:53:52","2018-08-10 12:53:52","196"),
("214","Hawally","Dasman","asdf","asdf","234234","24342","0","","","2","0","2018-08-10 12:54:31","2018-08-10 12:54:31","196"),
("215","Hawally","Dasman","asd","asd","232","32424243","0","","","2","0","2018-08-10 12:55:05","2018-08-10 12:55:05","196"),
("216","Hawally","Dasman","staff","asdf","341241234","1234124","0","","","2","0","2018-08-13 05:02:49","2018-08-13 05:02:49","196"),
("217","Hawally","kuwait city","staff","asdf","12341234","142341234","0","","","1","0","2018-08-13 05:14:54","2018-08-13 05:14:54","196"),
("218","Hawally","kuwait city","asdf","asdf","124123412","34124123","0","","","1","0","2018-08-13 05:17:37","2018-08-13 05:17:37","196"),
("219","Hawally","Dasman","staff","adds","214234","425234532","0","","","2","0","2018-08-13 05:45:22","2018-08-13 05:45:22","196"),
("220","Mubarak Al Kaber","AL Aqila","asdfasdfas","sg","134123412","3345345","0","","","33","0","2018-08-13 13:01:06","2018-08-13 13:01:06","196"),
("221","Mubarak Al Kaber","AL Aqila","sdf","sdf","2345","346534634","0","","","33","0","2018-08-13 13:02:08","2018-08-13 13:02:08","196"),
("222","Mubarak Al Kaber","AL Fintas","asdf","sdf","3423423","3452354","0","","","32","0","2018-08-13 13:02:48","2018-08-13 13:02:48","196"),
("223","Hawally","Dasman","dada","asdf","134241234","2341234","0","","","2","0","2018-08-13 13:07:16","2018-08-13 13:07:16","196"),
("224","Hawally","Dasman","disadvantage","asdf","3214231","2147483647","0","","","2","0","2018-08-14 04:54:47","2018-08-14 04:54:47","196"),
("225","Hawally","Dasman","asdfasdfas","sdf","234","2147483647","0","","","2","0","2018-08-14 04:55:22","2018-08-14 04:55:22","196"),
("226","Hawally","Dasman","Adam","asdf","234234","2147483647","0","","","2","0","2018-08-14 04:56:36","2018-08-14 04:56:36","196"),
("227","Hawally","kuwait city","asdfasdfas","did","41423","2147483647","0","","","1","0","2018-08-14 05:09:41","2018-08-14 05:09:41","196"),
("228","Hawally","kuwait city","doffs","sdfg","433453","2147483647","0","","","1","0","2018-08-14 05:18:25","2018-08-14 05:18:25","196"),
("229","Hawally","Dasman","staff","asdf","234234","2147483647","0","","","2","0","2018-08-14 05:19:30","2018-08-14 05:19:30","196"),
("230","Mubarak Al Kaber","AL Aqila","asdf","asdf","234234","2147483647","0","","","33","0","2018-08-14 05:23:39","2018-08-14 05:23:39","196"),
("231","Hawally","kuwait city","sdfg","as","3452352","2147483647","0","","","1","0","2018-08-14 06:11:55","2018-08-14 06:11:55","196"),
("232","Hawally","Dasman","add","asdf","324234","2147483647","0","","","2","0","2018-08-14 06:15:10","2018-08-14 06:15:10","196"),
("233","Hawally","Dasman","asdf","asdf","523523","2147483647","0","","","2","0","2018-08-14 06:37:27","2018-08-14 06:37:27","196"),
("234","Hawally","kuwait city","sdfg","sdfg","3545","2147483647","0","","","1","0","2018-08-14 06:41:33","2018-08-14 06:41:33","196"),
("235","Mubarak Al Kaber","AL Fintas","dad","sdfg","34534534","2147483647","0","","","32","0","2018-08-14 06:45:37","2018-08-14 06:45:37","196"),
("236","Hawally","kuwait city","sdf","cxzv","543","2147483647","0","","","1","0","2018-08-14 06:46:32","2018-08-14 06:46:32","196"),
("237","Hawally","kuwait city","asdf","sdfg","3433","2147483647","0","","","1","0","2018-08-14 06:48:11","2018-08-14 06:48:11","196"),
("238","Mubarak Al Kaber","AL Fintas","asdfasdfas","asdf","234234","2147483647","0","","","32","0","2018-08-14 07:08:09","2018-08-14 07:08:09","196"),
("239","Hawally","Dasman","sdfgsd","fog","34","2147483647","0","","","2","0","2018-08-14 07:08:46","2018-08-14 07:08:46","196"),
("240","Hawally","Dasman","sdfg","sdfg","34534","2147483647","0","","","2","0","2018-08-14 07:09:46","2018-08-14 07:09:46","196"),
("241","Hawally","Dasman","asdf","asdf","232342","2147483647","0","","","2","0","2018-08-14 07:10:59","2018-08-14 07:10:59","196"),
("242","Hawally","kuwait city","asdf","asdf","33435","2147483647","0","","","1","0","2018-08-14 07:16:32","2018-08-14 07:16:32","196"),
("243","Hawally","Dasman","staff","asdf","23423423","2147483647","0","","","2","0","2018-08-14 07:18:39","2018-08-14 07:18:39","196"),
("244","Mubarak Al Kaber","AL Aqila","dfsgsdf","fdsgsfdg","5465","2147483647","0","","","33","0","2018-08-14 07:24:04","2018-08-14 07:24:04","196"),
("245","Hawally","kuwait city","asdfas","df","354345","2147483647","0","","","1","0","2018-08-14 07:30:11","2018-08-14 07:30:11","196"),
("246","Mubarak Al Kaber","AL Aqila","asd","ASD","33","2147483647","0","","","33","0","2018-08-14 07:30:42","2018-08-14 07:30:42","196"),
("247","Mubarak Al Kaber","AL Aqila","sdf asd","dsfads","44545","2147483647","0","","","33","0","2018-08-14 07:32:13","2018-08-14 07:32:13","196"),
("248","Mubarak Al Kaber","AL Mahbula","df sdfg","fdgsdfg","566","2147483647","0","","","35","0","2018-08-14 07:33:05","2018-08-14 07:33:05","196"),
("249","Hawally","Dasman","hey","giggles","6546","2147483647","0","","","2","0","2018-08-14 07:33:51","2018-08-14 07:33:51","196"),
("250","Mubarak Al Kaber","AL Aqila","hmm","ghjgfjhg","7767","2147483647","0","","","33","0","2018-08-14 07:34:29","2018-08-14 07:34:29","196"),
("251","Mubarak Al Kaber","AL Aqila","hey","gfhdfg","57567","2147483647","0","","","33","0","2018-08-14 07:35:52","2018-08-14 07:35:52","196"),
("252","Mubarak Al Kaber","AL Aqila","gfsdfg","fdgsdfg","3545","2147483647","0","","","33","0","2018-08-14 07:37:11","2018-08-14 07:37:11","196"),
("253","Al Farwanya","Abu Fteira","dfgfds","fdgsdfg","576575","2147483647","0","","","69","0","2018-08-14 07:38:55","2018-08-14 07:38:55","196"),
("254","Mubarak Al Kaber","AL Zuhar","dsfgfds","df sdfg","35454","2147483647","0","","","34","0","2018-08-14 07:42:07","2018-08-14 07:42:07","196"),
("255","Mubarak Al Kaber","AL Aqila","fghdfhgdfg","high","6456","2147483647","0","","","33","0","2018-08-14 07:42:44","2018-08-14 07:42:44","196"),
("256","Hawally","Dasman","fdgsdfg","fdgsdfg","555","2147483647","0","","","2","0","2018-08-14 07:55:54","2018-08-14 07:55:54","196"),
("257","Mubarak Al Kaber","AL Aqila","gsdfgsfd","fdgsdfg","6565","2147483647","0","","","33","0","2018-08-14 07:57:29","2018-08-14 07:57:29","196"),
("258","Mubarak Al Kaber","AL Zuhar","gfhfhg","gfhfgth","56757","2147483647","0","","","34","0","2018-08-14 07:59:38","2018-08-14 07:59:38","196"),
("259","Mubarak Al Kaber","AL Zuhar","fdgsdfg","sgdfsgdf","65656","2147483647","0","","","34","0","2018-08-14 08:00:24","2018-08-14 08:00:24","196"),
("260","Mubarak Al Kaber","AL Fintas","dsfgs","sdf","34","2147483647","0","","","32","0","2018-08-14 08:53:10","2018-08-14 08:53:10","196"),
("261","Hawally","kuwait city","sdfg","sdfg","3453","2147483647","0","","","1","0","2018-08-14 08:53:45","2018-08-14 08:53:45","196"),
("262","Hawally","kuwait city","asdf","asd","232342","2147483647","0","","","1","0","2018-08-14 08:54:32","2018-08-14 08:54:32","196"),
("263","Hawally","Dasman","adfadsf","adfaf","3333","2147483647","0","","","2","0","2018-08-14 09:35:07","2018-08-14 09:35:07","196"),
("264","Mubarak Al Kaber","AL Aqila","dsfadsf","dfasdf","44444","2147483647","0","","","33","0","2018-08-14 09:38:48","2018-08-14 09:38:48","196"),
("265","Hawally","Dasman","dsa","wdwead","43344","2147483647","0","","","2","0","2018-08-14 09:40:07","2018-08-14 09:40:07","196"),
("266","Mubarak Al Kaber","AL Fintas","dfds","dsafds","3435","2147483647","0","","","32","0","2018-08-14 09:47:53","2018-08-14 09:47:53","196"),
("267","Mubarak Al Kaber","AL Aqila","sdfdf","dfdsf","435345","2147483647","0","","","33","0","2018-08-14 09:49:51","2018-08-14 09:49:51","196"),
("268","Mubarak Al Kaber","AL Zuhar","afadsf","dafdsf","44234","2147483647","0","","","34","0","2018-08-14 09:56:48","2018-08-14 09:56:48","196"),
("269","Mubarak Al Kaber","AL Aqila","adfa","adsfas","3452345","2147483647","0","","","33","0","2018-08-14 10:00:38","2018-08-14 10:00:38","196"),
("270","Hawally","Dasman","dfgf","sdfgsdfg","345345","2147483647","0","","","2","0","2018-08-14 10:02:34","2018-08-14 10:02:34","196"),
("271","Mubarak Al Kaber","AL Fintas","afdf","dafasdf","42343","2147483647","0","","","32","0","2018-08-14 10:03:14","2018-08-14 10:03:14","196"),
("272","Hawally","Dasman","fas","fads","345345","2147483647","0","","","2","0","2018-08-14 10:08:23","2018-08-14 10:08:23","196"),
("273","Mubarak Al Kaber","AL Fintas","dfgsdfg","dsfgdfsg","4544","2147483647","0","","","32","0","2018-08-14 10:15:02","2018-08-14 10:15:02","196"),
("274","Hawally","kuwait city","fd","fadsf","324523","2147483647","0","","","1","0","2018-08-14 10:24:00","2018-08-14 10:24:00","196"),
("275","Mubarak Al Kaber","AL Aqila","fsafad","dsfadsf","3434","2147483647","0","","","33","0","2018-08-14 10:26:33","2018-08-14 10:26:33","196"),
("276","Mubarak Al Kaber","AL Aqila","fadsfd","fdsafdsf","454","2147483647","0","","","33","0","2018-08-14 10:29:19","2018-08-14 10:29:19","196"),
("277","Al Farwanya","Abu Fteira","dsgdfs","fdsgsdf","5445","2147483647","0","","","69","0","2018-08-14 10:30:39","2018-08-14 10:30:39","196"),
("278","Mubarak Al Kaber","AL Fintas","dfadsf","dfadsf","45435","2147483647","0","","","32","0","2018-08-14 10:31:24","2018-08-14 10:31:24","196"),
("279","Mubarak Al Kaber","AL Fintas","asfds","dsafadsf","424234","2147483647","0","","","32","0","2018-08-14 10:33:16","2018-08-14 10:33:16","196"),
("280","Mubarak Al Kaber","AL Aqila","fdafads","dfadsf","34343","2147483647","0","","","33","0","2018-08-14 10:44:13","2018-08-14 10:44:13","196"),
("281","Mubarak Al Kaber","AL Aqila","fdfadsf","dsfadsfadsf","342342","2147483647","0","","","33","0","2018-08-14 11:00:11","2018-08-14 11:00:11","196"),
("282","Mubarak Al Kaber","AL Aqila","gdfsg","gsdfgsdfg","353454","2147483647","0","","","33","0","2018-08-14 11:02:00","2018-08-14 11:02:00","196"),
("283","Hawally","Dasman","dgdfg","dfgdfg","435345","2147483647","0","","","2","0","2018-08-14 11:06:37","2018-08-14 11:06:37","196"),
("284","Hawally","Dasman","sdaf","sdf","232342","2147483647","0","","","2","0","2018-08-14 11:31:58","2018-08-14 11:31:58","196"),
("285","Mubarak Al Kaber","AL Zuhar","Kuwait","Kuwait ","2147483647","2147483647","0","","","34","0","2018-08-16 13:16:54","2018-08-16 13:16:54","199"),
("286","Mubarak Al Kaber","AL Aqila","Kuwait ","Kuwait ","2147483647","2147483647","0","","","33","0","2018-08-16 13:34:50","2018-08-16 13:34:50","199"),
("287","Mubarak Al Kaber","AL Zuhar","Kuwait ","Kuwait ","2147483647","2147483647","0","","","34","0","2018-08-16 13:38:19","2018-08-16 13:38:19","199"),
("288","Hawally","kuwait city","gaff","sg","4334","2147483647","0","","","1","0","2018-08-17 04:24:27","2018-08-17 04:24:27","196"),
("289","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 06:50:01","2018-08-21 06:50:01","198"),
("290","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 06:50:24","2018-08-21 06:50:24","198"),
("291","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 06:52:46","2018-08-21 06:52:46","198"),
("292","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 06:54:23","2018-08-21 06:54:23","198"),
("293","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 06:54:39","2018-08-21 06:54:39","198"),
("294","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 06:55:24","2018-08-21 06:55:24","198"),
("295","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 06:56:02","2018-08-21 06:56:02","198"),
("296","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 06:56:15","2018-08-21 06:56:15","198"),
("297","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 06:56:27","2018-08-21 06:56:27","198"),
("298","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 08:35:54","2018-08-21 08:35:54","198"),
("299","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 08:37:26","2018-08-21 08:37:26","198"),
("300","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 08:38:05","2018-08-21 08:38:05","198"),
("301","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 08:38:34","2018-08-21 08:38:34","198"),
("302","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 08:38:59","2018-08-21 08:38:59","198"),
("303","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 08:40:25","2018-08-21 08:40:25","198");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_shipping_address` (`id`,`country`,`state`,`house_address`,`street`,`phone_number1`,`phone_number2`,`zipcode`,`lat`,`long`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("304","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 08:40:39","2018-08-21 08:40:39","198"),
("305","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 08:41:04","2018-08-21 08:41:04","198"),
("306","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 08:47:49","2018-08-21 08:47:49","198"),
("307","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 08:48:48","2018-08-21 08:48:48","198"),
("308","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 08:49:30","2018-08-21 08:49:30","198"),
("309","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 08:57:45","2018-08-21 08:57:45","198"),
("310","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 08:59:17","2018-08-21 08:59:17","198"),
("311","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 08:59:23","2018-08-21 08:59:23","198"),
("312","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 08:59:37","2018-08-21 08:59:37","198"),
("313","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 08:59:53","2018-08-21 08:59:53","198"),
("314","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:00:54","2018-08-21 09:00:54","198"),
("315","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:01:18","2018-08-21 09:01:18","198"),
("316","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:04:22","2018-08-21 09:04:22","198"),
("317","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:05:10","2018-08-21 09:05:10","198"),
("318","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:05:51","2018-08-21 09:05:51","198"),
("319","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:05:59","2018-08-21 09:05:59","198"),
("320","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:06:21","2018-08-21 09:06:21","198"),
("321","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:09:00","2018-08-21 09:09:00","198"),
("322","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:11:09","2018-08-21 09:11:09","198"),
("323","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:11:29","2018-08-21 09:11:29","198"),
("324","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:12:17","2018-08-21 09:12:17","198"),
("325","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:15:51","2018-08-21 09:15:51","198"),
("326","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:16:52","2018-08-21 09:16:52","198"),
("327","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:23:54","2018-08-21 09:23:54","198"),
("328","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:36:44","2018-08-21 09:36:44","198"),
("329","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:37:21","2018-08-21 09:37:21","198"),
("330","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:44:38","2018-08-21 09:44:38","198"),
("331","capital governorate","AL Qudsiya","1234","fvgrkuegoue","12341234","2147483647","0","","","20","0","2018-08-21 09:58:29","2018-08-21 09:58:29","198"),
("332","Mubarak Al Kaber","AL Aqila","rrr","rrr","85285","2147483647","0","","","33","0","2018-08-21 14:21:33","2018-08-21 14:21:33","174"),
("333","Mubarak Al Kaber","AL Aqila","56","45","2147483647","2147483647","0","","","33","0","2018-08-21 14:28:03","2018-08-21 14:28:03","174"),
("334","Hawally","kuwait city","add","asdf","242342","2147483647","0","","","1","0","2018-08-22 04:19:25","2018-08-22 04:19:25","196"),
("335","Mubarak Al Kaber","AL Aqila","67","g","2147483647","2147483647","0","","","33","0","2018-08-22 04:28:07","2018-08-22 04:28:07","174"),
("336","Hawally","kuwait city","staff","staff","3453555","2147483647","0","","","0","0","2018-08-22 05:03:21","2018-08-22 05:03:21","174"),
("337","Hawally","kuwait city","staff","staff","3453555","2147483647","0","","","0","0","2018-08-22 05:03:26","2018-08-22 05:03:26","174"),
("338","Hawally","kuwait city","sdf","sdfg","343453","2147483647","0","","","1","0","2018-08-22 05:06:07","2018-08-22 05:06:07","174"),
("339","Hawally","Dasman","dad","asas","3223","2147483647","0","","","2","0","2018-08-22 06:34:11","2018-08-22 06:34:11","196"),
("340","Hawally","Dasman","asdf","asdf","2323","2147483647","0","","","2","0","2018-08-22 06:35:37","2018-08-22 06:35:37","196"),
("341","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:21:12","2018-08-22 07:21:12","174"),
("342","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:22:07","2018-08-22 07:22:07","174"),
("343","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:22:29","2018-08-22 07:22:29","174"),
("344","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:23:52","2018-08-22 07:23:52","174"),
("345","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:24:13","2018-08-22 07:24:13","174"),
("346","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:24:15","2018-08-22 07:24:15","174"),
("347","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:26:10","2018-08-22 07:26:10","174"),
("348","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:27:09","2018-08-22 07:27:09","174"),
("349","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:27:59","2018-08-22 07:27:59","174"),
("350","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:29:05","2018-08-22 07:29:05","174"),
("351","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:30:19","2018-08-22 07:30:19","174"),
("352","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:31:31","2018-08-22 07:31:31","174"),
("353","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:31:34","2018-08-22 07:31:34","174"),
("354","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:31:38","2018-08-22 07:31:38","174"),
("355","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:31:40","2018-08-22 07:31:40","174"),
("356","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:32:00","2018-08-22 07:32:00","174"),
("357","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:32:56","2018-08-22 07:32:56","174"),
("358","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:34:51","2018-08-22 07:34:51","174"),
("359","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:37:25","2018-08-22 07:37:25","174"),
("360","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:38:53","2018-08-22 07:38:53","174"),
("361","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:41:25","2018-08-22 07:41:25","174"),
("362","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:41:28","2018-08-22 07:41:28","174"),
("363","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:41:30","2018-08-22 07:41:30","174"),
("364","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:41:32","2018-08-22 07:41:32","174"),
("365","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:41:34","2018-08-22 07:41:34","174"),
("366","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:41:36","2018-08-22 07:41:36","174"),
("367","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:41:39","2018-08-22 07:41:39","174"),
("368","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:41:41","2018-08-22 07:41:41","174"),
("369","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:41:43","2018-08-22 07:41:43","174"),
("370","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:41:45","2018-08-22 07:41:45","174"),
("371","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:41:47","2018-08-22 07:41:47","174"),
("372","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:41:50","2018-08-22 07:41:50","174"),
("373","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:41:52","2018-08-22 07:41:52","174"),
("374","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:44:17","2018-08-22 07:44:17","174"),
("375","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:44:22","2018-08-22 07:44:22","174"),
("376","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 07:48:22","2018-08-22 07:48:22","174"),
("377","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 08:34:04","2018-08-22 08:34:04","174"),
("378","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 08:34:12","2018-08-22 08:34:12","174"),
("379","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 08:48:35","2018-08-22 08:48:35","174"),
("380","Mohali","Chd","#56","7/6","2147483647","576756758","0","","","5","0","2018-08-22 08:48:46","2018-08-22 08:48:46","174"),
("381","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 09:00:52","2018-08-22 09:00:52","174"),
("382","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 09:03:07","2018-08-22 09:03:07","174"),
("383","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 09:05:16","2018-08-22 09:05:16","174"),
("384","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 09:22:20","2018-08-22 09:22:20","174"),
("385","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 09:22:24","2018-08-22 09:22:24","174"),
("386","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 09:23:46","2018-08-22 09:23:46","174"),
("387","Hawally","kuwait city","sdfg","asdf","2342342","2147483647","0","","","1","0","2018-08-22 09:29:33","2018-08-22 09:29:33","196"),
("388","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 09:32:43","2018-08-22 09:32:43","196"),
("389","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 09:37:49","2018-08-22 09:37:49","196"),
("390","Hawally","Dasman","sadfa","sdf","232223423","2147483647","0","","","2","0","2018-08-22 09:42:39","2018-08-22 09:42:39","196"),
("391","Mubarak Al Kaber","AL Fintas","sofas","asdf","32234","2147483647","0","","","32","0","2018-08-22 09:44:35","2018-08-22 09:44:35","196"),
("392","Hawally","kuwait city","asdf","asdf","23234","2147483647","0","","","1","0","2018-08-22 09:56:59","2018-08-22 09:56:59","196"),
("393","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 10:00:31","2018-08-22 10:00:31","196"),
("394","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 10:21:17","2018-08-22 10:21:17","196"),
("395","Hawally","Sharq","dfsg","sdfg","344","2147483647","0","","","3","0","2018-08-22 10:27:11","2018-08-22 10:27:11","196"),
("396","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 10:32:12","2018-08-22 10:32:12","196"),
("397","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 10:41:00","2018-08-22 10:41:00","196"),
("398","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 10:42:10","2018-08-22 10:42:10","196"),
("399","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 10:42:25","2018-08-22 10:42:25","196"),
("400","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 10:46:01","2018-08-22 10:46:01","196"),
("401","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 10:46:04","2018-08-22 10:46:04","196"),
("402","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 10:46:12","2018-08-22 10:46:12","196"),
("403","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 10:46:49","2018-08-22 10:46:49","196");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_shipping_address` (`id`,`country`,`state`,`house_address`,`street`,`phone_number1`,`phone_number2`,`zipcode`,`lat`,`long`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("404","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 10:47:40","2018-08-22 10:47:40","196"),
("405","Mohali","Chd","#56","7/6","2147483647","2147483647","0","","","5","0","2018-08-22 10:49:12","2018-08-22 10:49:12","196"),
("406","Hawally","kuwait city","dsaf","asdfs add","2323","2147483647","0","","","1","0","2018-08-22 11:34:24","2018-08-22 11:34:24","196"),
("407","Hawally","Dasman","adds","asdf","32234","2147483647","0","","","0","0","2018-08-23 05:12:03","2018-08-23 05:12:03","202"),
("408","Hawally","AL Sawabir","asdfas","asdf","223","2147483647","0","","","4","0","2018-08-23 05:17:56","2018-08-23 05:17:56","202"),
("409","Hawally","AL Sawabir","Ed","staff","3232","2147483647","0","","","4","0","2018-08-23 05:36:59","2018-08-23 05:36:59","202"),
("410","Hawally","Dasman","67","you","1236547896","2147483647","0","","","0","0","2018-08-23 09:40:24","2018-08-23 09:40:24","203"),
("411","Mubarak Al Kaber","AL Aqila","5","ghh","555555523","2147483647","0","","","33","0","2018-08-23 10:04:08","2018-08-23 10:04:08","203"),
("412","Mubarak Al Kaber","AL Aqila","3","z","2147483647","2147483647","0","","","33","0","2018-08-23 10:06:52","2018-08-23 10:06:52","203"),
("413","Mubarak Al Kaber","AL Aqila","t","t","555555555","2147483647","0","","","33","0","2018-08-23 10:09:25","2018-08-23 10:09:25","203"),
("414","Hawally","Dasman","ssh","Bsbs","4545","2147483647","0","","","2","0","2018-08-23 10:21:18","2018-08-23 10:21:18","202"),
("415","Hawally","kuwait city","asdfasdfas","sdf","32423","23423423","0","","","1","0","2018-08-23 10:24:15","2018-08-23 10:24:15","202"),
("416","Mubarak Al Kaber","AL Aqila","t","u","85285236","2147483647","0","","","33","0","2018-08-23 10:25:49","2018-08-23 10:25:49","203"),
("417","Mubarak Al Kaber","AL Aqila","23","g","5","852555555","0","","","33","0","2018-08-23 11:03:36","2018-08-23 11:03:36","203"),
("418","Hawally","kuwait city","tttt","gggff","55555555","2147483647","0","","","1","0","2018-08-23 11:18:13","2018-08-23 11:18:13","203");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_size` (`id`,`title`,`symbol`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("1","Large","L","1","0","2018-03-30 10:17:02","2018-03-30 10:17:02","1"),
("2","Extra Large","XL","1","0","2018-03-30 10:17:22","2018-03-30 10:17:22","1"),
("3","medium","m","1","0","2018-03-31 12:20:42","2018-03-31 12:20:42","1"),
("6","small","s","0","0","2018-03-31 12:25:14","2018-03-31 12:25:14","1"),
("9","M","","1","0","2018-04-11 15:17:39","2018-04-11 15:17:39","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_state` (`id`,`state`,`country_id`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("1","kuwait city","1","1","0","2018-05-10 11:24:30","2018-05-10 11:24:30","1"),
("2","Dasman","1","1","0","2018-05-10 11:25:17","2018-05-10 11:25:17","1"),
("3","Sharq","1","1","0","2018-05-10 11:26:16","2018-05-10 11:26:16","1"),
("4","AL Sawabir","1","1","0","2018-05-10 11:26:25","2018-05-10 11:26:25","1"),
("5","AL Mirgab","1","1","0","2018-05-10 11:26:33","2018-05-10 11:26:33","1"),
("6","AL Jibla","1","1","0","2018-05-10 11:26:42","2018-05-10 11:26:42","1"),
("7","AL Salhiya","1","1","0","2018-05-10 11:26:51","2018-05-10 11:26:51","1"),
("8","AL Watiya","1","1","0","2018-05-10 11:27:01","2018-05-10 11:27:01","1"),
("9","Bneid EL Gar","1","1","0","2018-05-10 11:27:14","2018-05-10 11:27:14","1"),
("10","Kaifan","1","1","0","2018-05-10 11:27:27","2018-05-10 11:27:27","1"),
("11","AL Dasma","1","1","0","2018-05-10 11:27:36","2018-05-10 11:27:36","1"),
("12","AL Da\"iya","1","1","0","2018-05-10 11:27:53","2018-05-10 11:27:53","1"),
("13","AL Mansuriya","1","1","0","2018-05-10 11:28:03","2018-05-10 11:28:03","1"),
("14","Abdul Allah Al Salem","1","1","0","2018-05-10 11:28:16","2018-05-10 11:28:16","1"),
("15","AL Nuzha","1","1","0","2018-05-10 11:28:28","2018-05-10 11:28:28","1"),
("16","AL Faihaa","1","1","0","2018-05-10 11:28:37","2018-05-10 11:28:37","1"),
("17","AL Shamiya _ AL Rawda","1","1","0","2018-05-10 11:28:49","2018-05-10 11:28:49","1"),
("18","AL Adiliya","1","1","0","2018-05-10 11:29:35","2018-05-10 11:29:35","1"),
("19","AL Khaldiya","1","1","0","2018-05-10 11:30:18","2018-05-10 11:30:18","1"),
("20","AL Qudsiya","1","1","0","2018-05-10 11:30:57","2018-05-10 11:30:57","1"),
("21","Qurtuba","1","1","0","2018-05-10 11:31:12","2018-05-10 11:31:12","1"),
("22","AL Surra","1","1","0","2018-05-10 11:31:23","2018-05-10 11:31:23","1"),
("23","AL Yarmuk","1","1","0","2018-05-10 11:31:33","2018-05-10 11:31:33","1"),
("24","AL Shuwaikh","1","1","0","2018-05-10 11:32:07","2018-05-10 11:32:07","1"),
("25","AL Rai","1","1","0","2018-05-10 11:33:11","2018-05-10 11:33:11","1"),
("26","Ghirnata","1","1","0","2018-05-10 11:35:30","2018-05-10 11:35:30","1"),
("27","AL Doha","1","1","0","2018-05-10 11:35:47","2018-05-10 11:35:47","1"),
("28","AL Nahda","1","1","0","2018-05-10 11:35:59","2018-05-10 11:35:59","1"),
("29","Jaber AL Ahmed","1","1","0","2018-05-10 11:36:44","2018-05-10 11:36:44","1"),
("30","AL Qairawan","1","1","0","2018-05-10 11:37:03","2018-05-10 11:37:03","1"),
("31","AL Sulaibikhat","1","1","0","2018-05-10 11:37:12","2018-05-10 11:37:12","1"),
("32","AL Fintas","2","1","0","2018-05-10 11:37:32","2018-05-10 11:37:32","1"),
("33","AL Aqila","2","1","0","2018-05-10 11:37:44","2018-05-10 11:37:44","1"),
("34","AL Zuhar","2","1","0","2018-05-10 11:37:52","2018-05-10 11:37:52","1"),
("35","AL Mahbula","2","1","0","2018-05-10 11:38:01","2018-05-10 11:38:01","1"),
("36","AL Rigga","2","1","0","2018-05-10 11:38:12","2018-05-10 11:38:12","1"),
("37","Hadiya","2","1","0","2018-05-10 11:38:23","2018-05-10 11:38:23","1"),
("38","Abu Hulaifa","2","1","0","2018-05-10 11:38:33","2018-05-10 11:38:33","1"),
("39","AL Sabahiya","2","1","0","2018-05-10 11:38:43","2018-05-10 11:38:43","1"),
("40","AL Mangaf","2","1","0","2018-05-10 11:38:54","2018-05-10 11:38:54","1"),
("41","AL Fahaheel","2","1","0","2018-05-10 11:39:05","2018-05-10 11:39:05","1"),
("42","AL Ahmadi","2","1","0","2018-05-10 11:39:16","2018-05-10 11:39:16","1"),
("43","Bneidar","2","1","0","2018-05-10 11:39:27","2018-05-10 11:39:27","1"),
("44","Jaber AK Ali","2","1","0","2018-05-10 11:39:37","2018-05-10 11:39:37","1"),
("45","Fahd AL Ahmed","2","1","0","2018-05-10 11:39:47","2018-05-10 11:39:47","1"),
("46","Subah AL Ahmed","2","1","0","2018-05-10 11:39:58","2018-05-10 11:39:58","1"),
("47","Al Andalus","2","1","0","2018-05-10 11:40:14","2018-05-10 11:40:14","1"),
("48","Ishbillia","2","1","0","2018-05-10 11:40:24","2018-05-10 11:40:24","1"),
("49","Jleeb Al Sh","2","1","0","2018-05-10 11:40:40","2018-05-10 11:40:40","1"),
("50","Khitan","2","1","0","2018-05-10 11:40:50","2018-05-10 11:40:50","1"),
("51","AL Omariya","2","1","0","2018-05-10 11:41:01","2018-05-10 11:41:01","1"),
("52","AL Ardiya","2","1","0","2018-05-10 11:44:09","2018-05-10 11:44:09","1"),
("53","Industrial Ardiya","2","1","0","2018-05-10 11:44:18","2018-05-10 11:44:18","1"),
("54","AL AbASSIYA","2","1","0","2018-05-10 11:44:31","2018-05-10 11:44:31","1"),
("55","AL Fordous","2","1","0","2018-05-10 11:44:39","2018-05-10 11:44:39","1"),
("56","AL Frwaniya","2","1","0","2018-05-10 11:44:57","2018-05-10 11:44:57","1"),
("57","AL Rabiya","2","1","0","2018-05-10 11:45:07","2018-05-10 11:45:07","1"),
("58","AL Rihab","2","1","0","2018-05-10 11:45:18","2018-05-10 11:45:18","1"),
("59","AL Rigey","2","1","0","2018-05-10 11:45:28","2018-05-10 11:45:28","1"),
("60","AL Rai Al sinaaya","2","1","0","2018-05-10 11:45:37","2018-05-10 11:45:37","1"),
("61","sSubah Al Nasser","2","1","0","2018-05-10 11:45:47","2018-05-10 11:45:47","1"),
("62","Abdul Allah Al Mubark","2","1","0","2018-05-10 11:45:57","2018-05-10 11:45:57","1"),
("63","AL Dajeej","2","1","0","2018-05-10 11:46:07","2018-05-10 11:46:07","1"),
("64","AL Adan","2","1","0","2018-05-10 11:46:18","2018-05-10 11:46:18","1"),
("65","AL Qusur","2","1","0","2018-05-10 11:46:29","2018-05-10 11:46:29","1"),
("66","AL Qurain","2","1","0","2018-05-10 11:46:41","2018-05-10 11:46:41","1"),
("67","Subah AL Salem suburb","3","1","0","2018-05-10 11:46:56","2018-05-10 11:46:56","1"),
("68","AL Misila","3","1","0","2018-05-10 11:47:07","2018-05-10 11:47:07","1"),
("69","Abu Fteira","3","1","0","2018-05-10 11:47:17","2018-05-10 11:47:17","1"),
("70","Sabhan","3","1","0","2018-05-10 11:47:29","2018-05-10 11:47:29","1"),
("71","AL Fintas","3","1","0","2018-05-10 11:47:43","2018-05-10 11:47:43","1"),
("72","AL Funaitis","3","1","0","2018-05-10 11:47:52","2018-05-10 11:47:52","1"),
("73","Hawally","3","1","0","2018-05-10 11:48:01","2018-05-10 11:48:01","1"),
("74","AL Rumaithiya","3","1","0","2018-05-10 11:48:13","2018-05-10 11:48:13","1"),
("75","AL Habriya","3","1","0","2018-05-10 11:48:23","2018-05-10 11:48:23","1"),
("76","AL Salmiya","3","1","0","2018-05-10 11:48:33","2018-05-10 11:48:33","1"),
("77","Mishrif","4","1","0","2018-05-10 11:49:10","2018-05-10 11:49:10","1"),
("78","AL Shaab","4","1","0","2018-05-10 11:49:20","2018-05-10 11:49:20","1"),
("79","Bayan","4","1","0","2018-05-10 11:49:28","2018-05-10 11:49:28","1"),
("80","AL Bidi","4","1","0","2018-05-10 11:49:36","2018-05-10 11:49:36","1"),
("81","ALNigra","4","1","0","2018-05-10 11:49:44","2018-05-10 11:49:44","1"),
("82","Salwa","4","1","0","2018-05-10 11:49:51","2018-05-10 11:49:51","1"),
("83","Maidan Hawally","4","1","0","2018-05-10 11:49:59","2018-05-10 11:49:59","1"),
("84","Mubarak AL Jaber","4","1","0","2018-05-10 11:50:08","2018-05-10 11:50:08","1"),
("85","South Surra","4","1","0","2018-05-10 11:50:18","2018-05-10 11:50:18","1"),
("86","Hittin","4","1","0","2018-05-10 11:50:27","2018-05-10 11:50:27","1");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_super_order` (`id`,`order_number`,`shipping_address_id`,`payment_mode`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("91","4763","71","0","4","0","2018-05-14 17:13:58","2018-07-05 11:25:49","1"),
("92","F593","72","0","1","0","2018-05-14 17:17:30","2018-05-14 17:17:30","118"),
("103","CA38","83","0","1","0","2018-06-19 08:37:50","2018-06-19 08:37:50","131"),
("104","EA84","84","0","1","0","2018-06-19 09:57:30","2018-06-19 09:57:30","133"),
("105","7769","85","0","1","0","2018-06-19 10:24:54","2018-06-19 10:24:54","131"),
("106","787F","86","0","1","0","2018-06-20 07:46:19","2018-06-20 07:46:19","137"),
("107","9872","87","0","1","0","2018-06-22 15:14:52","2018-06-22 15:14:52","137"),
("109","8885","89","0","1","0","2018-06-27 10:56:10","2018-06-27 10:56:10","143"),
("111","FB50","91","0","1","0","2018-06-27 14:11:22","2018-06-27 14:11:22","145"),
("112","D4DD","92","0","1","0","2018-07-01 13:00:47","2018-07-01 13:00:47","146"),
("113","0212","93","0","1","0","2018-07-02 11:47:41","2018-07-02 11:47:41","147"),
("116","DBF8","116","0","1","0","2018-07-05 12:41:21","2018-07-05 12:41:21","1"),
("117","D04A","117","0","4","0","2018-07-05 12:47:05","2018-07-06 10:12:55","148"),
("118","BC3A","118","0","1","0","2018-07-06 11:56:35","2018-07-06 11:56:35","150"),
("121","8ABE","121","0","1","0","2018-07-22 14:01:59","2018-07-22 14:01:59","147"),
("126","E64C","126","0","1","0","2018-08-04 22:24:10","2018-08-04 22:24:10","186"),
("129","BFDB","129","0","1","0","2018-08-08 11:13:17","2018-08-08 11:13:17","113"),
("130","9606","130","0","1","0","2018-08-08 11:15:07","2018-08-08 11:15:07","113"),
("131","3CB1","131","0","1","0","2018-08-08 11:18:13","2018-08-08 11:18:13","113"),
("132","0FD8","132","0","1","0","2018-08-08 12:57:15","2018-08-08 12:57:15","113"),
("133","C95F","133","0","1","0","2018-08-08 13:09:05","2018-08-08 13:09:05","113"),
("134","AF1D","134","0","1","0","2018-08-08 13:12:36","2018-08-08 13:12:36","113"),
("135","47B1","135","0","1","0","2018-08-08 13:14:18","2018-08-08 13:14:18","113"),
("141","E0E5","150","0","1","0","2018-08-10 05:43:41","2018-08-10 05:43:41","113"),
("142","3F85","151","0","1","0","2018-08-10 05:44:05","2018-08-10 05:44:05","113"),
("143","576E","152","0","1","0","2018-08-10 05:46:30","2018-08-10 05:46:30","113"),
("144","4697","153","0","1","0","2018-08-10 05:47:00","2018-08-10 05:47:00","113"),
("150","3B44","159","0","1","0","2018-08-10 09:00:39","2018-08-10 09:00:39","113"),
("151","599D","160","0","1","0","2018-08-10 09:01:00","2018-08-10 09:01:00","113"),
("152","713E","161","0","1","0","2018-08-10 09:01:56","2018-08-10 09:01:56","113"),
("153","AA4C","164","0","1","0","2018-08-10 09:02:55","2018-08-10 09:02:55","113"),
("154","1203","165","0","1","0","2018-08-10 09:03:42","2018-08-10 09:03:42","113"),
("157","6190","169","0","1","0","2018-08-10 09:26:48","2018-08-10 09:26:48","113"),
("158","840D","171","0","1","0","2018-08-10 09:28:11","2018-08-10 09:28:11","113"),
("159","C39F","172","0","1","0","2018-08-10 09:29:09","2018-08-10 09:29:09","113"),
("161","CEF0","174","0","1","0","2018-08-10 09:36:40","2018-08-10 09:36:40","113"),
("162","1955","177","0","1","0","2018-08-10 09:37:39","2018-08-10 09:37:39","198"),
("163","9CD7","178","0","1","0","2018-08-10 09:38:36","2018-08-10 09:38:36","198"),
("164","12B9","179","0","1","0","2018-08-10 09:40:01","2018-08-10 09:40:01","198"),
("270","7BA3","285","0","1","0","2018-08-16 13:16:54","2018-08-16 13:16:54","199"),
("271","A0FD","286","0","1","0","2018-08-16 13:34:50","2018-08-16 13:34:50","199"),
("272","B314","287","0","1","0","2018-08-16 13:38:19","2018-08-16 13:38:19","199"),
("274","2D35","297","0","1","0","2018-08-21 06:56:27","2018-08-21 06:56:27","198"),
("275","3D3F","298","0","1","0","2018-08-21 08:35:54","2018-08-21 08:35:54","198"),
("276","346D","300","0","1","0","2018-08-21 08:38:05","2018-08-21 08:38:05","198"),
("277","A07C","301","0","1","0","2018-08-21 08:38:34","2018-08-21 08:38:34","198"),
("278","827C","302","0","1","0","2018-08-21 08:38:59","2018-08-21 08:38:59","198"),
("279","79CC","303","0","1","0","2018-08-21 08:40:25","2018-08-21 08:40:25","198"),
("280","513A","304","0","1","0","2018-08-21 08:40:39","2018-08-21 08:40:39","198"),
("281","A2E4","305","0","1","0","2018-08-21 08:41:04","2018-08-21 08:41:04","198"),
("282","B1AF","306","0","1","0","2018-08-21 08:47:49","2018-08-21 08:47:49","198"),
("283","E6DD","307","0","1","0","2018-08-21 08:48:48","2018-08-21 08:48:48","198"),
("284","7E01","308","0","1","0","2018-08-21 08:49:30","2018-08-21 08:49:30","198"),
("285","5676","309","0","1","0","2018-08-21 08:57:45","2018-08-21 08:57:45","198"),
("286","B5D1","310","0","1","0","2018-08-21 08:59:17","2018-08-21 08:59:17","198"),
("287","104F","311","0","1","0","2018-08-21 08:59:23","2018-08-21 08:59:23","198"),
("288","F195","312","0","1","0","2018-08-21 08:59:37","2018-08-21 08:59:37","198"),
("289","3B59","313","0","1","0","2018-08-21 08:59:53","2018-08-21 08:59:53","198"),
("290","FF96","314","0","1","0","2018-08-21 09:00:54","2018-08-21 09:00:54","198"),
("291","77DC","316","0","1","0","2018-08-21 09:04:22","2018-08-21 09:04:22","198"),
("292","DC94","317","0","1","0","2018-08-21 09:05:10","2018-08-21 09:05:10","198"),
("293","87D4","318","0","1","0","2018-08-21 09:05:51","2018-08-21 09:05:51","198"),
("294","DDC9","319","0","1","0","2018-08-21 09:05:59","2018-08-21 09:05:59","198"),
("295","5AC2","320","0","1","0","2018-08-21 09:06:21","2018-08-21 09:06:21","198"),
("296","1C7F","321","0","1","0","2018-08-21 09:09:00","2018-08-21 09:09:00","198"),
("297","FD13","322","0","1","0","2018-08-21 09:11:09","2018-08-21 09:11:09","198"),
("298","C674","323","0","1","0","2018-08-21 09:11:29","2018-08-21 09:11:29","198"),
("299","CF6E","324","0","1","0","2018-08-21 09:12:17","2018-08-21 09:12:17","198"),
("300","A8ED","325","0","1","0","2018-08-21 09:15:51","2018-08-21 09:15:51","198"),
("301","0653","326","0","1","0","2018-08-21 09:16:52","2018-08-21 09:16:52","198"),
("302","8B75","327","0","1","0","2018-08-21 09:23:54","2018-08-21 09:23:54","198"),
("303","DF4F","328","0","1","0","2018-08-21 09:36:44","2018-08-21 09:36:44","198"),
("304","51B4","329","0","1","0","2018-08-21 09:37:21","2018-08-21 09:37:21","198"),
("305","8CCD","330","0","1","0","2018-08-21 09:44:38","2018-08-21 09:44:38","198"),
("306","FEFD","331","0","1","0","2018-08-21 09:58:29","2018-08-21 09:58:29","198"),
("376","A747","407","0","1","0","2018-08-23 05:12:03","2018-08-23 05:12:03","202"),
("377","F2E5","408","0","1","0","2018-08-23 05:17:56","2018-08-23 05:17:56","202"),
("378","8C6B","409","0","1","0","2018-08-23 05:36:59","2018-08-23 05:36:59","202"),
("379","13B8","410","0","1","0","2018-08-23 09:40:24","2018-08-23 09:40:24","203"),
("380","3891","411","0","1","0","2018-08-23 10:04:08","2018-08-23 10:04:08","203"),
("381","8BAB","412","0","1","0","2018-08-23 10:06:52","2018-08-23 10:06:52","203"),
("382","40A7","413","0","1","0","2018-08-23 10:09:25","2018-08-23 10:09:25","203"),
("383","4463","414","0","1","0","2018-08-23 10:21:18","2018-08-23 10:21:18","202"),
("384","527F","415","0","1","0","2018-08-23 10:24:15","2018-08-23 10:24:15","202"),
("385","0D97","416","0","1","0","2018-08-23 10:25:49","2018-08-23 10:25:49","203"),
("386","E7D9","417","0","1","0","2018-08-23 11:03:36","2018-08-23 11:03:36","203"),
("387","FA0D","418","0","1","0","2018-08-23 11:18:13","2018-08-23 11:18:13","203");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_user` (`id`,`first_name`,`last_name`,`full_name`,`email`,`password`,`date_of_birth`,`gender`,`about_me`,`contact_no`,`location_tracking`,`address`,`latitude`,`longitude`,`city`,`country`,`contact_no_1`,`zipcode`,`language`,`email_verified`,`profile_file`,`tos`,`role_id`,`is_customer`,`is_vendor`,`state_id`,`type_id`,`last_visit_time`,`last_action_time`,`last_password_change`,`login_error_count`,`activation_key`,`access_token`,`timezone`,`created_on`,`updated_on`,`created_by_id`) VALUES
("1","","","admin","admin@yeswa.shop","$2y$13$DvtYmwKOW9WV4PSprmm9DOup2Ye.E8Cas1AUYvgw0gXey6wYEFA2G","","0","","","0","","","","","","","","","0","user-1522756601-profile_fileuser_id_1.gif","0","0","0","0","1","0","2018-08-27 11:22:42","","","0","bUQUawNBm8AYUCuynE1pk-cfnf4OKL6o_1522501596","49WbC4oIc-SgPtOyEsfUiX0Rjta-n9Nt","","2018-03-28 13:10:45","2018-08-27 11:22:42","0"),
("2","","","Sonu Sharma","sonu.sharma@toxsltech.com","$2y$13$FoRHKHsWsIS0BAlj8879cuMVr/TnRREDlGh2hmDeoTN6VjSeC/dci","","0","","21364","1","","","","","","546434","","","0","","0","2","1","1","1","0","2018-07-24 05:16:16","","","0","","VW7OU3nJ2QU76eG7EN_MzyO2E0CWDKYX","","2018-03-28 13:11:48","2018-07-24 05:16:16","1"),
("10","","","Colten Marquardt","kirlin.shanon@gmail.com","$2y$13$BgMEoK2AWkgaVKlRWyjLH.ZNMsOR2GA7R1X6FTX4bFVQhXQScqIKS","","0","","10","1","","","","","","","","","0","","0","2","1","0","1","0","","","","0","","vgTBujA3RwJ_3jLocWZ546YSCSyYFlF6","","2018-03-28 14:37:18","2018-03-28 14:37:18","2"),
("13","","","Sony","sony@toxsltech.com","$2y$13$.mIc3e.kY.REqXVPicfQsu4JJ0Kx1/hn0pmh2HO/7taIWAhS4FNBS","","0","","","0","","","","","","","","","0","","0","2","1","0","1","0","2018-03-29 10:52:36","","","0","Z7Ym6RLGiYbFCVm2CVe_5AoHCucZBQDY_1522302498","IIO6VHh33Y04a7bVEAdDnK8_eV0jJAI6","","2018-03-29 10:51:54","2018-03-29 11:18:18","12"),
("15","","","Mona Cassin","ven@toxsl.in","$2y$13$9mmWfxSYU6I55n6vvFSwsuWDCZnlV6WF29Wjo/qAzhca0Wl9gj8US","","0","","10","0","","","","","","","","","0","","0","1","1","0","1","0","2018-06-27 06:48:30","","","0","VIovnPncTuUV4FIU7zrG5HyLJRjbKOpo_1522304061","humhKPKMCX2lgWdj897tUhZlURH9qT19","","2018-03-29 11:27:26","2018-06-27 06:48:30","1"),
("22","","","rosy","r@t.in","$2y$13$j5HdaqJTwfROaRQ4Qgfq6u.5NDTRQa7TTvNgzLVWohCta0/S/q1Yq","","0","","","0","","","","","","","","","0","","0","2","1","0","1","0","","","","0","","JQdbMaVMd2uR535CFgIHxYF-wyZMO9sn","","2018-03-29 16:04:22","2018-03-29 16:04:22","0"),
("48","","","baba","manu@t.in","$2y$13$Z8II9ukSLPZrqjJZi82aRuSCJ/Y37eADSoKWf3M2dysypS5gvbdgi","","0","","","0","","","","","","","","","0","","0","2","1","0","1","0","","","","0","","cOLsJn2_t-0Jf_xOQMFTSzJSgmLwQ6zt","","2018-03-29 18:14:10","2018-03-29 18:14:10","0"),
("54","","","Customer","s@gmail.com","$2y$13$PnsO6GwpJ3SZgldxJA3UtO1wR44VhnrIaw10BaSpLAfXxzrOVvSm6","","0","","1234123412","0","","","","","","","","","0","user-1522762803-profile_fileuser_id_54.png","0","2","1","0","1","0","2018-04-05 18:26:10","","","0","","nAWJdLgPYvoykdzQcvvmkXiMFlXLt2v4","","2018-04-03 18:45:25","2018-04-05 18:26:10","0"),
("60","","","Vipin","s@t.in","$2y$13$ckveBzd553HgqJz44.Zb3ekDLuBfxbmTCugDrgD3gIbDcr7SIoLLm","","0","","","0","","","","","","","","","0","user-1523450465-profile_fileuser_id_60.png","0","2","1","0","1","0","2018-04-11 18:44:09","","","0","gXZoeAlCunbZtzt3lwDwZmiv2tmIW763_1523450410","0kKsPi7KhOjsvSznW5y-3O6AUIKWOPyN","","2018-04-11 18:09:50","2018-04-11 18:44:09","0"),
("66","","","Munera","muneraalrashidi@gmail.com","$2y$13$j2lWlvjhJaZ9ZEBBTPtVG.Ty.wVj0IQjc6pIvjD.W7Pn7lGqSJ4RK","","0","","46576664","0","","","","","","","","","0","","0","1","1","1","1","0","2018-04-19 20:53:27","","","0","6g8jWwK_pWwS5ziXXegOo9_zpcbMh3PT_1533130650","vZpKKt9a4vm45ceAdd6xHFslf57-G9pq","","2018-04-11 19:48:36","2018-08-01 13:37:30","0"),
("69","","","customer","customer1@gmail.com","$2y$13$u7U7SR9Afqzrae45sFyR5O8noVuSSKMVKQB3R8i0ZesXG29lsKdXi","","0","","","0","","","","","","","","","0","","0","2","1","0","1","0","2018-04-16 10:29:44","","","0","","YTzy46Na80R2AE65RRvoVdtOkRoNUrLR","","2018-04-16 10:24:53","2018-04-16 10:29:44","0"),
("70","","","new","new@c.in","$2y$13$Hvnqg.RSKioKA2BgaMMx0uZyoI1HZdHOelQ3xOvKr3iFOrlouPrmO","","0","","","0","","","","","","","","","0","","0","2","1","0","1","0","2018-04-16 11:03:10","","","0","","XNAuIeSYp6XcPl3vdZ08_SbTw-Ted62J","","2018-04-16 10:52:44","2018-04-16 11:03:10","0"),
("71","","","hello","YESWA@gmail.com","$2y$13$fH5pD6rN8.WwlyIQs4s5hOcQgRDttGyMXhwR6YWeAibuGbDLkoZni","","0","","","0","","","","","","","","","0","","0","2","1","1","1","0","2018-04-16 12:07:28","","","0","","Ey2_YUFH1vN7ZdMfSEOcQbR0uhkIhvR7","","2018-04-16 11:43:39","2018-04-16 12:07:28","0"),
("73","","","new","shonu@gmail.com","$2y$13$uBVCkItoYU8bYGnvjwrZR.vCZj3BJ5chzNezWmowQQnNhU18q5TSC","","0","","134134333","0","","","","","","","","","0","","0","1","1","1","1","0","2018-04-16 14:44:05","","","0","","_LfD2jGUiJORxEpcjxnhHkEy8svWywR_","","2018-04-16 14:38:58","2018-04-16 14:44:05","0"),
("74","","","staff","add@t.in","$2y$13$WDGO/0Jgy3xVnNO7fKqfAOt5de2NDCb9R.vM.fS992okdB.hifubG","","0","","","0","","","","","","","","","0","","0","2","1","0","1","0","","","","0","","c2bpJZavfbQnXb5unzw1eZ6YKyU2SnX_","","2018-04-16 14:54:27","2018-04-16 14:54:27","0"),
("76","","","munera","munera@gmail.com","$2y$13$mrCGM0Vn.uEVLy2rUZFbXOXty5PbwKvJjjw6kab8.FgmWYEet3x72","","0","","","0","","","","","","","","","0","","0","2","1","0","1","0","2018-04-20 03:11:25","","","0","","bZY7J1GcOv203JreNzPpGmCtrq4_G_Ol","","2018-04-20 00:18:07","2018-04-20 03:11:25","0"),
("77","","","muneraa","muneramunera@gmail.com","$2y$13$e0TJz.r9.QFG6fe9ffIWY.0/R05RnRI2ahVFsTLved3zF0Z9JfnoC","","0","","767894","0","","","","","","","","","0","","0","1","1","1","1","0","2018-05-01 15:46:39","","","0","","UlQSUBPuB8g2srwol35ZDXGCUjgfeL_f","","2018-04-21 20:54:20","2018-05-01 15:46:39","0"),
("80","","","Sony","sonycustomer@gmail.in","$2y$13$1gE7YC5Imrkk9tgWVRq4dOIotpq56mFkCu.1aUaiT7s819tZNAST2","","0","","","0","","","","","","","","","0","user-1525065167-profile_fileuser_id_80.png","0","2","1","0","1","0","2018-04-30 13:29:33","","","0","","OvWnLW99QT6TKYaFSHEVdsifvjrS4ji-","","2018-04-30 10:41:31","2018-04-30 13:29:33","0"),
("89","","","jasmine Rao","jasmine@c.com","$2y$13$2sKpG11xVHqYv5ULBXZdz.1NITWpwB9w3mga2e27dRrzyBsXYfzxu","","0","","8557056606","0","","","","","","","","","0","","0","1","0","1","1","0","2018-05-01 11:37:41","","","0","","oAJSAOb7GP5rcvDuPe07KSNCGptVpam3","","2018-05-01 11:22:42","2018-05-01 11:37:41","0"),
("90","rose","Rao","rose Rao","rose@c.com","$2y$13$STl3WSgU7fbJnaE4UqXvM.yIjKJTBjAGaMAGAWutpa.scCHeR852m","","0","","","0","","","","","","","","","0","user-1525154292-profile_fileuser_id_90.png","0","1","1","0","1","0","2018-05-01 11:57:28","","","0","","pfn0_j0YNuCvfWeHN6iXXrbusVU-mhvd","","2018-05-01 11:25:16","2018-05-01 11:57:28","0"),
("91","Lilly","Rao","Lilly Rao","lilly@c.com","$2y$13$BvpXwgQ4YjV6fJpJtxb21u65m7MMm6.YM5OpJ6231wGNrZ0rdISMG","","0","","","0","","","","","","","","","0","","0","1","1","0","1","0","2018-05-01 11:51:12","","","0","","0wk0Rn_CRC0GhB7dL84Ee5TyX-g7t5wa","","2018-05-01 11:44:50","2018-05-01 11:51:12","0"),
("93","dolphin","pin","dolphin pin","dol@c.com","$2y$13$hbnTyWy3CDKhcUuqJU3usejm66YwthMhmL7idaD21C.LIH45ybMOu","","0","","","0","","","","","","","","","0","","0","2","1","0","1","0","2018-05-01 13:54:47","","","0","","_J2DuEvgeNIVeL6mWiNe02DqKnRZODNI","","2018-05-01 12:08:26","2018-05-01 13:54:47","0"),
("96","newcustomer","jjj","newcustomer jjj","new@c.com","$2y$13$hV76B1VJcAXhbsxRMMfhVegekljG29KTWZ8JmAvawj.G3gVpjgBWq","","0","","","0","","","","","","","","","0","user-1525163875-profile_fileuser_id_96.png","0","1","1","0","1","0","2018-05-01 14:53:44","","","0","","lU2r7C0QIzAw6_878r8q99fEO7twWX3M","","2018-05-01 14:05:25","2018-05-01 14:53:44","0"),
("97","Kane","nan","Kane nan","kane@c.com","$2y$13$gQPUAiDubuzTEF6aahDwnuqDJ7ZYFk6.Nkq6WBLHDgj81G0didvDG","","0","","2582588258","0","","","","","","","","","0","","0","1","1","1","1","0","2018-05-15 12:52:54","","","0","","NTh3xW695IKMfUE-US9nKEX4znGxkXdc","","2018-05-01 14:57:28","2018-05-15 12:52:54","0"),
("98","muneraa","alr","muneraa alr","munera637637@gmail.com","$2y$13$jjHLFodVm7jPHlVjt7I3me160wUqOO8sGYJlnRgBz8EET./lv5DSu","","0","","585","0","","","","","","5522","","","0","","0","1","1","1","1","0","2018-05-07 16:39:53","","","0","","Rp67-U77iDzORcrDis29NAtDelPXrmWO","","2018-05-01 15:47:58","2018-05-07 16:39:53","0"),
("108","","","grace ban","grace@c.com","$2y$13$RKB0zIp.mOf0YXeuyjBfuuBAyTj0yq5TSAZelU72fIRVAteR0jH6K","","0","","8888888888","0","","","","","","9999999999","","","0","","0","1","0","1","1","0","2018-05-04 19:11:13","","","0","","K4BpxgjRF6PRSiIXjhgllw_VQW6HpAGp","","2018-05-04 15:43:55","2018-05-04 19:11:13","0"),
("109","praise","ban","praise ban","praise@c.com","$2y$13$49A6J2fC/vFoDUlcuxW2SOJKZrnq1hz9ypaQ6vvc3JzKU.eRsrDty","","0","","5555555555","0","","","","","","3333333333","","","0","user-1525429131-profile_fileuser_id_109.png","0","2","1","1","1","0","2018-05-11 15:23:34","","","0","","Z5wOks7TVNzz7DkvIvsSGR2yx5dUuiK0","","2018-05-04 15:47:43","2018-05-11 15:23:34","0"),
("113","hello","user","hello user","hellouser@gmail.com","$2y$13$AmDVKkZkRk5JwlJFjMqBVOcsAs4RSc/77KlDOyFBSTlvMTdiA8Uru","","0","","","0","","","","","","","","","0","","0","2","1","0","1","0","2018-08-10 09:37:21","","","0","","Aay3l0NOa_Aj1EtMgbE2O3ZBL2mlc7t0","","2018-05-07 13:06:26","2018-08-10 09:37:21","0"),
("114","para","Rao","para Rao","para@c.com","$2y$13$3XoZJVZ.vXL3zH6qovizG.lo6RAGVBK1.vVWAQVPNDRetXENih8/y","","0","","","0","","","","","","","","","0","user-1525768783-profile_fileuser_id_114.png","0","2","1","0","1","0","2018-05-18 15:09:51","","","0","","FMcUqpl_e0GNSc7jG4NoSTSjJEb8_y_7","","2018-05-08 14:07:14","2018-05-18 15:09:51","0"),
("115","","","Diana ban","diana@c.com","$2y$13$6wrNHXbw5pC6N8RyskXxwOLp9tejOUZrImausuaJxkI4iQj0UNGIG","","0","","8524568528","0","","","","","","4568524568","","","0","","0","1","0","1","1","0","2018-05-08 14:39:57","","","0","","t21vfukIF5NIXoHVSRH2rZ7zsYOSDzYd","","2018-05-08 14:13:31","2018-05-08 14:39:57","0"),
("118","tiny","ttt","tiny ttt","tiny@c.com","$2y$13$2GRxaLcZ4QZH.gVvvNpKUOBXgdXNW36ILlEZuF4wKxfYpf9C/iPH.","","0","","","0","","","","","","","","","0","user-1526298352-profile_fileuser_id_118.png","0","2","1","0","1","0","2018-06-02 12:54:10","","","0","","YG6qBXalBlzZzFhxwfF042rbOKLl_o2t","","2018-05-14 17:11:50","2018-06-02 12:54:10","0"),
("128","","","Varun sharma","varuni@c.com","$2y$13$JMeTMPqX3/UEn6Aui6zmh.s/8tcqZ7iCHeNkYUqbkcEyTlfMZm0sK","","0","","5555","0","","","","","","3333333331558","","","0","","0","1","0","1","1","0","2018-05-18 17:41:50","","","0","","9wAKct-xavBZC9uaC2M6J222ZJcYvU78","","2018-05-18 15:25:20","2018-05-18 17:41:50","0"),
("131","jolly","jal","jolly jal","jolly@c.com","$2y$13$1JQwpqeZroIyRpCHkRRyIexHVYfvobF7Lp9K3Vrwdxk5MyhcLk.u2","","0","","","0","","","","","","","","","0","user-1529403934-profile_fileuser_id_131.png","","2","1","0","1","0","2018-06-19 10:28:56","","","","","wfr7WWh0xzCIRiebBEbK_Uzyij2kZDS0","","2018-06-19 08:36:48","2018-06-19 10:28:56",""),
("132","","","dose sos","dose@c.com","$2y$13$rTJkqoQ8G85XghKPxpgVguL2o8L85OLel6HAywXxOhrwKZYAZXDh.","","0","","22222233333","0","","","","","","85296325865","","","0","","","1","0","1","1","0","2018-06-19 10:17:19","","","","","qd2SuSBhlneea9kDU52uOHkE0qCwEWbi","","2018-06-19 08:45:30","2018-06-19 10:17:19",""),
("133","test","test","test test","testt@c.com","$2y$13$A6lWpLxoIhFSbrCUUKkN0uTl95cSMMfF/hSFdt/YL4TIlrkUQvmiu","","0","","5524855855","0","","","","","","7545455566","","","0","","","1","1","1","1","0","2018-06-19 10:20:24","","","","","311OtY2WSKpZ7orBO8x8kS-_maaLIYad","","2018-06-19 09:01:06","2018-06-19 10:20:24",""),
("137","munera","f","munera f","muneraaaa@gmail.com","$2y$13$Jy7o/UGCV33q8hbcq/0UcO0gIMEP9sMlUWLMFOzZ8/EwdSxjkEMzS","","0","","4","0","","","","","","4","","","0","user-1529481074-profile_fileuser_id_137.png","","1","1","1","1","0","2018-06-27 14:48:49","","","","","Mp5DvzYhsejQnxaIiZfFNdECN0YkCDHB","","2018-06-20 07:45:10","2018-06-27 14:48:49",""),
("138","","","sonu sharma","sonu@toxltech.com","$2y$13$xQSkq6eAjrNUf72vGkX0Fu2TtMCHClQZ.YBQsaMIoIemykZSmkI3a","","0","","12341234","0","","","","","","12341234","","","0","","","1","0","1","1","0","2018-06-26 07:21:50","","","","","VVIB9avauYZKQzm5MVXBcq6hfLjoh-69","","2018-06-26 07:11:48","2018-06-26 07:21:50","47"),
("142","","","Ammar Majeed","patodia@c.com","$2y$13$1fqt.2oakAqJYgshFyPtS.0HUuLukrfUYxV5mm6sPjwQy1DChoK/K","","0","","8557056606","0","","","","","","8577056606","","","0","","","1","0","1","1","0","2018-06-27 10:50:42","","","","","WROIYD1Fc_XuiqzQ3SEB4MI8Zr8Xju2Z","","2018-06-27 10:29:30","2018-06-27 10:50:42",""),
("143","jolly","sharma","jolly sharma","Patodia@g.com","$2y$13$uvFE.WM3e3FGhiAf6rasJO65ruKnu6IP8OBTU5Sp7CZgciKtr/Lie","","0","","82544588555","0","","","","","","88855555558","","","0","user-1530096994-profile_fileuser_id_143.png","","1","1","1","1","0","2018-06-27 11:01:30","","","","","MZPWFyJ8_wUzJKfRsIwJtMjFi3dIAqdb","","2018-06-27 10:52:37","2018-06-27 11:01:30",""),
("144","","","Geet Sharma","geet@c.com","$2y$13$LP6.qt.MRVYZyR6FStMXmuGfKJGVmQtDHCSBMkemAdK0uyxBVIKYi","","0","","8528528528","0","","","","","","8528528528","","","0","","","1","0","1","1","0","2018-06-27 14:07:34","","","","","LEVLILqQCdLK8r6zXUQCRSa9IB4fy3Bh","","2018-06-27 13:58:04","2018-06-27 14:07:34",""),
("145","for","log","for log","log@c.com","$2y$13$paT6mZOugRwazpULlXrwZemTMgrFJLF96mHbA9tUNfSwn6F268JP2","","0","","","0","","","","","","","","","0","","","2","1","0","1","0","2018-06-27 14:11:31","","","","","pFWxAi152vJZhoKuYkWt8L7Iwr8lst61","","2018-06-27 14:09:54","2018-06-27 14:11:31",""),
("146","munera","r","munera r","mun11@gmail.com","$2y$13$MKfFsYHWu5rTWpExTF1ohO4X6Zl9nihq4omQ9gcMLFkF2mzF3n08a","","0","","55565555","0","","","","","","55556688","","","0","","","1","1","1","1","0","2018-07-11 09:20:55","","","","","LkxRIo2W-sMW2aOVLiQm60kAk1k9B-oo","","2018-07-01 12:56:03","2018-07-11 09:20:55",""),
("147","alhwary","mo","mohamed alhwary","alhwary.dsn@gmail.com","$2y$13$F1JYlEUuj61R5DNrADpTCOmEeALrQrbM/nJztQLJP6bfbJkN9uwL.","","0","","60606060601","1","","","","","","60606060601","","","0","","","1","1","1","1","0","2018-08-07 13:55:41","","","","","lcAy50pW_VfJg2YJYmgknxqPVAG9Opuj","","2018-07-02 11:42:19","2018-08-07 13:55:41",""),
("148","sonu","sharma","sonu sharma","sonugautam@gmail.in","$2y$13$pFsyqlnLO68YXJR3D0yqNODDyDTTtPdx6wwPZPhLnsmVwN8JsWfym","","0","","41241234","1","","","","","","1423424323","","","0","","","1","1","1","1","0","2018-07-09 06:50:25","","","","","zoP7TGR5vmjFav74IBvei-V94TC8GAYQ","","2018-07-05 04:08:38","2018-07-09 06:50:25",""),
("150","Kabul","lab","Kabul lab","kabul@c.com","$2y$13$sY6HdiTistfEmQUvIBBWdOc9dF1XHUY7sImr0FFb80YYMRvqAEVHG","","0","","","0","","","","","","","","","0","","","2","1","0","1","0","2018-07-06 11:59:57","","","","","s9N56fv4s8NSbd9hNj3UtFW0ZdWxQ8xl","","2018-07-06 11:22:18","2018-07-06 11:59:57",""),
("152","","","faz  faz","faz@c.com","$2y$13$trS4MKcjAbRgsIHDHcvPceyJB0.v80IdcDxVxUagfvGNAWSyRs2DW","","0","","8528528521","0","","","","","","8528528523","","","0","","","1","0","1","1","0","2018-07-06 12:48:30","","","","","2kAdJXGeifOlLIKBOZ1qUpaJ74g8xocP","","2018-07-06 12:04:10","2018-07-06 12:48:30",""),
("153","","","YESWA Venodr","VendorNew@gmail.in","$2y$13$ovgbzbcLsgvoLWtyfMHIk.3rKx6KuB.V8x3eLRCEK7osry4axJbR6","","0","","12342323","0","","","","","","123412342","","","0","","","1","0","1","1","0","2018-07-09 06:15:52","","","","","oVrpgRbT0LUTBwnhLf2ZtdRfI9W1NvLs","","2018-07-09 04:21:48","2018-07-09 06:15:52",""),
("154","","","vendor toxsl","vendor@s.in","$2y$13$AEmU1wJB7hU8TMzvVLRT3.V5BeaEJlfrpjiRaSCXiUUn8Sm7UUt6.","","0","","21341234","0","","","","","","23423424","","","0","","","1","0","1","1","0","2018-07-09 06:27:31","","","","","uo0R3YX28ciVk9VY7dMh-VcZ1t8XIlHI","","2018-07-09 06:20:09","2018-07-09 06:27:31",""),
("155","","","sonu sharma","sonuharma@gmail.in","$2y$13$WC9O3D1Cqi6bg/0HLJkfEuL9XBZSjCzXidkjb9lk59A1SiB17CJ4W","","0","","1241234","1","","","","","","2142342","","","0","","","1","0","1","1","0","2018-07-09 06:37:56","","","","","j0MAbG2HQVP5yhxSSgHBSbABUgDavWWe","","2018-07-09 06:29:43","2018-07-09 06:37:56",""),
("159","test","gag","test gag","google@gmail.com","$2y$13$QMHGbMasK62dyoBvwWLLwOQw8zeMpuFLvtQbyHrntebztcyx1LmS6","","0","","","0","","","","","","","","","0","","","2","1","0","1","0","2018-07-09 09:50:43","","","","","zq_RC5iLdVFpq_Z4yZTcgrXLQJfx0es1","","2018-07-09 09:48:55","2018-07-09 09:50:43",""),
("162","","","merit merit","merit@c.com","$2y$13$r9R1l3SgWc77Wi9rzfqA7.WdyqyRBe8XB9CujIa.kVvdzNEo.VJbG","","0","","8888855555","1","","","","","","5555588888","","","0","","","1","0","1","1","0","2018-07-10 12:55:43","","","","","fvDtOFUVEtIg1iNPMcdKeSndhWojfhHi","","2018-07-10 11:31:47","2018-07-10 12:55:43",""),
("164","","","sat bzzb","saa@s.in","$2y$13$rGtcTH05vOcE0vVchAIUCOCbWOdywQwDTCZtfsd6h7yhY02iUzD0q","","0","","454546","0","","","","","","8484","","","0","","","1","0","1","1","0","2018-07-12 04:47:32","","","","","1S4sRzAYgmgDGewFGqe3Gr_tsj037dtU","","2018-07-10 12:27:31","2018-07-12 04:47:32",""),
("165","","","Atif Atif","atif@c.com","$2y$13$3u053u6zTSv6E0i/RkHgCuPGFu3kYVnOqbsTs92XRAcubPwFx7y0W","","0","","25855866665","1","","","","","","55588588585","","","0","","","1","0","1","1","0","2018-07-12 12:08:06","","","","","NFfJZTNH-uxdToETDGwHXFhgw4v_YReZ","","2018-07-12 12:05:29","2018-07-12 12:08:06",""),
("167","","","zzz zzz","zzz@c.com","$2y$13$.RWqsxGZNnnNxjdtPsgVa.eOr6EvcVju7vwTkYJ0wo8FAlkIgghoe","","0","","8528528528","1","","","","","","8523741358","","","0","","","1","0","1","1","0","2018-07-18 13:46:03","","","","","tadpf-rx5PjlwV7wiZ6nQnjthaArtfQD","","2018-07-18 13:20:29","2018-07-18 13:46:03",""),
("168","","","mohamed alhwary","alhwary.90@gmail.com","$2y$13$8HsAUTmrl.VpdrtHkDgdbu7Nf9LPEBoKvd8zVsod8JJKGnOvL8Djy","","0","","51518512121","1","","","","","","6464646121","","","0","","","1","0","1","1","0","2018-07-22 13:58:31","","","","MqPzFWUiGFdHRWnkMhnuPOkfH4KU74VB_1533130754","x1mxZ6Vcidvyo1zuxhUlUJ3yzSVWJvwb","","2018-07-22 13:56:11","2018-08-01 13:39:14",""),
("171","","","anki rana","ar@t.in","$2y$13$B4yF8Ggdfg/hD3Db/q.Ii.K2GlkN/jfyuCBButJA0XsHV4OA4Ihdi","","0","","7894561230","0","","","","","","9874561230","","","0","","","1","0","1","1","0","2018-08-02 11:34:34","","","","","OlE1NmrrZdBshJmdzdXb2g6MThwcxqNd","","2018-07-26 07:24:25","2018-08-02 11:34:34",""),
("173","","","m alrashedi","m12341234@gmail.com","$2y$13$Qtk.MVnWN0A8r3N3GDcy2.yRcAwoGnENaFmsLXnLz8ZJZ0yY2eqDS","","0","","577","1","","","","","","885","","","0","","","1","0","1","1","0","2018-07-26 15:09:18","","","","","y1wCIk79Rh94QduUP9hqvx1ZipOsKD_V","","2018-07-26 14:30:26","2018-07-26 15:09:18",""),
("175","","","patodia samara","smara@c.vom","$2y$13$xUJcerU6uu1TKOWTKx6B1uaDrTs.HCl.vo5Wv6j2ajidkwELoyNaO","","0","","1231231231","1","","","","","","1231231231","","","0","","","1","0","1","1","0","","","","","","TcXTKtNwhqhWRmp8BdMGnw2NweaF0HiG","","2018-08-01 09:25:34","2018-08-01 09:25:34",""),
("176","","","golf golf","golf@c.com","$2y$13$leE8pVU9yug.g.BjCqXBf.pqJKfRjYnPgJTszlOjwGEaCvNjFKFuO","","0","","8528528528","1","","","","","","8528528526","","","0","","","1","0","1","1","0","2018-08-01 09:46:17","","","","","Mv0KORDRis8H4sHt685LOPFQ86wbJcC4","","2018-08-01 09:29:15","2018-08-01 09:46:17",""),
("178","","","prize prize","yashikapatodia27@icloud.com","$2y$13$SLoqLWLCbU9Mofo.raf6xOD3xeiXVGujlFN3kpGZjCYoZYo3vfz5.","","0","","1231231232","1","","","","","","321213213","","","0","","","1","0","1","1","0","2018-08-02 11:18:08","","","","2-vuFeGVQ5sTQRS2ZT56QQmWDXIKD9VJ_1533208035","Y5QsuUogALL6JF25jSbeiRB9ac8B45XN","","2018-08-02 10:49:54","2018-08-02 11:18:08",""),
("183","     ","      ","","msbnsl@gmail.com","$2y$13$TlqYyz2eL7Dho5.PSCJdZufFpSG.9IhBCbDLLXZPJqcwG6sEqjj4.","","0","","","0","","","","","","","","","0","","","2","1","0","1","0","","","","","","k33bxzCm7TcGVZgrSYRbLja5GMxZOwBJ","","2018-08-03 08:55:02","2018-08-03 08:55:02",""),
("185","m","r","m r","muneraalrashedi@gmail.com","$2y$13$HlRqlXjKwJsNKA/tY0/dNeyXHQeZeGlaNq6nZ74W.xxh/rhW.LBgC","","0","","95886665","1","","","","","","6896635","","","0","","","1","1","1","1","0","2018-08-04 22:25:00","","","","","tDRfli7oFPTVhCqi4KZHd4IR-0dYRpcu","","2018-08-04 22:11:07","2018-08-04 22:25:00",""),
("186","mubarkf","alrr","mubarkf alrr","mubarkf404@gmail.com","$2y$13$24AagADrSZ3UkCvMGk50duTAm6txiwmWH7RakWAzZk.Qpm58LcyQm","","0","","","0","","","","","","","","","0","","","2","1","0","1","0","2018-08-04 22:24:11","","","","","ZIsTFczcCeITMQDHO-tGjp2R4w_AWSg5","","2018-08-04 22:22:20","2018-08-04 22:24:11",""),
("198","","","Vendor Yeswa","vendor@yeswa.in","$2y$13$C3z/2zPJsEjMvo7HUPPxluxmx/eoUo.5FTUWN1lycdht1fGkoSXRm","","0","","12412412","1","","","","","","1234123412","","","0","","","1","0","1","1","0","2018-08-23 04:01:05","","","","","D2qd0QkZkYOqkfEXMrC3q9g9R_M3TTDT","","2018-08-10 07:18:46","2018-08-23 04:01:05",""),
("199","Fatima","Majeed","Fatima Majeed","fatima@c.com","$2y$13$v9pNSinz.ZbWFYYMlHBxW.bFddA3cw9NnuDxupoVNJhcijiKuybUC","","0","","","0","","","","","","","","","0","user-1534424554-profile_fileuser_id_199.png","","1","1","0","1","0","2018-08-22 12:11:25","","","","","KTfpPaLc19W0Zr1TbbB3H2wC3SYSMkBD","","2018-08-16 13:00:13","2018-08-22 12:11:25",""),
("200","","","Amartya Majeed","amar@c.com","$2y$13$wMKd5lXn1hMpgyf4ICwXyuyhK8JoRWm5VX3oq4lFMbYWEogb90o.u","","0","","9696969696","1","","","","","","6363636363","","","0","","","1","0","1","1","0","2018-08-23 11:08:42","","","","","D6mXozyNwJ8ec5yOa8-j8NgQa2lF163s","","2018-08-16 13:04:59","2018-08-23 11:08:42",""),
("201","","","yeswa vendor","vendor@yeswa1.in","$2y$13$XjD8r9btgXkFLnqaTdc7ge7MscpOYQN5sPgFNq4cZCEpyWIQKr70K","","0","","53535225","1","","","","","","45545585","","","0","","","1","0","1","1","0","2018-08-23 10:27:52","","","","","u2znzOUlDrweWqTliNmmoA331X0ggp8O","","2018-08-23 04:03:13","2018-08-23 10:27:52",""),
("202","customer","yeswa","customer yeswa","customer@yeswa.in","$2y$13$/fjBY9h8GXCUcROYjdrXBOoIAN2d4yxurGcx/2xbtyst2Q1gmfVBK","","0","","","0","","","","","","","","","0","","","2","1","0","1","0","2018-08-23 10:27:22","","","","","o3sd-IulGKTNcDOafLtPRUBNB0-r0q3r","","2018-08-23 05:05:31","2018-08-23 10:27:22",""),
("203","lifa","majeed","lifa majeed","lifa@c.com","$2y$13$rqpMN45jveoRMREm3Kv3VuGD52WsGnuWqvEhIN3e.kSYrsOGIw7xO","","0","","","0","","","","","","","","","0","","","2","1","0","1","0","2018-08-23 11:18:15","","","","","XMxessgxPfrYBORUln-uxbbJ4Tn-jZ3L","","2018-08-23 09:35:36","2018-08-23 11:18:15","");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_vendor_address` (`id`,`location`,`city`,`area`,`block`,`street`,`house`,`apartment`,`office`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("1","Mohamad Ali Al Dakhan StreetKuwait City","Bsbs","bans","ddd","sss","sss","ddd","sss","1","0","2018","2018","2"),
("2","Aliquam quia rerum eaque mollitia facere quo ullam. Repellendus est dolor consequatur omnis fugit aut. Quisquam architecto est occaecati voluptatem molestias quibusdam. Corrupti eaque quia eaque.","Araceliborough","800 Yundt Prairie Suite 528Port Veda, NY 00815-0515","Janet Schneider","Antwon Kreiger","Emile Franecki DDS","Mrs. Lorine Lesch DVM","Sarah Pagac","1","0","2018","2018","10"),
("6","Ut modi sapiente voluptas aut voluptatem ut et. Nulla rerum rem accusantium inventore. Necessitatibus possimus et harum sint eum. Minus sint architecto suscipit quae autem recusandae.","Jaydonside","794 Roberts HarborVeumside, PA 48414-7332","Wilma Mraz","Thalia Franecki IV","Mrs. Caleigh Kuphal","Prof. Caterina Bergstrom Sr.","Destin Reilly","1","0","2018","2018","15"),
("33","Chandigarh RoadBadheri Sector 41Chandigarh","asdf","as","asdf","asdf","asdfa","asa","add","1","0","2018","2018","73"),
("34","DasmanKuwait City","sinsjss","sjnss","shsjs","sjjs","jshsjs","sjns","sijsis","1","0","2018","2018","66"),
("38","Mohali BypassPhase 3B-2 Sector 60Sahibzada Ajit Singh Nagar","Mohali","near","c","Mahi","35","tree","same","1","0","2018","2018","89"),
("41","Mohali BypassPhase 3B-2 Sector 60Sahibzada Ajit Singh Nagar","thin","are Ff","Chhattisgarh","Gigi","duh","f","chug","1","0","2018","2018","97"),
("42","Surratts RoadClinton","jdbdjs","jdbdjs","dhbs","djnd","jbsj","dinds","sjndid","1","0","2018","2018","77"),
("48","DasmanKuwait City","Kuwait","abc","c","21","234","weed","weed","1","0","2018","2018","108"),
("50","Salem Sabah Al Salem Al Sabah StreetAbu Halifa","Kuwait","Kuwait","c","st","234","1234","office","1","0","2018","2018","115"),
("55","Fahad Al-Salem Street JiblaKuwait City","Kuwait","Kuwait","c","10","234","building","no","1","0","2018","2018","128"),
("58","Fahad Al-Salem Street JiblaKuwait City","Kuwait","Kuwait","g","g","gy","hi","th","1","","2018","2018","132"),
("61","Soor StreetKuwait City","s","s","x","d","s","s","s","1","","2018","2018","137"),
("62","DasmanKuwait City","asdf","adds","asdf","asdf","asdf","asdfasdf","asdf","1","","2018","2018","138"),
("63","DasmanKuwait City","Kuwait","fhhh","vhj","cvhj","gg","vhj","gggg","1","","2018","2018","142"),
("64","DasmanKuwait City","Kuwait","ghhh","fgg","cvh","chj","vhj","fgg","1","","2018","2018","143"),
("65","Salem Sabah Al Salem Al Sabah StreetAbu Halifa","Kuwait","chhh","ghh","ghh","g","ghhhh","thump","1","","2018","2018","144"),
("66","DasmanKuwait City","kuwait","farwa","7","56","66","66","hh","1","","2018","2018","147"),
("68","Al-Shuhada Street SharqKuwait City","Kuwait","Kuwait","b","t","234","office","office","1","","2018","2018","152"),
("69","DasmanKuwait City","asdf","asdf","asdf","gfhjfg","sigh","dfgh","dfgh","1","","2018","2018","153"),
("70","DasmanKuwait City","asdf","asdf","asdf","asdfasdfas","asdf","asdf","asdf","1","","2018","2018","154"),
("71","DasmanKuwait City","asdf","asdfasdfas","dad","asdf","asdf","asdfasdfas","asdf","1","","2018","2018","155"),
("75","Al-Shuhada Street SharqKuwait City","Kuwait","Kuwait","b","abc","abc","abc","abc","1","","2018","2018","162"),
("77","DasmanKuwait City","shdj","hash","hdhd","hdhd","shdj","bsbd","bsbd","1","","2018","2018","164"),
("78","DasmanKuwait City","Kuwait","asset","b","bout","fgh","fhjjj","chhh","1","","2018","2018","165"),
("79","DasmanKuwait City","kuwait","kuwait","c","d","345","tin","tin","1","","2018","2018","167"),
("80","Al Kuwayt,Al Farwaniyah,Kuwait","Farwaniya","haga","gaga","gaga","haha","gagaha","hahah","1","","2018","2018","168"),
("81","Mohamad Bin Al Qasim StreetKuwait City","mohali","nsssa","123","hhh","456","ewe","dead reter were","1","","2018","2018","171"),
("82","Hamad Yousif Bin Hussain Al-Roumi Street SurraKuwait City","cd","dcc","dcc","def","dfc","wer","ff","1","","2018","2018","173"),
("83","DasmanKuwait City","Kuwait","Kuwait","b","golf club","55","78","Elantra","1","","2018","2018","175"),
("84","DasmanKuwait City","quail","Kuwait","b","g","55","h","Elantra","1","","2018","2018","176"),
("85","Salem Sabah Al Salem Al Sabah StreetAbu Halifa","Kuwait","Kuwait","h","h","234","y","f","1","","2018","2018","178"),
("86","Hamad Yousif Bin Hussain Al-Roumi Street Surra","Asmiah","surra","6","13","5","4","-","1","","2018","2018","185"),
("87","Niper Road,Mohali Sector 70,Mohali,Chandigarh 140301,India","asdf","asdf","asdfasdfas","asdf","asdfasdfas","asdfasdfas","asdf","1","","2018","2018","198"),
("88","Salem Sabah Al Salem Al Sabah StreetAbu Halifa","Kuwait","Kuwait","g","g","j","C block","Kuwait","1","","2018","2018","200"),
("89","DasmanKuwait City","chcj","hchc","dhdh","ff","fg","gg","ghh","1","","2018","2018","201");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_vendor_location` (`id`,`vendor_id`,`location`,`latitude`,`longitude`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("1","2","Mohamad Ali Al Dakhan StreetKuwait City","29.3347","48.0242","1","0","2018-03-28 13:11:48","2018-07-18 12:33:05","2"),
("2","10","Aliquam quia rerum eaque mollitia facere quo ullam. Repellendus est dolor consequatur omnis fugit aut. Quisquam architecto est occaecati voluptatem molestias quibusdam. Corrupti eaque quia eaque.","30.7046","76.7179","1","0","2018-03-28 14:37:18","2018-03-28 14:37:18","10"),
("6","15","Ut modi sapiente voluptas aut voluptatem ut et. Nulla rerum rem accusantium inventore. Necessitatibus possimus et harum sint eum. Minus sint architecto suscipit quae autem recusandae.","30.7046","76.7179","1","0","2018-03-29 11:27:26","2018-03-29 11:27:26","15"),
("32","73","Chandigarh RoadBadheri Sector 41Chandigarh","30.7327","76.7298","1","0","2018-04-16 14:41:43","2018-04-16 14:41:43","73"),
("33","66","DasmanKuwait City","29.39","48.0031","1","0","2018-04-19 20:49:59","2018-04-19 20:49:59","66"),
("37","89","Mohali BypassPhase 3B-2 Sector 60Sahibzada Ajit Singh Nagar","30.7075","76.7156","1","0","2018-05-01 11:22:42","2018-05-01 11:22:42","89"),
("40","97","Mohali BypassPhase 3B-2 Sector 60Sahibzada Ajit Singh Nagar","30.7075","76.7156","1","0","2018-05-01 15:00:38","2018-05-01 15:00:38","97"),
("41","77","Surratts RoadClinton","38.747","-76.8736","1","0","2018-05-01 15:46:24","2018-05-01 15:46:24","77"),
("47","108","DasmanKuwait City","0.0","0.0","1","0","2018-05-04 15:43:55","2018-05-04 15:43:55","108"),
("49","115","Salem Sabah Al Salem Al Sabah StreetAbu Halifa","0.0","0.0","1","0","2018-05-08 14:13:31","2018-05-08 14:13:31","115"),
("54","128","Fahad Al-Salem Street JiblaKuwait City","0.0","0.0","1","0","2018-05-18 15:25:20","2018-05-18 17:41:38","128"),
("57","132","Fahad Al-Salem Street JiblaKuwait City","0.0","0.0","1","0","2018-06-19 08:45:30","2018-06-19 10:09:52","132"),
("60","137","Soor StreetKuwait City","29.3617","47.979","1","0","2018-06-22 15:16:38","2018-06-22 15:16:38","137"),
("61","138","DasmanKuwait City","29.39","48.0031","1","0","2018-06-26 07:11:48","2018-06-26 07:11:48","138"),
("62","142","DasmanKuwait City","29.39","48.0031","1","0","2018-06-27 10:29:30","2018-06-27 10:29:30","142"),
("63","143","DasmanKuwait City","29.39","48.0031","1","0","2018-06-27 11:01:16","2018-06-27 11:01:16","143"),
("64","144","Salem Sabah Al Salem Al Sabah StreetAbu Halifa","29.134","48.1323","1","0","2018-06-27 13:58:04","2018-06-27 13:58:04","144"),
("65","147","DasmanKuwait City","29.39","48.0031","1","0","2018-07-02 13:16:49","2018-07-02 13:31:56","147"),
("67","152","Al-Shuhada Street SharqKuwait City","29.3787","47.9911","1","0","2018-07-06 12:04:10","2018-07-06 12:04:10","152"),
("68","153","DasmanKuwait City","29.39","48.0031","1","0","2018-07-09 04:21:48","2018-07-09 04:21:48","153"),
("69","154","DasmanKuwait City","29.39","48.0031","1","0","2018-07-09 06:20:09","2018-07-09 06:20:09","154"),
("70","155","DasmanKuwait City","29.39","48.0031","1","0","2018-07-09 06:29:43","2018-07-09 06:29:43","155"),
("74","162","Al-Shuhada Street SharqKuwait City","0.0","0.0","1","0","2018-07-10 11:31:47","2018-07-10 12:55:13","162"),
("76","164","DasmanKuwait City","29.39","48.0031","1","0","2018-07-10 12:27:31","2018-07-10 12:27:31","164"),
("77","165","DasmanKuwait City","29.3897","48.0032","1","0","2018-07-12 12:05:29","2018-07-12 12:05:29","165"),
("78","167","DasmanKuwait City","29.39","48.0031","1","0","2018-07-18 13:20:29","2018-07-18 13:20:29","167"),
("79","168","Al Kuwayt,Al Farwaniyah,Kuwait","29.2904","47.9191","1","0","2018-07-22 13:56:11","2018-07-22 13:56:11","168"),
("80","171","Mohamad Bin Al Qasim StreetKuwait City","29.2853","47.9278","1","0","2018-07-26 07:24:25","2018-07-26 07:24:25","171"),
("81","173","Hamad Yousif Bin Hussain Al-Roumi Street SurraKuwait City","29.3135","48.0049","1","0","2018-07-26 14:30:26","2018-07-26 14:30:26","173"),
("82","175","DasmanKuwait City","29.39","48.0031","1","0","2018-08-01 09:25:34","2018-08-01 09:25:34","175"),
("83","176","DasmanKuwait City","29.39","48.0031","1","0","2018-08-01 09:29:15","2018-08-01 09:29:15","176"),
("84","178","Salem Sabah Al Salem Al Sabah StreetAbu Halifa","0.0","0.0","1","0","2018-08-02 10:49:54","2018-08-02 11:11:06","178"),
("85","185","Hamad Yousif Bin Hussain Al-Roumi Street Surra","29.3132","48.0053","1","0","2018-08-04 22:19:37","2018-08-04 22:19:37","185"),
("86","198","Niper Road,Mohali Sector 70,Mohali,Chandigarh 140301,India","30.7046","76.7179","1","0","2018-08-10 07:18:46","2018-08-10 07:18:46","198"),
("87","200","Salem Sabah Al Salem Al Sabah StreetAbu Halifa","30.713","76.7093","1","0","2018-08-16 13:04:59","2018-08-16 13:55:10","200"),
("88","201","DasmanKuwait City","29.39","48.0031","1","0","2018-08-23 04:03:13","2018-08-23 04:03:13","201");

 -- -------AutobackUpStarttoxsl------ 


INSERT INTO `tbl_vendor_profile` (`id`,`title`,`first_name`,`last_name`,`civil_id`,`description`,`whats_app_no`,`shopname`,`shop_logo`,`state_id`,`type_id`,`created_on`,`updated_on`,`created_by_id`) VALUES
("1","Sapna babajj","Sapna","babajj","hshs","","2484394","hshsjds","user-1531917185-shop_logouser_id_2.png","1","0","2018-03-28 13:11:48","2018-07-18 12:33:05","2"),
("9","Colten Marquardt","Colten","Marquardt","Willms Inc","","1-520-410-0154 x27868","Luna Leuschke","user-1522228038-shop_logouser_id_2.jpg","1","0","2018-03-28 14:37:18","2018-03-28 14:37:18","10"),
("13","Mona Cassin","Mona","Cassin","Bayer, Terry and O‘Conner","","1-959-282-6654","Sadie Nikolaus","user-1522303046-shop_logouser_id_1.gif","1","0","2018-03-29 11:27:26","2018-03-29 11:27:26","15"),
("40","Switch  Vendor","Switch","Vendor","asdf","","1234132433","asdf","user-1523869903-shop_logouser_id_73.png","1","0","2018-04-16 14:41:43","2018-04-16 14:41:43","73"),
("41","sjnzz jshzjsi","sjnzz","jshzjsi","sjnsjisos","","4468764","sishisos","user-1524151199-shop_logouser_id_66.png","1","0","2018-04-19 20:49:59","2018-04-19 20:49:59","66"),
("45","jasmine Rao","jasmine","Rao","233","","8557056606","jazz","user-1525153962-shop_logouser_id_.png","1","0","2018-05-01 11:22:42","2018-05-01 11:22:42","89"),
("48","you you","you","you","134","","9639639639","mahal","user-1525167038-shop_logouser_id_97.png","1","0","2018-05-01 15:00:38","2018-05-01 15:00:38","97"),
("49","munera alrashedi","munera","alrashedi","1037929283","","65082777","jxbsjskx","user-1525169784-shop_logouser_id_77.png","1","0","2018-05-01 15:46:24","2018-05-01 15:46:24","77"),
("55","grace ban","grace","ban","c2134","","8888888888","Mobe","user-1525428835-shop_logouser_id_.png","1","0","2018-05-04 15:43:55","2018-05-04 15:43:55","108"),
("57","Diana ban","Diana","ban","1234","","8524568528","Dmore","user-1525769011-shop_logouser_id_.png","1","0","2018-05-08 14:13:31","2018-05-08 14:13:31","115"),
("62","varuni Rao","Varun","sharma","Qadgjkllcn","","121344556","goal","user-1526645498-shop_logouser_id_128.png","1","0","2018-05-18 15:25:20","2018-05-18 17:41:38","128"),
("65","dose sos","dose","sos","yyy","","5555522222","Lacoste","user-1529402991-shop_logouser_id_132.png","1","0","2018-06-19 08:45:30","2018-06-19 10:09:51","132"),
("68","j f","j","f","fccddc","","5588588","ddcd","user-1529680598-shop_logouser_id_137.png","1","0","2018-06-22 15:16:38","2018-06-22 15:16:38","137"),
("69","sonu sharma","sonu","sharma","Hr-234","","9874747478","Show","user-1529997108-shop_logouser_id_47.png","1","0","2018-06-26 07:11:48","2018-06-26 07:11:48","138"),
("70","Ammar Majeed","Ammar","Majeed","tui","","8557056606","Zara","user-1530095370-shop_logouser_id_.png","1","0","2018-06-27 10:29:30","2018-06-27 10:29:30","142"),
("71","ghhh chj","ghhh","chj","fhj","","85588228656","ghhh","user-1530097276-shop_logouser_id_143.png","1","0","2018-06-27 11:01:16","2018-06-27 11:01:16","143"),
("72","Geet Sharma","Geet","Sharma","this","","2582582882","doremon","user-1530107884-shop_logouser_id_.png","1","0","2018-06-27 13:58:04","2018-06-27 13:58:04","144"),
("73","mohamed alhwary","mohamed","alhwary","666161616161","","60706701","alhwary shop","user-1530538316-shop_logouser_id_147.png","1","0","2018-07-02 13:16:49","2018-07-02 13:31:56","147"),
("75","faz  faz","faz","faz","123","","8528528521","ghhj","user-1530878650-shop_logouser_id_.png","1","0","2018-07-06 12:04:10","2018-07-06 12:04:10","152"),
("76","YESWA Venodr","YESWA","Venodr","Hr-23","","9873439338","Cama","user-1531110108-shop_logouser_id_.png","1","0","2018-07-09 04:21:48","2018-07-09 04:21:48","153"),
("77","vendor toxsl","vendor","toxsl","Hr-333","","1234134123","Lucky","user-1531117209-shop_logouser_id_.png","1","0","2018-07-09 06:20:09","2018-07-09 06:20:09","154"),
("78","sonu sharma","sonu","sharma","Hr-3338","","21424234","Xyz","user-1531117783-shop_logouser_id_.png","1","0","2018-07-09 06:29:43","2018-07-09 06:29:43","155"),
("82","merit merit","merit","merit","you","","8888888886","shopper stop","user-1531227313-shop_logouser_id_162.png","1","0","2018-07-10 11:31:47","2018-07-10 12:55:13","162"),
("84","sat bzzb","sat","bzzb","hddhshdj","","454546","shdj","user-1531225651-shop_logouser_id_.png","1","0","2018-07-10 12:27:31","2018-07-10 12:27:31","164"),
("85","Atif Atif","Atif","Atif","987","","5555555557","Channel","user-1531397129-shop_logouser_id_.png","1","0","2018-07-12 12:05:29","2018-07-12 12:05:29","165"),
("86","zzz zzz","zzz","zzz","tom","","2222222229","jjj","user-1531920029-shop_logouser_id_.png","1","0","2018-07-18 13:20:29","2018-07-18 13:20:29","167"),
("87","mohamed alhwary","mohamed","alhwary","515151638","","60607070","alhwary shop","user-1532267771-shop_logouser_id_.png","1","0","2018-07-22 13:56:11","2018-07-22 13:56:11","168"),
("88","anki rana","anki","rana","123456790","","7894561230","ankee","user-1532589865-shop_logouser_id_.png","1","0","2018-07-26 07:24:25","2018-07-26 07:24:25","171"),
("89","m alrashedi","m","alrashedi","39289292","","2505686","idndnks","user-1532615426-shop_logouser_id_.png","1","0","2018-07-26 14:30:26","2018-07-26 14:30:26","173"),
("90","patodia samara","patodia","samara","33","","8528528523","fork","user-1533115534-shop_logouser_id_.png","1","0","2018-08-01 09:25:34","2018-08-01 09:25:34","175"),
("91","golf golf","golf","golf","g","","1231231231","form","user-1533115755-shop_logouser_id_.png","1","0","2018-08-01 09:29:15","2018-08-01 09:29:15","176"),
("92","prize prize","prize","prize","h","","8528528524","Armani","user-1533208266-shop_logouser_id_178.png","1","0","2018-08-02 10:49:54","2018-08-02 11:11:06","178"),
("93","m r","m","r","46767888","","508655856","mubarkkk","user-1533421177-shop_logouser_id_185.png","1","0","2018-08-04 22:19:37","2018-08-04 22:19:37","185"),
("94","Vendor Yeswa","Vendor","Yeswa","asdfasdfas","","12341234","asdfasdfas","user-1533885526-shop_logouser_id_.png","1","0","2018-08-10 07:18:46","2018-08-10 07:18:46","198"),
("95","Amar Majeed","Amartya","Majeed","097","","8585885585","Gucci","user-1534427710-shop_logouser_id_200.png","1","0","2018-08-16 13:04:59","2018-08-16 13:55:10","200"),
("96","yeswa vendor","yeswa","vendor","chcjcj","","86656556","reliance store","user-1534996993-shop_logouser_id_.png","1","0","2018-08-23 04:03:13","2018-08-23 04:03:13","201");

 -- -------AutobackUpStarttoxsl------ -- -------------------------------------------
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
COMMIT;
 -- -------AutobackUpStarttoxsl------ -- -------------------------------------------

-- -------------------------------------------

-- END BACKUP

-- -------------------------------------------
